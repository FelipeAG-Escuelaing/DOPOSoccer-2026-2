package test.domain;

import domain.CharacterType;
import domain.DOPOSoccerException;
import domain.NormalState;
import domain.Player;
import domain.StunnedState;

/**
 * Pruebas unitarias para la entidad Player:
 *  - Vida y fórmulas oficiales
 *  - Movimiento, salto y patada
 *  - Aturdimiento a 0 de vida (3s inmovilizado y restablecimiento de VidaMax)
 *  - Reglas 1, 2, 3 y 7 de Poder: carga en 10s, bono de 25% por recibir gol, aura y vaciado de barra
 *  - Mejoras de estadísticas con puntos
 */
public class PlayerTest {

    public void testPlayerInitializationAndHealth() {
        Player p = new Player(1, "Corea", CharacterType.SOUTH_KOREA, 200.0, 500.0, 1.0);
        assertEquals(120.0, p.getCurrentHealth(), 1e-4);
        assertEquals(120.0, p.getStats().getVidaMax(), 1e-4);
        assertEquals(0.0, p.getPowerEnergy(), 1e-4);
        assertFalse(p.hasActivePower());
        assertTrue(p.getState() instanceof NormalState);
        assertTrue(p.isGrounded());
    }

    public void testMovementAndBoundaries() {
        Player p = new Player(1, "Corea", CharacterType.SOUTH_KOREA, 200.0, 500.0, 1.0);
        p.moveRight();
        assertTrue(p.getVelocity().getX() > 0);

        p.update(0.1, 1000.0, 500.0);
        assertTrue(p.getPosition().getX() > 200.0);

        p.moveLeft();
        assertTrue(p.getVelocity().getX() < 0);

        p.stopHorizontal();
        assertEquals(0.0, p.getVelocity().getX(), 1e-4);
    }

    public void testJumpPhysics() {
        Player p = new Player(1, "Corea", CharacterType.SOUTH_KOREA, 200.0, 500.0, 1.0);
        assertTrue(p.isGrounded());

        p.jump();
        assertFalse(p.isGrounded());
        assertTrue(p.getVelocity().getY() < 0);

        p.update(0.5, 1000.0, 500.0);
        p.update(1.0, 1000.0, 500.0);
        assertTrue(p.isGrounded());
        assertEquals(500.0, p.getPosition().getY(), 1e-4);
    }

    public void testKickStateAndCooldown() {
        Player p = new Player(1, "Corea", CharacterType.SOUTH_KOREA, 200.0, 500.0, 1.0);
        assertFalse(p.isKicking());

        boolean kicked = p.kick();
        assertTrue(kicked);
        assertTrue(p.isKicking());

        boolean kickAgain = p.kick();
        assertFalse(kickAgain);

        p.update(0.25, 1000.0, 500.0);
        assertFalse(p.isKicking());
    }

    public void testDamageAndStunAtZeroHealth() {
        Player p = new Player(1, "Corea", CharacterType.SOUTH_KOREA, 200.0, 500.0, 1.0);

        p.takeDamage(50.0);
        assertEquals(70.0, p.getCurrentHealth(), 1e-4);
        assertTrue(p.getState() instanceof NormalState);

        p.takeDamage(100.0);
        assertEquals(0.0, p.getCurrentHealth(), 1e-4);

        // Al llegar a 0 de vida, el jugador se inmoviliza por 3s
        assertTrue(p.getState() instanceof StunnedState);
        StunnedState stun = (StunnedState) p.getState();
        assertEquals("ATURDIDO", stun.getStateName());
        assertFalse(p.getState().canMove());
        assertFalse(p.getState().canJump());
        assertFalse(p.getState().canKick());
        assertFalse(p.getState().canUsePower());

        // Pasan 2.0s: sigue aturdido
        p.update(2.0, 1000.0, 500.0);
        assertTrue(p.getState() instanceof StunnedState);

        // Pasan 1.1s más: supera los 3.0s y restablece VidaMax
        p.update(1.1, 1000.0, 500.0);
        assertTrue(p.getState() instanceof NormalState);
        assertEquals(120.0, p.getCurrentHealth(), 1e-4);
        assertTrue(p.getState().canMove());
    }

    public void testOfficialPowerRulesChargingAndAura() throws DOPOSoccerException {
        Player p = new Player(1, "Corea", CharacterType.SOUTH_KOREA, 200.0, 500.0, 1.0);

        // La barra se llena en 10 segundos (10 puntos por segundo)
        p.update(5.0, 1000.0, 500.0);
        assertEquals(50.0, p.getPowerEnergy(), 1e-2);
        assertFalse(p.isPowerReady());

        // Al recibir un gol, la barra aumenta de inmediato un cuarto (+25.0)
        p.onConcedeGoal();
        assertEquals(75.0, p.getPowerEnergy(), 1e-2);

        // Terminar de cargar hasta 100
        p.update(2.5, 1000.0, 500.0);
        assertEquals(100.0, p.getPowerEnergy(), 1e-2);
        assertTrue(p.isPowerReady());

        // Con la barra llena, activa el poder. La barra se vacía y queda con aura visible
        p.activatePowerAura();
        assertTrue(p.hasActivePower());
        assertEquals(0.0, p.getPowerEnergy(), 1e-4);

        // Mientras tenga el poder, no puede activar otro poder
        boolean thrown = false;
        try {
            p.activatePowerAura();
        } catch (DOPOSoccerException e) {
            thrown = true;
        }
        assertTrue(thrown);
    }

    public void testStatUpgradesWithPoints() {
        Player p = new Player(1, "Corea", CharacterType.SOUTH_KOREA, 200.0, 500.0, 1.0);
        assertEquals(0, p.getAccumulatedPoints());

        // Nivel base de Kick = 4
        assertEquals(4, p.getStats().getKick());

        // Sin puntos no puede mejorar
        assertFalse(p.upgradeStat("kick"));

        // Costo para subir de nivel 4: 500 * 2^(4-1) = 500 * 8 = 4000 pts
        p.addPoints(4000);
        assertTrue(p.upgradeStat("kick"));
        assertEquals(5, p.getStats().getKick());
        assertEquals(0, p.getAccumulatedPoints());
    }

    private void assertEquals(double expected, double actual, double delta) {
        if (Math.abs(expected - actual) > delta) {
            throw new AssertionError("Esperado: " + expected + ", pero fue: " + actual);
        }
    }

    private void assertEquals(int expected, int actual) {
        if (expected != actual) {
            throw new AssertionError("Esperado: " + expected + ", pero fue: " + actual);
        }
    }

    private void assertEquals(String expected, String actual) {
        if (!expected.equals(actual)) {
            throw new AssertionError("Esperado: " + expected + ", pero fue: " + actual);
        }
    }

    private void assertTrue(boolean condition) {
        if (!condition) {
            throw new AssertionError("Se esperaba true pero fue false");
        }
    }

    private void assertFalse(boolean condition) {
        if (condition) {
            throw new AssertionError("Se esperaba false pero fue true");
        }
    }
}
