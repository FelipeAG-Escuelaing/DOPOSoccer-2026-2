package test.domain;

import domain.Ball;
import domain.CharacterType;
import domain.Field;
import domain.GoalMatch;
import domain.Player;
import domain.TimeMatch;

/**
 * Pruebas unitarias para las modalidades de partido:
 * - TimeMatch: cuenta regresiva, fin reglamentario, activación de Muerte Súbita
 * al empatar.
 * - GoalMatch: límite de goles, fin inmediato.
 * - Asignación de puntos (+100 Ganador, +25 Perdedor).
 * - Regla 1: Al recibir un gol, la barra aumenta un cuarto (+25%).
 * - Reubicación con caída desde el centro tras gol.
 * - Exclusión de goles de balones falsos (ilusión).
 */
public class MatchTest {

    public void testGoalMatchFinishesAtLimit() {
        Field f = new Field();
        Player p1 = new Player(1, "P1", CharacterType.SOUTH_KOREA, 200.0, 500.0, 1.0);
        Player p2 = new Player(2, "P2", CharacterType.CAMEROON, 800.0, 500.0, -1.0);
        GoalMatch match = new GoalMatch(f, p1, p2, 2);

        assertFalse(match.isGameOver());
        assertEquals(0, match.getScore1());
        assertEquals(0, match.getScore2());

        // Gol 1 de P1
        match.handleGoal(1);
        assertEquals(1, match.getScore1());
        assertFalse(match.isGameOver());

        // REGLA 1: P2 recibió gol -> su barra aumenta +25%
        assertEquals(25.0, p2.getPowerEnergy(), 1e-2);

        // Gol 2 de P1 (alcanza el límite de 2)
        match.update(2.5); // Fin celebración
        match.handleGoal(1);

        // REGLAS OFICIALES: Partido finalizado, puntos asignados (+100 ganador, +25
        // perdedor)
        assertTrue(match.isGameOver());
        assertEquals(p1, match.getWinner());
        assertEquals(p2, match.getLoser());
        assertEquals(100, match.getWinnerPoints());
        assertEquals(25, match.getLoserPoints());
        assertEquals(100, p1.getAccumulatedPoints());
        assertEquals(25, p2.getAccumulatedPoints());
    }

    public void testTimeMatchRegularEnd() {
        Field f = new Field();
        Player p1 = new Player(1, "P1", CharacterType.SOUTH_KOREA, 200.0, 500.0, 1.0);
        Player p2 = new Player(2, "P2", CharacterType.CAMEROON, 800.0, 500.0, -1.0);
        TimeMatch match = new TimeMatch(f, p1, p2, 30.0);

        match.handleGoal(1);
        match.update(2.5);

        // Tiempo se agota con marcador 1 - 0
        match.setTimeRemaining(0.0);
        match.update(0.1);

        assertTrue(match.isGameOver());
        assertFalse(match.isSuddenDeath());
        assertEquals(p1, match.getWinner());
        assertEquals(100, match.getWinnerPoints());
        assertEquals(25, match.getLoserPoints());
    }

    public void testTimeMatchSuddenDeathOnTie() {
        Field f = new Field();
        Player p1 = new Player(1, "P1", CharacterType.SOUTH_KOREA, 200.0, 500.0, 1.0);
        Player p2 = new Player(2, "P2", CharacterType.CAMEROON, 800.0, 500.0, -1.0);
        TimeMatch match = new TimeMatch(f, p1, p2, 30.0);

        // Marcador 0 - 0 (empate) y se agota el tiempo reglamentario
        match.setTimeRemaining(0.0);
        match.update(0.1);

        // REGLA OFICIAL: Muerte Súbita al empatar al finalizar el tiempo reglamentario
        assertFalse(match.isGameOver());
        assertTrue(match.isSuddenDeath());

        // Gol de oro finaliza el partido inmediatamente
        match.handleGoal(2);
        assertTrue(match.isGameOver());
        assertEquals(p2, match.getWinner());
        assertEquals(p1, match.getLoser());
        assertEquals(100, match.getWinnerPoints());
        assertEquals(25, match.getLoserPoints());
    }

    public void testResetAfterGoalDropsFromAbove() {
        Field f = new Field();
        Player p1 = new Player(1, "P1", CharacterType.SOUTH_KOREA, 200.0, 500.0, 1.0);
        Player p2 = new Player(2, "P2", CharacterType.CAMEROON, 800.0, 500.0, -1.0);
        GoalMatch match = new GoalMatch(f, p1, p2, 5);

        match.resetAfterGoal();

        // El balón y personajes deben estar por encima del suelo para caer (Pág. 1)
        assertTrue(match.getMainBall().getPosition().getY() < f.getGroundY());
        assertTrue(p1.getPosition().getY() < f.getGroundY());
        assertTrue(p2.getPosition().getY() < f.getGroundY());
    }

    public void testIllusionBallCannotScoreGoal() {
        Field f = new Field();
        Player p1 = new Player(1, "P1", CharacterType.SOUTH_KOREA, 200.0, 500.0, 1.0);
        Player p2 = new Player(2, "P2", CharacterType.CAMEROON, 800.0, 500.0, -1.0);
        GoalMatch match = new GoalMatch(f, p1, p2, 3);

        Ball illusion = new Ball(f.getWidth() - 10.0, 400.0, true);
        assertFalse(f.getRightGoal().isGoal(illusion));
    }

    private void assertEquals(int expected, int actual) {
        if (expected != actual) {
            throw new AssertionError("Esperado: " + expected + ", pero fue: " + actual);
        }
    }

    private void assertEquals(double expected, double actual, double delta) {
        if (Math.abs(expected - actual) > delta) {
            throw new AssertionError("Esperado: " + expected + ", pero fue: " + actual);
        }
    }

    private void assertEquals(Object expected, Object actual) {
        if (expected != actual && (expected == null || !expected.equals(actual))) {
            throw new AssertionError("Esperado: " + expected + ", pero fue: " + actual);
        }
    }

    private void assertTrue(boolean condition) {
        if (!condition) {
            throw new AssertionError("Se esperaba true pero fue false");
        }
    }

    private void assertFalse(boolean condition) {
        if (condition) {
            throw new AssertionError("Se esperaba false pero fue true");
        }
    }
}
