package test;

import test.domain.CharacterStatsTest;
import test.domain.DOPOSoccerTest;
import test.domain.MatchTest;
import test.domain.Physics2DTest;
import test.domain.PlayerTest;
import test.domain.PowerShotTest;

import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;

/**
 * Ejecutor automatizado de Pruebas Unitarias para DOPOSoccer (Versión Uno).
 * Ejecuta todas las suites de prueba de la capa de dominio sin requerir
 * dependencias externas.
 */
public class TestRunner {

    public static void main(String[] args) {
        System.out.println("DOPOSoccer 2026-2 - Pruebas Unitarias");
        System.out.println("Escuela Colombiana de Ingenieria Julio Garavito (DOPO)\n");

        List<Class<?>> testClasses = new ArrayList<>();
        testClasses.add(CharacterStatsTest.class);
        testClasses.add(PlayerTest.class);
        testClasses.add(PowerShotTest.class);
        testClasses.add(MatchTest.class);
        testClasses.add(DOPOSoccerTest.class);
        testClasses.add(Physics2DTest.class);

        int totalTests = 0;
        int passedTests = 0;
        int failedTests = 0;
        long startTime = System.currentTimeMillis();

        for (Class<?> testClass : testClasses) {
            System.out.println("-> Ejecutando pruebas en: " + testClass.getSimpleName());
            Method[] methods = testClass.getDeclaredMethods();

            for (Method method : methods) {
                if (method.getName().startsWith("test") && method.getParameterCount() == 0) {
                    totalTests++;
                    try {
                        Object instance = testClass.getDeclaredConstructor().newInstance();
                        method.invoke(instance);
                        System.out.println("   [PASO]  " + method.getName());
                        passedTests++;
                    } catch (Throwable t) {
                        failedTests++;
                        Throwable cause = t.getCause() != null ? t.getCause() : t;
                        System.err.println("   [FALLO] " + method.getName() + " -> " + cause.getMessage());
                        cause.printStackTrace(System.err);
                    }
                }
            }
            System.out.println();
        }

        long elapsedTime = System.currentTimeMillis() - startTime;
        double passRate = totalTests > 0 ? (passedTests * 100.0 / totalTests) : 0.0;

        System.out.println("\nResumen de Pruebas Unitarias:");
        System.out.println("Total de pruebas ejecutadas: " + totalTests);
        System.out.println("Pruebas exitosas:            " + passedTests);
        System.out.println("Pruebas fallidas:            " + failedTests);
        System.out.println(String.format("Tasa de exito:               %.1f%%", passRate));
        System.out.println("Tiempo total:                " + elapsedTime + " ms");

        if (failedTests > 0) {
            System.exit(1);
        }
    }
}
