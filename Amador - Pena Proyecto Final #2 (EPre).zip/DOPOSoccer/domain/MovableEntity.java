package domain;

/**
 * Clase abstracta base para los elementos moviles del juego (Jugadores y Balon).
 * Centraliza las propiedades de posicion, velocidad y operaciones fisicas comunes.
 */
public abstract class MovableEntity {

    // Posicion actual en X y Y

    protected Vector2D position;

    // Velocidad actual en X y Y

    protected Vector2D velocity;

    /**
     * Constructor para inicializar la posicion y velocidad.
     * 
     * @param startX Posicion inicial en X.
     * @param startY Posicion inicial en Y.
     */
    public MovableEntity(double startX, double startY) {
        this.position = new Vector2D(startX, startY);
        this.velocity = new Vector2D(0.0, 0.0);
    }

    /**
     * Retorna el vector de posicion de la entidad.
     * 
     * @return Vector2D de posicion.
     */
    public Vector2D getPosition() {
        return position;
    }

    /**
     * Retorna el vector de velocidad de la entidad.
     * 
     * @return Vector2D de velocidad.
     */
    public Vector2D getVelocity() {
        return velocity;
    }

    /**
     * Retorna la coordenada X actual.
     * 
     * @return Valor de X.
     */
    public double getX() {
        return position.getX();
    }

    /**
     * Retorna la coordenada Y actual.
     * 
     * @return Valor de Y.
     */
    public double getY() {
        return position.getY();
    }

    /**
     * Retorna la velocidad horizontal actual.
     * 
     * @return Velocidad en X.
     */
    public double getVx() {
        return velocity.getX();
    }

    /**
     * Retorna la velocidad vertical actual.
     * 
     * @return Velocidad en Y.
     */
    public double getVy() {
        return velocity.getY();
    }

    /**
     * Cambia la posicion actual de la entidad.
     * 
     * @param x Nueva coordenada X.
     * @param y Nueva coordenada Y.
     */
    public void setPosition(double x, double y) {
        this.position.set(x, y);
    }

    /**
     * Cambia la velocidad actual de la entidad.
     * 
     * @param vx Nueva velocidad en X.
     * @param vy Nueva velocidad en Y.
     */
    public void setVelocity(double vx, double vy) {
        this.velocity.set(vx, vy);
    }

    /**
     * Aplica un impulso sumando velocidad en X y Y.
     * 
     * @param fx Impulso en X.
     * @param fy Impulso en Y.
     */
    public void applyImpulse(double fx, double fy) {
        this.velocity.add(fx, fy);
    }

    /**
     * Calcula la distancia hacia otra entidad movil.
     * 
     * @param other Otra entidad en la cancha.
     * @return Distancia en pixeles.
     */
    public double distanceTo(MovableEntity other) {
        if (other == null || other.getPosition() == null) {
            return Double.MAX_VALUE;
        }
        return this.position.distance(other.getPosition());
    }
}

