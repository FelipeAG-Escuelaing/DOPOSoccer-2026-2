package domain;

/**
 * Modalidad de partido por tiempo reglamentario.
 * Si al terminar el tiempo reglamentario hay empate, el juego entra en muerte subita
 * y el primer gol que se anote define al ganador.
 */
public class TimeMatch extends Match {

    // Duracion por defecto de 60 segundos si no se especifica

    public static final double DEFAULT_DURATION = 60.0;

    // Tiempo total configurado para el partido en segundos

    private double totalDuration;

    // Segundos restantes en el cronometro

    private double timeRemaining;

    /**
     * Constructor por defecto con 60 segundos de duracion.
     * 
     * @param field Cancha del partido.
     * @param player1 Jugador 1.
     * @param player2 Jugador 2.
     */
    public TimeMatch(Field field, Player player1, Player player2) {
        this(field, player1, player2, DEFAULT_DURATION);
    }

    /**
     * Constructor para configurar la duracion en segundos del partido.
     * 
     * @param field Cancha del partido.
     * @param player1 Jugador 1.
     * @param player2 Jugador 2.
     * @param durationSeconds Duracion en segundos.
     */
    public TimeMatch(Field field, Player player1, Player player2, double durationSeconds) {
        super(field, player1, player2);
        // Minimo 10 segundos para pruebas
        this.totalDuration = Math.max(10.0, durationSeconds);
        this.timeRemaining = this.totalDuration;
    }

    /**
     * Retorna la duracion total inicial del partido.
     * 
     * @return Duracion en segundos.
     */
    public double getTotalDuration() {
        return totalDuration;
    }

    /**
     * Retorna los segundos que quedan en el cronometro.
     * 
     * @return Segundos restantes.
     */
    public double getTimeRemaining() {
        return timeRemaining;
    }

    /**
     * Permite fijar el tiempo restante.
     * 
     * @param timeRemaining Nuevos segundos restantes.
     */
    public void setTimeRemaining(double timeRemaining) {
        this.timeRemaining = Math.max(0.0, timeRemaining);
    }

    /**
     * Descuenta el tiempo reglamentario en cada tick si todavia no estamos en muerte subita.
     * Si el tiempo llega a cero y hay empate, se activa la muerte subita.
     * 
     * @param dt Delta time en segundos.
     */
    @Override
    protected void updateMatchSpecificLogic(double dt) {
        // En muerte subita el cronometro no se descuenta
        if (!isSuddenDeath) {
            timeRemaining -= dt;
            if (timeRemaining <= 0.0) {
                timeRemaining = 0.0;
                // Si al agotarse el tiempo hay empate, se activa la muerte subita
                if (score1 == score2) {
                    isSuddenDeath = true;
                }
            }
        }
    }

    /**
     * Verifica si el partido termino por tiempo regular.
     * Si no estan empatados, gana quien tenga mas goles anotados.
     */
    @Override
    protected void checkGameOverConditions() {
        if (timeRemaining <= 0.0 && !isSuddenDeath) {
            if (score1 > score2) {
                // Gano Jugador 1
                finishMatch(player1, player2);
            } else if (score2 > score1) {
                // Gano Jugador 2
                finishMatch(player2, player1);
            }
        }
    }

    /**
     * Retorna el nombre de la modalidad para el encabezado.
     * 
     * @return Texto con la duracion.
     */
    @Override
    public String getMatchTypeName() {
        return "Por Tiempo (" + (int) totalDuration + "s)";
    }
}
