package domain;

import java.util.List;

/**
 * Fachada del Dominio y Controlador de DOPOSoccer.
 * 
 * Es el unico punto de entrada para que la GUI y el Game Loop interactuen con
 * la logica.
 * No tiene dependencias de librerias graficas de Swing o AWT.
 */
public class DOPOSoccer {

    // Partido actualmente en disputa

    private Match currentMatch;

    // Modalidad configurada (PvP o PvC para la version dos)

    private String configuredModality;

    // Tipo de partido configurado (TIME o GOALS)

    private String configuredMatchType;

    // Seleccion nacional del Jugador 1

    private CharacterType configuredP1Char;

    // Seleccion nacional del Jugador 2

    private CharacterType configuredP2Char;

    // Duracion en segundos o limite de goles

    private int configuredTargetValue;

    // Ancho en pixeles de la cancha

    private double configuredFieldWidth;

    // Alto en pixeles de la cancha

    private double configuredFieldHeight;

    /**
     * Constructor que inicia el juego con una partida por defecto lista para jugar.
     */
    public DOPOSoccer() {
        this.configuredModality = "PvP";
        this.configuredMatchType = "TIME";
        this.configuredP1Char = CharacterType.SOUTH_KOREA;
        this.configuredP2Char = CharacterType.CAMEROON;
        this.configuredTargetValue = 60;
        this.configuredFieldWidth = Field.DEFAULT_WIDTH;
        this.configuredFieldHeight = Field.DEFAULT_HEIGHT;

        try {
            configureAndStartMatch(configuredModality, configuredMatchType,
                    configuredP1Char, configuredP2Char,
                    configuredTargetValue, configuredFieldWidth, configuredFieldHeight);
        } catch (DOPOSoccerException e) {
            // No ocurre con los valores por defecto validos
        }
    }

    /**
     * Configura e inicia un nuevo partido con los parametros elegidos en la ventana
     * de configuracion.
     * 
     * @param modality    Modalidad de juego (PvP).
     * @param matchType   Tipo de partido (TIME o GOALS).
     * @param p1Char      Personaje del Jugador 1.
     * @param p2Char      Personaje del Jugador 2.
     * @param targetValue Segundos si es por tiempo o cantidad de goles si es por
     *                    goles.
     * @param fieldWidth  Ancho de resolucion de la cancha.
     * @param fieldHeight Alto de resolucion de la cancha.
     * @throws DOPOSoccerException Si los personajes son nulos o las medidas son
     *                             negativas.
     */
    public void configureAndStartMatch(String modality, String matchType,
            CharacterType p1Char, CharacterType p2Char,
            int targetValue, double fieldWidth, double fieldHeight)
            throws DOPOSoccerException {
        // Validamos que los personajes no vengan nulos
        if (p1Char == null || p2Char == null) {
            throw new DOPOSoccerException(DOPOSoccerException.NULL_CHARACTER);
        }
        // Validamos medidas y metas positivas
        if (fieldWidth <= 0 || fieldHeight <= 0 || targetValue <= 0) {
            throw new DOPOSoccerException(DOPOSoccerException.INVALID_CONFIGURATION);
        }

        this.configuredModality = modality != null ? modality : "PvP";
        this.configuredMatchType = matchType != null ? matchType : "TIME";
        this.configuredP1Char = p1Char;
        this.configuredP2Char = p2Char;
        this.configuredTargetValue = targetValue;
        this.configuredFieldWidth = fieldWidth;
        this.configuredFieldHeight = fieldHeight;

        Field field = new Field(fieldWidth, fieldHeight);
        Player p1 = new Player(1, "Jugador 1 (" + p1Char.getDisplayName() + ")", p1Char,
                200.0, field.getGroundY(), 1.0);
        Player p2 = new Player(2, "Jugador 2 (" + p2Char.getDisplayName() + ")", p2Char,
                fieldWidth - 200.0, field.getGroundY(), -1.0);

        // Instanciamos la subclase correspondiente segun la modalidad
        if ("GOALS".equalsIgnoreCase(matchType)) {
            this.currentMatch = new GoalMatch(field, p1, p2, targetValue);
        } else {
            this.currentMatch = new TimeMatch(field, p1, p2, targetValue);
        }
    }

    /**
     * Reinicia el partido actual volviendo a cargar los mismos parametros que
     * tenia.
     * 
     * @throws DOPOSoccerException Si ocurre un error de inicializacion.
     */
    public void restartCurrentMatch() throws DOPOSoccerException {
        configureAndStartMatch(configuredModality, configuredMatchType,
                configuredP1Char, configuredP2Char,
                configuredTargetValue, configuredFieldWidth, configuredFieldHeight);
    }

    /**
     * Avanza el bucle del juego durante el tiempo delta dt.
     * 
     * @param dt Delta time en segundos.
     */
    public void update(double dt) {
        if (currentMatch != null) {
            currentMatch.update(dt);
        }
    }

    /**
     * Alterna la pausa del partido (si estaba pausado lo reanuda y viceversa).
     */
    public void togglePause() {
        if (currentMatch != null) {
            currentMatch.setPaused(!currentMatch.isPaused());
        }
    }

    /**
     * Cambia directamente el estado de pausa.
     * 
     * @param paused true para pausar, false para continuar.
     */
    public void setPaused(boolean paused) {
        if (currentMatch != null) {
            currentMatch.setPaused(paused);
        }
    }

    // Acciones de Jugador 1

    /**
     * Mueve al Jugador 1 hacia la izquierda.
     */
    public void moveP1Left() {
        if (currentMatch != null && !currentMatch.isPaused()) {
            currentMatch.getPlayer1().moveLeft();
        }
    }

    /**
     * Mueve al Jugador 1 hacia la derecha.
     */
    public void moveP1Right() {
        if (currentMatch != null && !currentMatch.isPaused()) {
            currentMatch.getPlayer1().moveRight();
        }
    }

    /**
     * Detiene el movimiento horizontal del Jugador 1.
     */
    public void stopP1Horizontal() {
        if (currentMatch != null && !currentMatch.isPaused()) {
            currentMatch.getPlayer1().stopHorizontal();
        }
    }

    /**
     * Ordena saltar al Jugador 1.
     */
    public void jumpP1() {
        if (currentMatch != null && !currentMatch.isPaused()) {
            currentMatch.getPlayer1().jump();
        }
    }

    /**
     * Ordena patear al Jugador 1.
     */
    public void kickP1() {
        if (currentMatch != null && !currentMatch.isPaused()) {
            currentMatch.getPlayer1().kick();
        }
    }

    /**
     * Activa el aura de poder de Jugador 1 si la barra esta al 100%.
     * 
     * @throws DOPOSoccerException Si no hay partido activo o la barra no esta
     *                             lista.
     */
    public void powerP1() throws DOPOSoccerException {
        if (currentMatch == null) {
            throw new DOPOSoccerException(DOPOSoccerException.NO_ACTIVE_MATCH);
        }
        if (!currentMatch.isPaused()) {
            currentMatch.getPlayer1().activatePowerAura();
        }
    }

    // Acciones de Jugador 2

    /**
     * Mueve al Jugador 2 hacia la izquierda.
     */
    public void moveP2Left() {
        if (currentMatch != null && !currentMatch.isPaused()) {
            currentMatch.getPlayer2().moveLeft();
        }
    }

    /**
     * Mueve al Jugador 2 hacia la derecha.
     */
    public void moveP2Right() {
        if (currentMatch != null && !currentMatch.isPaused()) {
            currentMatch.getPlayer2().moveRight();
        }
    }

    /**
     * Detiene el movimiento horizontal del Jugador 2.
     */
    public void stopP2Horizontal() {
        if (currentMatch != null && !currentMatch.isPaused()) {
            currentMatch.getPlayer2().stopHorizontal();
        }
    }

    /**
     * Ordena saltar al Jugador 2.
     */
    public void jumpP2() {
        if (currentMatch != null && !currentMatch.isPaused()) {
            currentMatch.getPlayer2().jump();
        }
    }

    /**
     * Ordena patear al Jugador 2.
     */
    public void kickP2() {
        if (currentMatch != null && !currentMatch.isPaused()) {
            currentMatch.getPlayer2().kick();
        }
    }

    /**
     * Activa el aura de poder de Jugador 2 si la barra esta al 100%.
     * 
     * @throws DOPOSoccerException Si no hay partido activo o la barra no esta
     *                             lista.
     */
    public void powerP2() throws DOPOSoccerException {
        if (currentMatch == null) {
            throw new DOPOSoccerException(DOPOSoccerException.NO_ACTIVE_MATCH);
        }
        if (!currentMatch.isPaused()) {
            currentMatch.getPlayer2().activatePowerAura();
        }
    }

    /**
     * Permite comprar una mejora de atributo gastando los puntos acumulados del
     * jugador.
     * 
     * @param playerId 1 para Jugador 1 o 2 para Jugador 2.
     * @param statName Nombre del atributo: speed, jump, kick o survival.
     * @return true si la mejora se aplico exitosamente.
     */
    public boolean upgradeStat(int playerId, String statName) {
        if (currentMatch == null)
            return false;
        Player p = (playerId == 1) ? currentMatch.getPlayer1() : currentMatch.getPlayer2();
        return p != null && p.upgradeStat(statName);
    }

    /**
     * Retorna el partido que se esta jugando actualmente.
     * 
     * @return Objeto Match en disputa.
     */
    public Match getCurrentMatch() {
        return currentMatch;
    }

    /**
     * Indica si hay un partido activo que todavia no ha finalizado.
     * 
     * @return true si se puede seguir jugando.
     */
    public boolean isMatchActive() {
        return currentMatch != null && !currentMatch.isGameOver();
    }

    /**
     * Indica si el partido actual esta en pausa.
     * 
     * @return true si esta pausado.
     */
    public boolean isMatchPaused() {
        return currentMatch != null && currentMatch.isPaused();
    }

    /**
     * Indica si el partido ya llego a su fin.
     * 
     * @return true si ya hubo ganador.
     */
    public boolean isGameOver() {
        return currentMatch != null && currentMatch.isGameOver();
    }

    /**
     * Retorna la lista de errores guardados en la bitacora del dominio.
     * 
     * @return Lista inmutable con las entradas del log.
     */
    public List<String> getDomainErrorLog() {
        return DOPOSoccerException.getErrorLog();
    }
}
