package domain;

/**
 * Vector 2D para manejar posiciones, velocidades y rebotes en el juego.
 * No usamos Point2D de AWT para que el dominio no dependa de librerias graficas.
 */
public class Vector2D {

    // Componente en el eje X (horizontal)

    private double x;

    // Componente en el eje Y (vertical)

    private double y;

    // Constructor por defecto que inicia el vector en el origen (0, 0).

    public Vector2D() {
        this(0.0, 0.0);
    }

    /**
     * Constructor con valores iniciales para X y Y.
     * 
     * @param x Valor inicial en X.
     * @param y Valor inicial en Y.
     */
    public Vector2D(double x, double y) {
        this.x = x;
        this.y = y;
    }

    /**
     * Obtiene el valor actual en X.
     * 
     * @return Componente horizontal X.
     */
    public double getX() {
        return x;
    }

    /**
     * Asigna un nuevo valor a la componente X.
     * 
     * @param x Nuevo valor para X.
     */
    public void setX(double x) {
        this.x = x;
    }

    /**
     * Obtiene el valor actual en Y.
     * 
     * @return Componente vertical Y.
     */
    public double getY() {
        return y;
    }

    /**
     * Asigna un nuevo valor a la componente Y.
     * 
     * @param y Nuevo valor para Y.
     */
    public void setY(double y) {
        this.y = y;
    }

    /**
     * Cambia las dos coordenadas X y Y al mismo tiempo.
     * 
     * @param x Nueva posicion en X.
     * @param y Nueva posicion en Y.
     */
    public void set(double x, double y) {
        this.x = x;
        this.y = y;
    }

    /**
     * Suma un desplazamiento directo a las componentes X y Y.
     * 
     * @param dx Cantidad a sumar en X.
     * @param dy Cantidad a sumar en Y.
     */
    public void add(double dx, double dy) {
        // Sumamos directamente los deltas a cada eje
        this.x += dx;
        this.y += dy;
    }

    /**
     * Suma las componentes de otro vector a este vector.
     * 
     * @param other El otro vector a sumar.
     */
    public void add(Vector2D other) {
        if (other != null) {
            this.x += other.x;
            this.y += other.y;
        }
    }

    /**
     * Resta las componentes de otro vector a este vector.
     * 
     * @param other El otro vector que vamos a restar.
     */
    public void subtract(Vector2D other) {
        if (other != null) {
            this.x -= other.x;
            this.y -= other.y;
        }
    }

    /**
     * Multiplica las componentes del vector por un escalar.
     * 
     * @param scalar Factor numerico para escalar el vector.
     */
    public void multiply(double scalar) {
        // Multiplicamos ambas coordenadas por el escalar
        this.x *= scalar;
        this.y *= scalar;
    }

    /**
     * Calcula la magnitud o longitud del vector.
     * 
     * @return Longitud del vector.
     */
    public double magnitude() {
        // Usamos Pitagoras para hallar la norma
        return Math.sqrt(x * x + y * y);
    }

    /**
     * Calcula la distancia en linea recta hacia otro vector.
     * 
     * @param other El vector destino.
     * @return Distancia euclidiana entre ambos vectores.
     */
    public double distance(Vector2D other) {
        if (other == null) {
            return 0.0;
        }
        // Diferencia entre coordenadas
        double dx = this.x - other.x;
        double dy = this.y - other.y;
        return Math.sqrt(dx * dx + dy * dy);
    }

    /**
     * Devuelve un vector unitario con la misma direccion pero con magnitud igual a 1.
     * 
     * @return Nuevo vector normalizado.
     */
    public Vector2D normalize() {
        double mag = magnitude();
        // Si la magnitud es muy pequena devolvemos un vector en cero para evitar division por cero
        if (mag > 1e-6) {
            return new Vector2D(this.x / mag, this.y / mag);
        }
        return new Vector2D(0.0, 0.0);
    }

    /**
     * Crea y devuelve una copia exacta de este vector.
     * 
     * @return Nuevo objeto Vector2D con los mismos valores de X y Y.
     */
    public Vector2D copy() {
        return new Vector2D(this.x, this.y);
    }

    /**
     * Muestra las coordenadas del vector en formato legible.
     * 
     * @return Texto con formato (x, y).
     */
    @Override
    public String toString() {
        return String.format("(%.2f, %.2f)", x, y);
    }
}
