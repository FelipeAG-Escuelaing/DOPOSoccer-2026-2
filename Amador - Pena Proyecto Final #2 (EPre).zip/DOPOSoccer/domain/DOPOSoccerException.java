package domain;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * Excepcion personalizada para controlar errores y reglas de negocio del juego.
 * Guarda un registro de errores para que podamos revisar que fallo.
 */
public class DOPOSoccerException extends Exception {

    // Mensaje de error para configuraciones que no son validas

    public static final String INVALID_CONFIGURATION = "Configuracion de partido no valida.";

    // Mensaje de error cuando el partido ya termino y se intenta hacer una jugada

    public static final String MATCH_ALREADY_FINISHED = "El partido ya finalizo.";

    // Mensaje de error cuando se quiere disparar el poder sin tener la barra al 100%

    public static final String POWER_NOT_READY = "El tiro de poder todavia no esta lleno al 100%.";

    // Mensaje de error cuando el jugador esta aturdido y no puede actuar

    public static final String PLAYER_STUNNED = "El jugador esta aturdido y no puede realizar acciones.";

    // Mensaje de error cuando se pide una accion pero no hay partido activo

    public static final String NO_ACTIVE_MATCH = "No hay ningun partido en juego actualmente.";

    // Mensaje de error para acciones no permitidas en el estado actual

    public static final String INVALID_PLAYER_ACTION = "Accion no permitida para el jugador en este momento.";

    // Mensaje de error cuando el personaje seleccionado llega nulo

    public static final String NULL_CHARACTER = "El personaje seleccionado no puede ser nulo.";

    // Lista estatica donde guardamos la bitacora de errores ocurridos

    private static final List<String> ERROR_LOG = new ArrayList<>();

    /**
     * Constructor basico con solo mensaje de error.
     * 
     * @param message Texto con la descripcion del problema.
     */
    public DOPOSoccerException(String message) {
        super(message);
        logError(message);
    }

    /**
     * Constructor con mensaje y causa original del error.
     * 
     * @param message Texto con la descripcion del problema.
     * @param cause Causa original de la excepcion.
     */
    public DOPOSoccerException(String message, Throwable cause) {
        super(message, cause);
        logError(message + " | Causa: " + (cause != null ? cause.getMessage() : "Desconocida"));
    }

    /**
     * Metodo interno para agregar un mensaje a la lista de errores con la marca de tiempo.
     * 
     * @param entry Mensaje de texto a guardar en el log.
     */
    private static void logError(String entry) {
        // Guardamos el tiempo en milisegundos y el mensaje
        ERROR_LOG.add(System.currentTimeMillis() + " - " + entry);
    }

    /**
     * Retorna una copia de solo lectura con todos los errores registrados.
     * 
     * @return Lista inmutable con las lineas de la bitacora de errores.
     */
    public static List<String> getErrorLog() {
        return Collections.unmodifiableList(new ArrayList<>(ERROR_LOG));
    }

    /**
     * Limpia la lista de errores registrados. Nos sirve mucho para las pruebas unitarias.
     */
    public static void clearErrorLog() {
        ERROR_LOG.clear();
    }
}
