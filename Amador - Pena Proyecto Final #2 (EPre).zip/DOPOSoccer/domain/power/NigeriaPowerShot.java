package domain.power;

import domain.AirKnockoutState;
import domain.Ball;
import domain.Match;
import domain.Player;

/**
 * Tiro de poder de Nigeria (Anexo 1 del documento).
 * - Nombre: Tornado rebotador.
 * - Trayectoria: Disparo a ras de suelo con remolino que genera rebotes
 * rapidos.
 * - Efecto en el rival: Inconsciente (lanzado al aire sin poder moverse, saltar
 * ni patear por 3 segundos).
 * - Danio base: 40 puntos.
 */
public class NigeriaPowerShot extends PowerShot {

    public static final double BASE_DAMAGE = 40.0;
    public static final double DURATION = 3.0;

    public NigeriaPowerShot() {
        super();
    }

    @Override
    public void applyPowerShotToBall(Match match, Player caster, Player opponent, Ball ball) {
        double dir = caster.getFacingDirection();
        ball.applyImpulse(dir * 650.0, 150.0);
        ball.setPowerShot(this, caster, getEffectName(), DURATION);
        ball.setLastKicker(caster);
    }

    @Override
    protected void applyNegativeState(Player caster, Player opponent, Ball ball) {
        double dir = caster.getFacingDirection();
        opponent.getVelocity().set(dir * 100.0, -500.0);
        opponent.setState(new AirKnockoutState(DURATION));
    }

    @Override
    public String getPowerName() {
        return "Tornado (Nigeria)";
    }

    @Override
    public String getEffectName() {
        return "TORNADO";
    }

    @Override
    public double getBaseDamage() {
        return BASE_DAMAGE;
    }

    @Override
    public double getDuration() {
        return DURATION;
    }
}
