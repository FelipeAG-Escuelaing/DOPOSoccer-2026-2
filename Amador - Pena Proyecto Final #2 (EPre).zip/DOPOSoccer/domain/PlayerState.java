package domain;

/**
 * Interfaz base para el patron State. Modela el estado fisico o mental del jugador
 * (Normal, Aturdido a cero de vida, Electrocutado, Confundido, etc.).
 */
public interface PlayerState {

    /**
     * Actualiza el temporizador del estado en cada cuadro del juego.
     * 
     * @param dt Tiempo transcurrido en segundos.
     * @param player Jugador que tiene aplicado este estado.
     */
    public void update(double dt, Player player);

    /**
     * Indica si el jugador puede moverse hacia los lados con las teclas.
     * 
     * @return true si se puede desplazar, false si esta bloqueado.
     */
    public boolean canMove();

    /**
     * Indica si el jugador tiene permitido saltar.
     * 
     * @return true si puede saltar, false si no.
     */
    public boolean canJump();

    /**
     * Indica si el jugador puede patear el balon o al rival.
     * 
     * @return true si tiene habilitada la patada.
     */
    public boolean canKick();

    /**
     * Indica si el jugador puede activar el aura de su tiro de poder.
     * 
     * @return true si puede activar el poder.
     */
    public boolean canUsePower();

    /**
     * Factor de multiplicacion de la velocidad al caminar (ej: 0.5 para Camerun).
     * 
     * @return Multiplicador de velocidad (1.0 normal, 0.5 lento, 0.0 quieto).
     */
    public double getSpeedMultiplier();

    /**
     * Indica si las teclas de direccion estan invertidas (poder de USA).
     * 
     * @return true si izquierda va a derecha y viceversa.
     */
    public boolean isInvertedControls();

    /**
     * Retorna el nombre en texto del estado para mostrar en el HUD o pruebas.
     * 
     * @return Nombre del estado actual.
     */
    public String getStateName();

    /**
     * Retorna el tiempo en segundos que le queda a este efecto temporal.
     * 
     * @return Segundos restantes del estado.
     */
    public double getRemainingTime();
}
