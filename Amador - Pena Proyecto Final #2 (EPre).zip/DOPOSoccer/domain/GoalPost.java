package domain;

/**
 * Representa la porteria del campo con sus postes, travesano y red.
 * Se encarga de verificar geometricamente si el balon entro para contar gol.
 */
public class GoalPost {

    // Lado del campo donde esta ubicado el arco

    public enum Side { LEFT, RIGHT }

    // Lado del arco (izquierdo o derecho)

    private final Side side;

    // Posicion X de la esquina superior izquierda del arco

    private final double x;

    // Posicion Y de la parte superior del arco

    private final double y;

    // Ancho o profundidad de la porteria

    private final double width;

    // Altura total de la porteria

    private final double height;

    // Altura en Y del travesano horizontal

    private final double crossbarY;

    /**
     * Constructor con las dimensiones y posicion del arco en la cancha.
     * 
     * @param side Lado del campo (LEFT o RIGHT).
     * @param x Posicion X de inicio.
     * @param y Posicion Y superior.
     * @param width Profundidad del arco.
     * @param height Altura de la porteria.
     */
    public GoalPost(Side side, double x, double y, double width, double height) {
        this.side = side;
        this.x = x;
        this.y = y;
        this.width = width;
        this.height = height;
        this.crossbarY = y;
    }

    /**
     * Retorna de que lado de la cancha es esta porteria.
     * 
     * @return Side.LEFT o Side.RIGHT.
     */
    public Side getSide() {
        return side;
    }

    /**
     * Retorna la posicion horizontal X del arco.
     * 
     * @return Coordenada X.
     */
    public double getX() {
        return x;
    }

    /**
     * Retorna la posicion vertical Y del arco.
     * 
     * @return Coordenada Y.
     */
    public double getY() {
        return y;
    }

    /**
     * Retorna el ancho del arco.
     * 
     * @return Ancho en pixeles.
     */
    public double getWidth() {
        return width;
    }

    /**
     * Retorna el alto del arco.
     * 
     * @return Altura en pixeles.
     */
    public double getHeight() {
        return height;
    }

    /**
     * Retorna la coordenada Y del travesano.
     * 
     * @return Altura del poste superior.
     */
    public double getCrossbarY() {
        return crossbarY;
    }

    /**
     * Revisa si el balon cruzo completamente la linea de gol entre los tres palos.
     * Los balones falsos generados por el poder de USA no cuentan como gol.
     * 
     * @param ball El balon a evaluar.
     * @return true si es gol valido, false si no entro o es ilusion.
     */
    public boolean isGoal(Ball ball) {
        // Los balones que son ilusiones no pueden anotar gol segun la regla
        if (ball == null || ball.isIllusion()) {
            return false;
        }

        double bx = ball.getPosition().getX();
        double by = ball.getPosition().getY();
        double br = ball.getRadius();

        // El balon debe estar por debajo del travesano y arriba del suelo
        boolean withinVerticalOpening = (by >= crossbarY) && (by <= y + height + br);
        if (!withinVerticalOpening) {
            return false;
        }

        // Comprobamos segun el lado si cruzo la linea completamente
        if (side == Side.LEFT) {
            // En el arco izquierdo, el borde derecho del balon debe pasar la linea interior
            return (bx + br <= x + width);
        } else {
            // En el arco derecho, el borde izquierdo del balon debe superar la linea de gol
            return (bx - br >= x);
        }
    }
}
