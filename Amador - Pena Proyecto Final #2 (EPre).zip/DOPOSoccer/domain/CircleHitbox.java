package domain;

/**
 * Hitbox circular que usamos para detectar colisiones entre el balon,
 * la cabeza y cuerpo de los jugadores, y los postes de la cancha.
 */
public class CircleHitbox {

    // Vector con el centro del circulo en la cancha

    private Vector2D center;

    // Radio del circulo de colision

    private double radius;

    /**
     * Constructor para definir una hitbox circular con centro y radio.
     * 
     * @param center Coordenadas del punto central.
     * @param radius Tamano del radio del circulo.
     */
    public CircleHitbox(Vector2D center, double radius) {
        this.center = center;
        this.radius = radius;
    }

    /**
     * Retorna el vector que representa el centro del circulo.
     * 
     * @return Vector2D con la posicion central.
     */
    public Vector2D getCenter() {
        return center;
    }

    /**
     * Retorna el radio de la hitbox.
     * 
     * @return Valor del radio.
     */
    public double getRadius() {
        return radius;
    }

    /**
     * Permite cambiar el radio de la hitbox.
     * 
     * @param radius Nuevo radio.
     */
    public void setRadius(double radius) {
        this.radius = radius;
    }

    /**
     * Revisa si este circulo choca con otro circulo comparando la distancia entre centros.
     * 
     * @param other La otra hitbox circular a comparar.
     * @return true si hay colision, false si no se tocan.
     */
    public boolean intersects(CircleHitbox other) {
        if (other == null) {
            return false;
        }
        // Calculamos la distancia al cuadrado entre ambos centros para no sacar raiz
        double dx = center.getX() - other.center.getX();
        double dy = center.getY() - other.center.getY();
        double distSq = dx * dx + dy * dy;

        // Suma de los radios al cuadrado
        double radSum = this.radius + other.radius;
        // Si la distancia entre centros es menor o igual a la suma de radios, hay choque
        return distSq <= (radSum * radSum);
    }

    /**
     * Revisa si este circulo colisiona con un rectangulo alineado, como el travesano del arco.
     * 
     * @param rx Posicion X izquierda del rectangulo.
     * @param ry Posicion Y superior del rectangulo.
     * @param rw Ancho del rectangulo.
     * @param rh Alto del rectangulo.
     * @return true si el circulo intersecta el rectangulo.
     */
    public boolean intersectsRect(double rx, double ry, double rw, double rh) {
        // Buscamos el punto del rectangulo mas cercano al centro de nuestro circulo
        double closestX = Math.max(rx, Math.min(center.getX(), rx + rw));
        double closestY = Math.max(ry, Math.min(center.getY(), ry + rh));

        // Distancia entre el centro del circulo y ese punto mas cercano
        double distanceX = center.getX() - closestX;
        double distanceY = center.getY() - closestY;

        // Comprobamos si esa distancia es menor o igual al radio al cuadrado
        return (distanceX * distanceX + distanceY * distanceY) <= (radius * radius);
    }
}
