package domain;

/**
 * Estado regular del jugador. Todas las acciones estan permitidas y no hay penalizaciones.
 */
public class NormalState implements PlayerState {

    /**
     * En estado normal no hay ningun temporizador que descontar.
     * 
     * @param dt Tiempo transcurrido en segundos.
     * @param player Jugador en estado normal.
     */
    @Override
    public void update(double dt, Player player) {
        // No hay cuenta regresiva en estado normal
    }

    /**
     * El jugador se puede mover con normalidad.
     * 
     * @return true siempre.
     */
    @Override
    public boolean canMove() {
        return true;
    }

    /**
     * El jugador puede saltar si esta en el suelo.
     * 
     * @return true siempre.
     */
    @Override
    public boolean canJump() {
        return true;
    }

    /**
     * El jugador puede patear.
     * 
     * @return true siempre.
     */
    @Override
    public boolean canKick() {
        return true;
    }

    /**
     * El jugador puede activar su tiro de poder si la barra esta llena.
     * 
     * @return true siempre.
     */
    @Override
    public boolean canUsePower() {
        return true;
    }

    /**
     * Multiplicador de velocidad al 100%.
     * 
     * @return 1.0.
     */
    @Override
    public double getSpeedMultiplier() {
        return 1.0;
    }

    /**
     * Los controles no estan invertidos.
     * 
     * @return false.
     */
    @Override
    public boolean isInvertedControls() {
        return false;
    }

    /**
     * Nombre descriptivo del estado.
     * 
     * @return Texto NORMAL.
     */
    @Override
    public String getStateName() {
        return "NORMAL";
    }

    /**
     * En estado normal el tiempo restante es 0.
     * 
     * @return 0.0.
     */
    @Override
    public double getRemainingTime() {
        return 0.0;
    }
}
