package domain;

/**
 * Clase abstracta base para los estados que tienen un temporizador y duracion finita.
 * Implementa la logica de conteo regresivo y retorno al estado normal.
 */
public abstract class TimedState implements PlayerState {

    // Segundos restantes de duracion del estado

    protected double remainingTime;

    /**
     * Constructor base que recibe la duracion en segundos.
     * 
     * @param duration Duracion del estado en segundos.
     */
    public TimedState(double duration) {
        this.remainingTime = Math.max(0.0, duration);
    }

    /**
     * Descuenta el tiempo restante en cada tick. Al llegar a cero invoca onExpire.
     * 
     * @param dt Tiempo transcurrido en segundos.
     * @param player Jugador afectado por este estado.
     */
    @Override
    public void update(double dt, Player player) {
        remainingTime -= dt;
        if (remainingTime <= 0.0) {
            remainingTime = 0.0;
            onExpire(player);
        }
    }

    /**
     * Accion ejecutada cuando el tiempo del estado llega a cero.
     * Por defecto regresa al jugador a NormalState.
     * 
     * @param player Jugador que finaliza el estado temporal.
     */
    protected void onExpire(Player player) {
        player.setState(new NormalState());
    }

    @Override
    public boolean canMove() {
        return true;
    }

    @Override
    public boolean canJump() {
        return true;
    }

    @Override
    public boolean canKick() {
        return true;
    }

    @Override
    public boolean canUsePower() {
        return false;
    }

    @Override
    public double getSpeedMultiplier() {
        return 1.0;
    }

    @Override
    public boolean isInvertedControls() {
        return false;
    }

    @Override
    public double getRemainingTime() {
        return remainingTime;
    }
}

