package presentation;

import domain.CharacterType;
import domain.DOPOSoccer;
import domain.GoalMatch;
import domain.Match;
import domain.Player;
import domain.TimeMatch;

import javax.swing.JPanel;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.GradientPaint;
import java.awt.RenderingHints;

/**
 * Panel superior que dibuja el marcador de goles, tiempo restante,
 * estado actual del partido y nombres de los competidores.
 */
public class ScoreboardPanel extends GamePanel {

    // Fuente grande para los numeros del marcador.

    private final Font scoreFont;

    // Fuente para los nombres y etiquetas de jugadores.

    private final Font labelFont;

    // Fuente para el reloj central y avisos de estado.

    private final Font statusFont;

    /**
     * Constructor del panel de marcador.
     * 
     * @param facade Fachada principal del juego.
     */
    public ScoreboardPanel(DOPOSoccer facade) {
        super(facade);
        setPreferredSize(new Dimension(1000, 75));
        setBackground(new Color(20, 24, 30));

        this.scoreFont = new Font("Arial", Font.BOLD, 36);
        this.labelFont = new Font("SansSerif", Font.BOLD, 14);
        this.statusFont = new Font("SansSerif", Font.BOLD, 16);
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        Graphics2D g2 = (Graphics2D) g;
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        g2.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);

        int w = getWidth();
        int h = getHeight();

        // Fondo degradado
        GradientPaint gp = new GradientPaint(0, 0, new Color(15, 20, 32), 0, h, new Color(30, 38, 55));
        g2.setPaint(gp);
        g2.fillRect(0, 0, w, h);

        // Borde inferior
        g2.setColor(new Color(0, 180, 216));
        g2.fillRect(0, h - 3, w, 3);

        Match match = facade.getCurrentMatch();
        if (match == null) {
            return;
        }

        Player p1 = match.getPlayer1();
        Player p2 = match.getPlayer2();

        // Bloque de Jugador 1 a la izquierda
        drawPlayerBlock(g2, 20, 10, p1, match.getScore1(), true);

        // Bloque central de tiempo o limite
        drawCenterBlock(g2, w / 2, h, match);

        // Bloque de Jugador 2 a la derecha
        drawPlayerBlock(g2, w - 240, 10, p2, match.getScore2(), false);
    }

    /**
     * Dibuja los datos individuales de un jugador en el marcador.
     */
    private void drawPlayerBlock(Graphics2D g2, int x, int y, Player player, int score, boolean isPlayer1) {
        if (player == null)
            return;

        CharacterType type = player.getCharacterType();
        Color teamColor = getTeamColor(type);

        // Caja de color identificador
        g2.setColor(teamColor);
        g2.fillRoundRect(x, y + 4, 34, 24, 6, 6);
        g2.setColor(Color.WHITE);
        g2.drawRoundRect(x, y + 4, 34, 24, 6, 6);

        // Codigo del pais
        g2.setFont(new Font("SansSerif", Font.BOLD, 11));
        String code = getCountryCode(type);
        g2.drawString(code, x + 6, y + 20);

        // Nombre del jugador
        g2.setColor(Color.WHITE);
        g2.setFont(labelFont);
        g2.drawString(player.getName(), x + 44, y + 20);

        // Marcador numerico
        g2.setFont(scoreFont);
        g2.setColor(new Color(255, 215, 0));
        String scoreStr = String.valueOf(score);
        if (isPlayer1) {
            g2.drawString(scoreStr, x + 160, y + 44);
        } else {
            g2.drawString(scoreStr, x + 5, y + 44);
        }
    }

    /**
     * Dibuja el bloque central con el resultado actual y el tiempo restante.
     */
    private void drawCenterBlock(Graphics2D g2, int centerX, int h, Match match) {
        String scoreDisplay = match.getScore1() + "  -  " + match.getScore2();
        g2.setFont(scoreFont);
        g2.setColor(Color.WHITE);
        int strW = g2.getFontMetrics().stringWidth(scoreDisplay);
        g2.drawString(scoreDisplay, centerX - strW / 2, 42);

        g2.setFont(statusFont);
        String centerInfo;
        if (match instanceof TimeMatch) {
            TimeMatch tm = (TimeMatch) match;
            if (tm.isSuddenDeath()) {
                g2.setColor(new Color(255, 75, 75));
                centerInfo = "MUERTE SUBITA";
            } else {
                g2.setColor(new Color(100, 220, 255));
                int secs = (int) Math.ceil(tm.getTimeRemaining());
                int m = secs / 60;
                int s = secs % 60;
                centerInfo = String.format("%02d:%02d", m, s);
            }
        } else if (match instanceof GoalMatch) {
            GoalMatch gm = (GoalMatch) match;
            g2.setColor(new Color(100, 220, 255));
            centerInfo = "Limite: " + gm.getGoalLimit() + " Goles";
        } else {
            centerInfo = "DOPOSoccer";
        }

        int infoW = g2.getFontMetrics().stringWidth(centerInfo);
        g2.drawString(centerInfo, centerX - infoW / 2, 64);

        if (match.isGameOver()) {
            drawStatusPill(g2, centerX, 12, "FINALIZADO (+100/+25 pts)", new Color(220, 53, 69));
        } else if (match.getGoalCelebrationTimer() > 0) {
            drawStatusPill(g2, centerX, 12, "GOL", new Color(40, 167, 69));
        } else if (match.isPaused()) {
            drawStatusPill(g2, centerX, 12, "PAUSA", new Color(255, 193, 7));
        }
    }

    /**
     * Dibuja una capsula visual de aviso de estado sobre el marcador.
     */
    private void drawStatusPill(Graphics2D g2, int centerX, int y, String text, Color bg) {
        g2.setFont(new Font("SansSerif", Font.BOLD, 12));
        int tw = g2.getFontMetrics().stringWidth(text);
        int pw = tw + 20;
        int ph = 18;
        int px = centerX - pw / 2;

        g2.setColor(bg);
        g2.fillRoundRect(px, y - 10, pw, ph, 10, 10);
        g2.setColor(Color.WHITE);
        g2.drawString(text, px + 10, y + 3);
    }

    /**
     * Retorna el color principal del pais seleccionado.
     */
    private Color getTeamColor(CharacterType type) {
        if (type == null)
            return Color.GRAY;
        switch (type) {
            case SOUTH_KOREA:
                return new Color(20, 100, 220);
            case CAMEROON:
                return new Color(30, 150, 60);
            case NIGERIA:
                return new Color(0, 120, 50);
            case USA:
                return new Color(180, 20, 30);
            default:
                return Color.DARK_GRAY;
        }
    }

    /**
     * Retorna la abreviatura de 3 letras del pais.
     */
    private String getCountryCode(CharacterType type) {
        if (type == null)
            return "KOR";
        switch (type) {
            case SOUTH_KOREA:
                return "KOR";
            case CAMEROON:
                return "CMR";
            case NIGERIA:
                return "NGA";
            case USA:
                return "USA";
            default:
                return "DOP";
        }
    }
}
