package presentation;

import domain.DOPOSoccer;
import domain.DOPOSoccerException;

import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.util.HashSet;
import java.util.Set;

/**
 * Adaptador de teclado que gestiona los eventos de entrada para ambos jugadores
 * en modo PvP simultaneo. Registra teclas activas para evitar retrasos del sistema operativo.
 */
public class GameKeyController extends KeyAdapter {

    // Fachada del dominio para comunicar las acciones del teclado.

    private final DOPOSoccer facade;

    // Conjunto de codigos de teclas que permanecen presionadas actualmente.

    private final Set<Integer> pressedKeys;

    /**
     * Constructor del controlador de teclado.
     * 
     * @param facade Fachada principal del juego.
     */
    public GameKeyController(DOPOSoccer facade) {
        this.facade = facade;
        this.pressedKeys = new HashSet<>();
    }

    @Override
    public void keyPressed(KeyEvent e) {
        int code = e.getKeyCode();
        pressedKeys.add(code);

        // Teclas de accion inmediata del Jugador 1
        if (code == KeyEvent.VK_W) {
            facade.jumpP1();
        } else if (code == KeyEvent.VK_J) {
            facade.kickP1();
        } else if (code == KeyEvent.VK_K) {
            try {
                facade.powerP1();
            } catch (DOPOSoccerException ex) {
                // Se ignora si el poder aun no esta cargado al maximo
            }
        }

        // Teclas de accion inmediata del Jugador 2
        if (code == KeyEvent.VK_UP) {
            facade.jumpP2();
        } else if (code == KeyEvent.VK_L || code == KeyEvent.VK_NUMPAD1) {
            facade.kickP2();
        } else if (code == KeyEvent.VK_P || code == KeyEvent.VK_NUMPAD2) {
            try {
                facade.powerP2();
            } catch (DOPOSoccerException ex) {
                // Se ignora si el poder aun no esta cargado al maximo
            }
        }

        // Control general de partida
        if (code == KeyEvent.VK_SPACE) {
            facade.togglePause();
        } else if (code == KeyEvent.VK_R) {
            try {
                facade.restartCurrentMatch();
            } catch (DOPOSoccerException ex) {
                // Se ignora si no hay partida que reiniciar
            }
        }
    }

    @Override
    public void keyReleased(KeyEvent e) {
        int code = e.getKeyCode();
        pressedKeys.remove(code);

        // Frenar al soltar teclas horizontales
        if (code == KeyEvent.VK_A || code == KeyEvent.VK_D) {
            if (!pressedKeys.contains(KeyEvent.VK_A) && !pressedKeys.contains(KeyEvent.VK_D)) {
                facade.stopP1Horizontal();
            }
        }
        if (code == KeyEvent.VK_LEFT || code == KeyEvent.VK_RIGHT) {
            if (!pressedKeys.contains(KeyEvent.VK_LEFT) && !pressedKeys.contains(KeyEvent.VK_RIGHT)) {
                facade.stopP2Horizontal();
            }
        }
    }

    /**
     * Procesa las teclas continuas de movimiento en cada cuadro de animacion.
     */
    public void processContinuousInput() {
        if (facade.isMatchPaused() || facade.isGameOver()) {
            return;
        }

        // Movimiento Jugador 1 (A y D)
        boolean p1Left = pressedKeys.contains(KeyEvent.VK_A);
        boolean p1Right = pressedKeys.contains(KeyEvent.VK_D);
        if (p1Left && !p1Right) {
            facade.moveP1Left();
        } else if (p1Right && !p1Left) {
            facade.moveP1Right();
        }

        // Movimiento Jugador 2 (Flechas izquierda y derecha)
        boolean p2Left = pressedKeys.contains(KeyEvent.VK_LEFT);
        boolean p2Right = pressedKeys.contains(KeyEvent.VK_RIGHT);
        if (p2Left && !p2Right) {
            facade.moveP2Left();
        } else if (p2Right && !p2Left) {
            facade.moveP2Right();
        }
    }

    /**
     * Limpia el registro de teclas activas al pausar o cambiar de foco.
     */
    public void clearPressedKeys() {
        pressedKeys.clear();
    }
}
