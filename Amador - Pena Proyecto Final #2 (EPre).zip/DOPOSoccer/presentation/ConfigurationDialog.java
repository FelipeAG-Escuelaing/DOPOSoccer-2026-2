package presentation;

import domain.CharacterStats;
import domain.CharacterType;
import domain.DOPOSoccer;
import domain.DOPOSoccerException;

import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

/**
 * Cuadro de dialogo para configurar los parametros de una nueva partida:
 * modalidad, tipo de partido, personajes, resolucion y vista previa de
 * estadisticas.
 */
public class ConfigurationDialog extends JDialog {

    /**
     * Fachada del dominio para aplicar la configuracion inicial.
     */
    private final DOPOSoccer facade;

    private JComboBox<String> comboModality;
    private JComboBox<String> comboCpuProfile;
    private JComboBox<String> comboMatchType;
    private JComboBox<String> comboTargetValue;
    private JComboBox<CharacterType> comboP1Character;
    private JComboBox<CharacterType> comboP2Character;
    private JComboBox<String> comboResolution;

    private JLabel lblP1Stats;
    private JLabel lblP2Stats;

    /**
     * Constructor del dialogo de configuracion.
     * 
     * @param parent Ventana principal propietaria del dialogo.
     * @param facade Fachada principal del juego.
     */
    public ConfigurationDialog(JFrame parent, DOPOSoccer facade) {
        super(parent, "DOPOSoccer - Configuracion de Partida", true);
        this.facade = facade;

        initComponents();
        pack();
        setLocationRelativeTo(parent);
    }

    /**
     * Inicializa los componentes de seleccion y previsualizacion.
     */
    private void initComponents() {
        setLayout(new BorderLayout(10, 10));
        getContentPane().setBackground(new Color(24, 28, 36));

        // Cabecera superior
        JPanel headerPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
        headerPanel.setBackground(new Color(15, 20, 30));
        JLabel titleLabel = new JLabel("CONFIGURACION DE PARTIDO - DOPOSOCCER 2026-2");
        titleLabel.setFont(new Font("Arial", Font.BOLD, 17));
        titleLabel.setForeground(new Color(0, 200, 255));
        headerPanel.add(titleLabel);
        add(headerPanel, BorderLayout.NORTH);

        // Panel central con formularios
        JPanel centerPanel = new JPanel();
        centerPanel.setLayout(new BoxLayout(centerPanel, BoxLayout.Y_AXIS));
        centerPanel.setBackground(new Color(24, 28, 36));
        centerPanel.setBorder(BorderFactory.createEmptyBorder(10, 20, 10, 20));

        // Modalidad
        JPanel modalityPanel = createRowPanel("Modalidad:");
        String[] modalities = { "Jugador vs. Jugador (Mismo Teclado)", "Jugador vs. Maquina (Alcance Version Dos)" };
        comboModality = new JComboBox<>(modalities);

        String[] cpuProfiles = { "Torpe (Al azar)", "Ofensiva (Prioridad anotar)", "Defensiva (Defender arco)",
                "Experta (Adaptativa)" };
        comboCpuProfile = new JComboBox<>(cpuProfiles);
        comboCpuProfile.setEnabled(false);

        comboModality.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (comboModality.getSelectedIndex() == 1) {
                    comboCpuProfile.setEnabled(true);
                    JOptionPane.showMessageDialog(ConfigurationDialog.this,
                            "Nota de Alcance: La modalidad Jugador vs. Maquina corresponde a la Version Dos.\n"
                                    + "En esta Version Uno se ejecutara en modo Jugador vs. Jugador.",
                            "Alcance Oficial Version Uno", JOptionPane.INFORMATION_MESSAGE);
                    comboModality.setSelectedIndex(0);
                    comboCpuProfile.setEnabled(false);
                }
            }
        });
        modalityPanel.add(comboModality);
        modalityPanel.add(new JLabel(" Perfil CPU: "));
        modalityPanel.add(comboCpuProfile);
        centerPanel.add(modalityPanel);

        // Tipo de Partido
        JPanel matchTypePanel = createRowPanel("Tipo de Partido:");
        String[] matchTypes = { "Por Tiempo (Muerte Subita al empatar)", "Por Goles (Limite predefinido)" };
        comboMatchType = new JComboBox<>(matchTypes);
        matchTypePanel.add(comboMatchType);
        centerPanel.add(matchTypePanel);

        // Duracion o Limite de Goles
        JPanel targetPanel = createRowPanel("Duracion / Goles:");
        comboTargetValue = new JComboBox<>(new String[] { "1 Minuto (60s)", "2 Minutos (120s)", "30 Segundos" });
        comboMatchType.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                comboTargetValue.removeAllItems();
                if (comboMatchType.getSelectedIndex() == 0) {
                    comboTargetValue.addItem("1 Minuto (60s)");
                    comboTargetValue.addItem("2 Minutos (120s)");
                    comboTargetValue.addItem("30 Segundos");
                } else {
                    comboTargetValue.addItem("3 Goles");
                    comboTargetValue.addItem("5 Goles");
                    comboTargetValue.addItem("7 Goles");
                }
            }
        });
        targetPanel.add(comboTargetValue);
        centerPanel.add(targetPanel);

        // 4. Seleccion de Personajes
        JPanel charsPanel = new JPanel(new GridLayout(1, 2, 15, 0));
        charsPanel.setBackground(new Color(24, 28, 36));

        // Jugador 1
        JPanel p1Panel = new JPanel();
        p1Panel.setLayout(new BoxLayout(p1Panel, BoxLayout.Y_AXIS));
        p1Panel.setBackground(new Color(32, 38, 50));
        p1Panel.setBorder(BorderFactory.createTitledBorder(BorderFactory.createLineBorder(new Color(0, 180, 216)),
                "Jugador 1 [W, A, D, J, K]", 0, 0, new Font("SansSerif", Font.BOLD, 12), Color.WHITE));

        comboP1Character = new JComboBox<>(CharacterType.values());
        comboP1Character.setSelectedItem(CharacterType.SOUTH_KOREA);
        lblP1Stats = new JLabel();
        lblP1Stats.setForeground(Color.LIGHT_GRAY);
        lblP1Stats.setFont(new Font("Monospaced", Font.PLAIN, 11));
        updateStatsPreview(CharacterType.SOUTH_KOREA, lblP1Stats);

        comboP1Character.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                CharacterType sel = (CharacterType) comboP1Character.getSelectedItem();
                updateStatsPreview(sel, lblP1Stats);
            }
        });
        p1Panel.add(comboP1Character);
        p1Panel.add(Box.createVerticalStrut(8));
        p1Panel.add(lblP1Stats);
        charsPanel.add(p1Panel);

        // Jugador 2
        JPanel p2Panel = new JPanel();
        p2Panel.setLayout(new BoxLayout(p2Panel, BoxLayout.Y_AXIS));
        p2Panel.setBackground(new Color(32, 38, 50));
        p2Panel.setBorder(BorderFactory.createTitledBorder(BorderFactory.createLineBorder(new Color(255, 90, 95)),
                "Jugador 2 [Flechas, L, P]", 0, 0, new Font("SansSerif", Font.BOLD, 12), Color.WHITE));

        comboP2Character = new JComboBox<>(CharacterType.values());
        comboP2Character.setSelectedItem(CharacterType.CAMEROON);
        lblP2Stats = new JLabel();
        lblP2Stats.setForeground(Color.LIGHT_GRAY);
        lblP2Stats.setFont(new Font("Monospaced", Font.PLAIN, 11));
        updateStatsPreview(CharacterType.CAMEROON, lblP2Stats);

        comboP2Character.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                CharacterType sel = (CharacterType) comboP2Character.getSelectedItem();
                updateStatsPreview(sel, lblP2Stats);
            }
        });
        p2Panel.add(comboP2Character);
        p2Panel.add(Box.createVerticalStrut(8));
        p2Panel.add(lblP2Stats);
        charsPanel.add(p2Panel);

        centerPanel.add(Box.createVerticalStrut(8));
        centerPanel.add(charsPanel);

        // 5. Resolucion de Cancha
        JPanel resolutionPanel = createRowPanel("Resolucion Cancha:");
        String[] resolutions = { "1000 x 550 (Estandar ECI)", "800 x 500 (Compacto)", "1200 x 650 (Amplio)" };
        comboResolution = new JComboBox<>(resolutions);
        resolutionPanel.add(comboResolution);
        centerPanel.add(Box.createVerticalStrut(8));
        centerPanel.add(resolutionPanel);

        add(centerPanel, BorderLayout.CENTER);

        // Botones de accion
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 15, 10));
        buttonPanel.setBackground(new Color(15, 20, 30));

        JButton btnCancel = new JButton("Cancelar");
        btnCancel.setFont(new Font("SansSerif", Font.BOLD, 12));
        btnCancel.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                dispose();
            }
        });

        JButton btnStart = new JButton("Iniciar Partido");
        btnStart.setFont(new Font("SansSerif", Font.BOLD, 13));
        btnStart.setBackground(new Color(0, 180, 216));
        btnStart.setForeground(Color.BLACK);
        btnStart.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                startGameAction();
            }
        });

        buttonPanel.add(btnCancel);
        buttonPanel.add(btnStart);
        add(buttonPanel, BorderLayout.SOUTH);
    }

    /**
     * Construye una fila con etiqueta alineada a la izquierda.
     */
    private JPanel createRowPanel(String labelText) {
        JPanel panel = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 4));
        panel.setBackground(new Color(24, 28, 36));
        JLabel label = new JLabel(labelText);
        label.setPreferredSize(new Dimension(140, 24));
        label.setFont(new Font("SansSerif", Font.BOLD, 12));
        label.setForeground(Color.WHITE);
        panel.add(label);
        return panel;
    }

    /**
     * Actualiza la previsualizacion de estadisticas y dano de un personaje
     */
    private void updateStatsPreview(CharacterType type, JLabel targetLabel) {
        if (type == null)
            return;
        CharacterStats stats = type.createDefaultStats();
        double multKick = stats.getMultiplicadorKick();
        double maxLife = stats.getVidaMax();
        double dmgKick = stats.getDanioPatada();
        double dmgPower = stats.getDanioPoder(type.createPowerShot().getBaseDamage());

        String html = String.format("<html>"
                + "<b>Velocidad:</b> %d/10 &nbsp; <b>Salto:</b> %d/10<br>"
                + "<b>Patada:</b> %d/10 (x%.2f) &nbsp; <b>Supervivencia:</b> %d/10<br>"
                + "<b>VidaMax:</b> %.0f &nbsp; <b>Danio Patada:</b> %.1f<br>"
                + "<b>Poder:</b> %s<br>"
                + "<b>Danio Poder:</b> %.1f"
                + "</html>",
                stats.getSpeed(), stats.getJump(),
                stats.getKick(), multKick, stats.getSurvival(),
                maxLife, dmgKick,
                type.getPowerDescription(), dmgPower);

        targetLabel.setText(html);
    }

    /**
     * Aplica la configuracion seleccionada e inicia el nuevo partido en el dominio.
     */
    private void startGameAction() {
        try {
            String modality = "PvP";
            String matchType = (comboMatchType.getSelectedIndex() == 0) ? "TIME" : "GOALS";

            String targetStr = (String) comboTargetValue.getSelectedItem();
            int targetValue = 60;
            if (targetStr != null) {
                if (targetStr.contains("1 Minuto"))
                    targetValue = 60;
                else if (targetStr.contains("2 Minutos"))
                    targetValue = 120;
                else
                    targetValue = Integer.parseInt(targetStr.replaceAll("[^0-9]", ""));
            }

            CharacterType p1 = (CharacterType) comboP1Character.getSelectedItem();
            CharacterType p2 = (CharacterType) comboP2Character.getSelectedItem();

            double fWidth = 1000.0;
            double fHeight = 550.0;
            int resIdx = comboResolution.getSelectedIndex();
            if (resIdx == 1) {
                fWidth = 800.0;
                fHeight = 500.0;
            } else if (resIdx == 2) {
                fWidth = 1200.0;
                fHeight = 650.0;
            }

            facade.configureAndStartMatch(modality, matchType, p1, p2, targetValue, fWidth, fHeight);
            dispose();

        } catch (DOPOSoccerException ex) {
            JOptionPane.showMessageDialog(this,
                    "Error al configurar la partida: " + ex.getMessage(),
                    "Error de Dominio", JOptionPane.ERROR_MESSAGE);
        }
    }
}
