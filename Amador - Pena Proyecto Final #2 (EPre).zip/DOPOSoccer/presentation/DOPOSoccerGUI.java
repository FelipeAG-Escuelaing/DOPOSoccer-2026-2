package presentation;

import domain.DOPOSoccer;
import domain.DOPOSoccerException;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.SwingUtilities;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.util.List;

/**
 * Ventana principal y coordinador de la capa de presentacion para DOPOSoccer.
 * Separa la interfaz grafica del ciclo de simulacion del juego.
 */
public class DOPOSoccerGUI extends JFrame {


    // Fachada del dominio que centraliza toda la logica del juego.

    private final DOPOSoccer facade;

    // Panel superior con el marcador y cronometro.

    private final ScoreboardPanel scoreboardPanel;

    // Panel central donde se dibuja el campo de juego.

    private final FieldPanel fieldPanel;

    // Controlador que escucha las entradas del teclado.

    private final GameKeyController keyController;

    // Hilo independiente para la ejecucion del Game Loop.

    private Thread gameLoopThread;

    // Bandera para controlar la ejecucion continua del hilo principal.

    private volatile boolean isRunning;

    /**
     * Constructor principal que inicializa la interfaz y el Game Loop.
     */
    public DOPOSoccerGUI() {
        super("DOPOSoccer 2026-2 - Nivel Basico (Jugador vs. Jugador) [ECI DOPO]");

        this.facade = new DOPOSoccer();
        this.scoreboardPanel = new ScoreboardPanel(this.facade);
        this.fieldPanel = new FieldPanel(this.facade);
        this.keyController = new GameKeyController(this.facade);
        this.isRunning = true;

        initGUI();
        startGameLoop();
    }

    /**
     * Configura los componentes visuales de la ventana principal.
     */
    private void initGUI() {
        setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
        setLayout(new BorderLayout());
        getContentPane().setBackground(new Color(20, 24, 30));

        setJMenuBar(createMenuBar());
        add(scoreboardPanel, BorderLayout.NORTH);
        add(fieldPanel, BorderLayout.CENTER);
        add(createControlsFooter(), BorderLayout.SOUTH);

        addKeyListener(keyController);
        setFocusable(true);
        requestFocusInWindow();

        addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                confirmExit();
            }

            @Override
            public void windowDeactivated(WindowEvent e) {
                keyController.clearPressedKeys();
            }
        });

        pack();
        setLocationRelativeTo(null);
        setResizable(false);
    }

    /**
     * Construye la barra de menus superior del juego.
     * 
     * @return Barra de menu configurada.
     */
    private JMenuBar createMenuBar() {
        JMenuBar menuBar = new JMenuBar();

        JMenu menuJuego = new JMenu("Juego");
        menuJuego.setFont(new Font("SansSerif", Font.BOLD, 12));

        JMenuItem itemConfig = new JMenuItem("Nueva Partida (Configurar)...");
        itemConfig.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                openConfigurationDialog();
            }
        });

        JMenuItem itemPause = new JMenuItem("Pausar / Reanudar (Espacio)");
        itemPause.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                facade.togglePause();
            }
        });

        JMenuItem itemRestart = new JMenuItem("Reiniciar Partido Actual (R)");
        itemRestart.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    facade.restartCurrentMatch();
                } catch (DOPOSoccerException ex) {
                    JOptionPane.showMessageDialog(DOPOSoccerGUI.this,
                            "Error al reiniciar: " + ex.getMessage(),
                            "Error de Dominio", JOptionPane.ERROR_MESSAGE);
                }
            }
        });

        JMenuItem itemLog = new JMenuItem("Ver Bitacora de Errores...");
        itemLog.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                showErrorLogDialog();
            }
        });

        JMenuItem itemExit = new JMenuItem("Salir");
        itemExit.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                confirmExit();
            }
        });

        menuJuego.add(itemConfig);
        menuJuego.add(itemPause);
        menuJuego.add(itemRestart);
        menuJuego.addSeparator();
        menuJuego.add(itemLog);
        menuJuego.addSeparator();
        menuJuego.add(itemExit);

        menuBar.add(menuJuego);
        return menuBar;
    }

    /**
     * Crea el panel inferior informativo con el resumen de teclas de juego.
     * 
     * @return Panel con etiquetas de controles.
     */
    private JPanel createControlsFooter() {
        JPanel footer = new JPanel(new FlowLayout(FlowLayout.CENTER, 20, 5));
        footer.setBackground(new Color(15, 20, 28));
        footer.setPreferredSize(new Dimension(1000, 32));

        JLabel p1Hint = new JLabel("P1: [W] Saltar | [A/D] Mover | [J] Patada | [K] Poder");
        p1Hint.setFont(new Font("Monospaced", Font.BOLD, 11));
        p1Hint.setForeground(new Color(0, 200, 255));

        JLabel sep = new JLabel("|");
        sep.setForeground(Color.GRAY);

        JLabel p2Hint = new JLabel("P2: [Arriba] Saltar | [Izq/Der] Mover | [L] Patada | [P] Poder");
        p2Hint.setFont(new Font("Monospaced", Font.BOLD, 11));
        p2Hint.setForeground(new Color(255, 120, 120));

        JLabel sep2 = new JLabel("|");
        sep2.setForeground(Color.GRAY);

        JLabel globalHint = new JLabel("[ESPACIO] Pausa | [R] Revancha");
        globalHint.setFont(new Font("Monospaced", Font.PLAIN, 11));
        globalHint.setForeground(Color.LIGHT_GRAY);

        footer.add(p1Hint);
        footer.add(sep);
        footer.add(p2Hint);
        footer.add(sep2);
        footer.add(globalHint);

        return footer;
    }

    /**
     * Inicia el ciclo principal del juego en un hilo secundario independiente.
     */
    private void startGameLoop() {
        gameLoopThread = new Thread(new Runnable() {
            @Override
            public void run() {
                long lastTime = System.nanoTime();
                while (isRunning) {
                    long now = System.nanoTime();
                    double dt = (now - lastTime) / 1_000_000_000.0;
                    lastTime = now;

                    // Limite maximo de paso para evitar saltos bruscos
                    if (dt > 0.05) {
                        dt = 0.05;
                    }

                    keyController.processContinuousInput();
                    facade.update(dt);

                    SwingUtilities.invokeLater(new Runnable() {
                        @Override
                        public void run() {
                            fieldPanel.repaint();
                            scoreboardPanel.repaint();
                        }
                    });

                    try {
                        Thread.sleep(16);
                    } catch (InterruptedException e) {
                        Thread.currentThread().interrupt();
                        break;
                    }
                }
            }
        }, "DOPOSoccer-GameLoop-Thread");

        gameLoopThread.start();
    }

    /**
     * Abre el cuadro de dialogo modal para configurar una nueva partida.
     */
    private void openConfigurationDialog() {
        boolean wasPaused = facade.isMatchPaused();
        facade.setPaused(true);

        ConfigurationDialog dialog = new ConfigurationDialog(this, facade);
        dialog.setVisible(true);

        requestFocusInWindow();
        if (!wasPaused) {
            facade.setPaused(false);
        }
    }

    /**
     * Muestra la ventana con las excepciones y advertencias registradas en el dominio.
     */
    private void showErrorLogDialog() {
        List<String> logs = facade.getDomainErrorLog();
        StringBuilder sb = new StringBuilder();
        if (logs.isEmpty()) {
            sb.append("No se registran excepciones ni errores en el log del dominio.");
        } else {
            for (String entry : logs) {
                sb.append(entry).append("\n");
            }
        }

        JOptionPane.showMessageDialog(this, sb.toString(),
                "Bitacora de Errores (DOPOSoccerException)", JOptionPane.INFORMATION_MESSAGE);
    }

    /**
     * Solicita confirmacion al usuario antes de cerrar el juego.
     */
    private void confirmExit() {
        int opt = JOptionPane.showConfirmDialog(this,
                "Desea salir de DOPOSoccer?", "Confirmacion de Salida",
                JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE);
        if (opt == JOptionPane.YES_OPTION) {
            isRunning = false;
            dispose();
            System.exit(0);
        }
    }

    /**
     * Punto de arranque de la aplicacion DOPOSoccer.
     *
     * @param args Argumentos de linea de comandos.
     */
    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                DOPOSoccerGUI gui = new DOPOSoccerGUI();
                gui.setVisible(true);
            }
        });
    }
}
