package presentation;

import domain.CharacterType;
import domain.DOPOSoccer;
import domain.GoalMatch;
import domain.Match;
import domain.Player;
import domain.TimeMatch;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.GradientPaint;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;

/**
 * Panel superior que dibuja el marcador de goles, tiempo restante,
 * banderas nacionales oficiales y estado del partido con diseno de transmision deportiva.
 */
public class ScoreboardPanel extends GamePanel {

    private final Font scoreFont;
    private final Font labelFont;
    private final Font subLabelFont;
    private final Font statusFont;

    /**
     * Constructor del panel de marcador.
     * 
     * @param facade Fachada principal del juego.
     */
    public ScoreboardPanel(DOPOSoccer facade) {
        super(facade);
        setPreferredSize(new Dimension(1000, 75));
        setBackground(new Color(15, 23, 42));

        this.scoreFont = new Font("Arial Black", Font.BOLD, 26);
        this.labelFont = new Font("SansSerif", Font.BOLD, 13);
        this.subLabelFont = new Font("SansSerif", Font.PLAIN, 11);
        this.statusFont = new Font("SansSerif", Font.BOLD, 12);
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        Graphics2D g2 = (Graphics2D) g;
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        g2.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);

        int w = getWidth();
        int h = getHeight();

        // Fondo degradado estilo transmision televisiva
        GradientPaint gp = new GradientPaint(0, 0, new Color(15, 23, 42), 0, h, new Color(30, 41, 59));
        g2.setPaint(gp);
        g2.fillRect(0, 0, w, h);

        // Borde inferior deportivo en cyan
        g2.setColor(new Color(14, 165, 233));
        g2.fillRect(0, h - 3, w, 3);

        Match match = facade.getCurrentMatch();
        if (match == null) {
            return;
        }

        Player p1 = match.getPlayer1();
        Player p2 = match.getPlayer2();

        // Bloque central de marcador organizado (Capsula de TV)
        drawCenterCapsule(g2, w / 2, match);

        // Bloque de Jugador 1 (Izquierda)
        drawPlayer1Block(g2, 20, 16, p1);

        // Bloque de Jugador 2 (Derecha)
        drawPlayer2Block(g2, w - 20, 16, p2);
    }

    /**
     * Dibuja los datos del Jugador 1 a la izquierda con su bandera oficial y sin solapamientos.
     */
    private void drawPlayer1Block(Graphics2D g2, int x, int y, Player player) {
        if (player == null) return;

        CharacterType type = player.getCharacterType();

        // Bandera oficial del pais (40x26)
        FlagAssets.drawFlag(g2, type, x, y + 2, 40, 26);

        // Nombre del jugador
        g2.setColor(Color.WHITE);
        g2.setFont(labelFont);
        g2.drawString(player.getName(), x + 48, y + 15);

        // Nombre del pais
        g2.setColor(new Color(148, 163, 184));
        g2.setFont(subLabelFont);
        g2.drawString(type.getDisplayName(), x + 48, y + 30);
    }

    /**
     * Dibuja los datos del Jugador 2 a la derecha alineado simetricamente con su bandera.
     */
    private void drawPlayer2Block(Graphics2D g2, int rightX, int y, Player player) {
        if (player == null) return;

        CharacterType type = player.getCharacterType();

        // Bandera oficial del pais a la derecha (40x26)
        int flagX = rightX - 40;
        FlagAssets.drawFlag(g2, type, flagX, y + 2, 40, 26);

        // Nombres alineados a la derecha antes de la bandera
        g2.setFont(labelFont);
        FontMetrics fmLabel = g2.getFontMetrics();
        int nameW = fmLabel.stringWidth(player.getName());

        g2.setColor(Color.WHITE);
        g2.drawString(player.getName(), flagX - nameW - 10, y + 15);

        g2.setFont(subLabelFont);
        FontMetrics fmSub = g2.getFontMetrics();
        int countryW = fmSub.stringWidth(type.getDisplayName());

        g2.setColor(new Color(148, 163, 184));
        g2.drawString(type.getDisplayName(), flagX - countryW - 10, y + 30);
    }

    /**
     * Dibuja la capsula central con marcador grande y reloj ordenado sin superposiciones.
     */
    private void drawCenterCapsule(Graphics2D g2, int centerX, Match match) {
        int capW = 220;
        int capH = 56;
        int capX = centerX - capW / 2;
        int capY = 8;

        // Fondo de la capsula
        g2.setColor(new Color(2, 6, 23, 220));
        g2.fillRoundRect(capX, capY, capW, capH, 12, 12);
        g2.setColor(new Color(51, 65, 85));
        g2.setStroke(new BasicStroke(1.5f));
        g2.drawRoundRect(capX, capY, capW, capH, 12, 12);

        // Marcador superior en amarillo dorado
        String scoreText = match.getScore1() + "  -  " + match.getScore2();
        g2.setFont(scoreFont);
        FontMetrics fmScore = g2.getFontMetrics();
        int scoreW = fmScore.stringWidth(scoreText);

        g2.setColor(new Color(250, 204, 21)); // Dorado brillante
        g2.drawString(scoreText, centerX - scoreW / 2, capY + 28);

        // Subtitulo de tiempo / modo
        g2.setFont(statusFont);
        FontMetrics fmStatus = g2.getFontMetrics();

        String statusText;
        Color statusColor;

        if (match.isGameOver()) {
            statusText = "FINALIZADO";
            statusColor = new Color(239, 68, 68);
        } else if (match.getGoalCelebrationTimer() > 0) {
            statusText = "GOL!";
            statusColor = new Color(34, 197, 94);
        } else if (match.isPaused()) {
            statusText = "PAUSA";
            statusColor = new Color(245, 158, 11);
        } else if (match instanceof TimeMatch) {
            TimeMatch tm = (TimeMatch) match;
            if (tm.isSuddenDeath()) {
                statusText = "MUERTE SUBITA";
                statusColor = new Color(239, 68, 68);
            } else {
                int secs = (int) Math.ceil(tm.getTimeRemaining());
                int m = secs / 60;
                int s = secs % 60;
                statusText = String.format("%02d:%02d", m, s);
                statusColor = new Color(56, 189, 248);
            }
        } else if (match instanceof GoalMatch) {
            GoalMatch gm = (GoalMatch) match;
            statusText = "A " + gm.getGoalLimit() + " GOLES";
            statusColor = new Color(56, 189, 248);
        } else {
            statusText = "EN JUEGO";
            statusColor = Color.LIGHT_GRAY;
        }

        int textW = fmStatus.stringWidth(statusText);
        g2.setColor(statusColor);
        g2.drawString(statusText, centerX - textW / 2, capY + 47);
    }
}
