package presentation;

import domain.CharacterStats;
import domain.DOPOSoccer;
import domain.DOPOSoccerException;
import domain.Player;

import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JDialog;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.filechooser.FileNameExtensionFilter;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;

/**
 * Dialogo modal de Tienda y Mejoras de Estadisticas.
 * Permite a los jugadores invertir sus puntos acumulados en mejorar
 * Velocidad, Salto, Patada y Supervivencia, asi como guardar/cargar su progreso.
 */
public class StoreDialog extends JDialog {

    private final DOPOSoccer facade;
    private JComboBox<String> comboPlayerSelect;
    private JLabel lblPlayerPoints;

    private JLabel lblSpeedLevel;
    private JLabel lblSpeedCost;
    private JButton btnUpgradeSpeed;

    private JLabel lblJumpLevel;
    private JLabel lblJumpCost;
    private JButton btnUpgradeJump;

    private JLabel lblKickLevel;
    private JLabel lblKickCost;
    private JButton btnUpgradeKick;

    private JLabel lblSurvivalLevel;
    private JLabel lblSurvivalCost;
    private JButton btnUpgradeSurvival;

    /**
     * Constructor del dialogo de la tienda.
     * 
     * @param parent Ventana principal.
     * @param facade Fachada del dominio.
     */
    public StoreDialog(JFrame parent, DOPOSoccer facade) {
        super(parent, "DOPOSoccer - Tienda de Mejoras y Progreso", true);
        this.facade = facade;

        initComponents();
        refreshDisplay();
        pack();
        setLocationRelativeTo(parent);
    }

    private void initComponents() {
        setLayout(new BorderLayout(10, 10));
        getContentPane().setBackground(new Color(24, 28, 36));

        // Cabecera
        JPanel headerPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
        headerPanel.setBackground(new Color(15, 20, 30));
        JLabel titleLabel = new JLabel("TIENDA DE MEJORAS Y PROGRESO DE JUGADORES");
        titleLabel.setFont(new Font("Arial", Font.BOLD, 16));
        titleLabel.setForeground(new Color(0, 200, 255));
        headerPanel.add(titleLabel);
        add(headerPanel, BorderLayout.NORTH);

        // Panel Central
        JPanel centerPanel = new JPanel();
        centerPanel.setLayout(new BoxLayout(centerPanel, BoxLayout.Y_AXIS));
        centerPanel.setBackground(new Color(24, 28, 36));
        centerPanel.setBorder(BorderFactory.createEmptyBorder(10, 20, 10, 20));

        // Selector de Jugador y Puntos
        JPanel playerPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 15, 5));
        playerPanel.setBackground(new Color(32, 38, 50));
        playerPanel.setBorder(BorderFactory.createTitledBorder(BorderFactory.createLineBorder(new Color(0, 180, 216)),
                "Seleccion de Jugador", 0, 0, new Font("SansSerif", Font.BOLD, 12), Color.WHITE));

        comboPlayerSelect = new JComboBox<>(new String[] { "Jugador 1", "Jugador 2" });
        comboPlayerSelect.setFont(new Font("SansSerif", Font.BOLD, 12));
        comboPlayerSelect.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                refreshDisplay();
            }
        });

        lblPlayerPoints = new JLabel("Puntos: 0");
        lblPlayerPoints.setFont(new Font("SansSerif", Font.BOLD, 14));
        lblPlayerPoints.setForeground(new Color(255, 215, 0));

        playerPanel.add(new JLabel("Jugador a mejorar: "));
        playerPanel.add(comboPlayerSelect);
        playerPanel.add(lblPlayerPoints);
        centerPanel.add(playerPanel);
        centerPanel.add(Box.createVerticalStrut(10));

        // Panel de Atributos
        JPanel statsPanel = new JPanel(new GridLayout(4, 1, 0, 8));
        statsPanel.setBackground(new Color(24, 28, 36));

        // Fila Velocidad
        lblSpeedLevel = new JLabel("Nivel: 1/10");
        lblSpeedCost = new JLabel("Costo: 500 pts");
        btnUpgradeSpeed = createUpgradeButton("speed");
        statsPanel.add(createStatRow("Velocidad (Speed):", lblSpeedLevel, lblSpeedCost, btnUpgradeSpeed));

        // Fila Salto
        lblJumpLevel = new JLabel("Nivel: 1/10");
        lblJumpCost = new JLabel("Costo: 500 pts");
        btnUpgradeJump = createUpgradeButton("jump");
        statsPanel.add(createStatRow("Salto (Jump):", lblJumpLevel, lblJumpCost, btnUpgradeJump));

        // Fila Patada
        lblKickLevel = new JLabel("Nivel: 1/10");
        lblKickCost = new JLabel("Costo: 500 pts");
        btnUpgradeKick = createUpgradeButton("kick");
        statsPanel.add(createStatRow("Patada (Kick):", lblKickLevel, lblKickCost, btnUpgradeKick));

        // Fila Supervivencia
        lblSurvivalLevel = new JLabel("Nivel: 1/10");
        lblSurvivalCost = new JLabel("Costo: 500 pts");
        btnUpgradeSurvival = createUpgradeButton("survival");
        statsPanel.add(createStatRow("Supervivencia (Vida):", lblSurvivalLevel, lblSurvivalCost, btnUpgradeSurvival));

        centerPanel.add(statsPanel);
        add(centerPanel, BorderLayout.CENTER);

        // Panel Inferior con botones de persistencia y cerrar
        JPanel footerPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 12, 10));
        footerPanel.setBackground(new Color(15, 20, 30));

        JButton btnSaveProgress = new JButton("Guardar Progreso...");
        btnSaveProgress.setFont(new Font("SansSerif", Font.PLAIN, 12));
        btnSaveProgress.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                saveProgressAction();
            }
        });

        JButton btnLoadProgress = new JButton("Cargar Progreso...");
        btnLoadProgress.setFont(new Font("SansSerif", Font.PLAIN, 12));
        btnLoadProgress.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                loadProgressAction();
            }
        });

        JButton btnClose = new JButton("Cerrar");
        btnClose.setFont(new Font("SansSerif", Font.BOLD, 12));
        btnClose.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                dispose();
            }
        });

        footerPanel.add(btnSaveProgress);
        footerPanel.add(btnLoadProgress);
        footerPanel.add(btnClose);
        add(footerPanel, BorderLayout.SOUTH);
    }

    private JPanel createStatRow(String statName, JLabel lblLevel, JLabel lblCost, JButton btnUpgrade) {
        JPanel row = new JPanel(new FlowLayout(FlowLayout.LEFT, 15, 5));
        row.setBackground(new Color(32, 38, 50));
        row.setBorder(BorderFactory.createLineBorder(new Color(60, 70, 85)));

        JLabel nameLabel = new JLabel(statName);
        nameLabel.setPreferredSize(new Dimension(160, 22));
        nameLabel.setFont(new Font("SansSerif", Font.BOLD, 12));
        nameLabel.setForeground(Color.WHITE);

        lblLevel.setPreferredSize(new Dimension(90, 22));
        lblLevel.setFont(new Font("SansSerif", Font.PLAIN, 12));
        lblLevel.setForeground(new Color(0, 200, 255));

        lblCost.setPreferredSize(new Dimension(120, 22));
        lblCost.setFont(new Font("SansSerif", Font.PLAIN, 12));
        lblCost.setForeground(new Color(255, 180, 0));

        row.add(nameLabel);
        row.add(lblLevel);
        row.add(lblCost);
        row.add(btnUpgrade);
        return row;
    }

    private JButton createUpgradeButton(final String statKey) {
        JButton btn = new JButton("+ Mejorar");
        btn.setFont(new Font("SansSerif", Font.BOLD, 11));
        btn.setBackground(new Color(0, 180, 216));
        btn.setForeground(Color.BLACK);
        btn.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int playerId = comboPlayerSelect.getSelectedIndex() + 1;
                boolean success = facade.upgradeStat(playerId, statKey);
                if (success) {
                    JOptionPane.showMessageDialog(StoreDialog.this,
                            "Mejora aplicada exitosamente para " + statKey + "!",
                            "Mejora Exitosa", JOptionPane.INFORMATION_MESSAGE);
                } else {
                    JOptionPane.showMessageDialog(StoreDialog.this,
                            "No se pudo aplicar la mejora. Verifica si tienes suficientes puntos o alcanzaste el nivel maximo (10).",
                            "Puntos Insuficientes", JOptionPane.WARNING_MESSAGE);
                }
                refreshDisplay();
            }
        });
        return btn;
    }

    private void refreshDisplay() {
        if (facade.getCurrentMatch() == null) {
            return;
        }

        int playerId = comboPlayerSelect.getSelectedIndex() + 1;
        Player player = (playerId == 1) ? facade.getCurrentMatch().getPlayer1() : facade.getCurrentMatch().getPlayer2();
        if (player == null) {
            return;
        }

        int points = player.getAccumulatedPoints();
        lblPlayerPoints.setText("Puntos Disponibles: " + points + " pts");

        CharacterStats stats = player.getStats();
        if (stats != null) {
            updateRow(lblSpeedLevel, lblSpeedCost, btnUpgradeSpeed, stats.getSpeed(), points);
            updateRow(lblJumpLevel, lblJumpCost, btnUpgradeJump, stats.getJump(), points);
            updateRow(lblKickLevel, lblKickCost, btnUpgradeKick, stats.getKick(), points);
            updateRow(lblSurvivalLevel, lblSurvivalCost, btnUpgradeSurvival, stats.getSurvival(), points);
        }
    }

    private void updateRow(JLabel lblLevel, JLabel lblCost, JButton btn, int currentLevel, int currentPoints) {
        lblLevel.setText("Nivel: " + currentLevel + "/10");
        int cost = CharacterStats.getUpgradeCost(currentLevel);
        if (cost > 0) {
            lblCost.setText("Costo: " + cost + " pts");
            btn.setEnabled(currentPoints >= cost);
        } else {
            lblCost.setText("Nivel Maximo (MAX)");
            btn.setEnabled(false);
        }
    }

    private void saveProgressAction() {
        int playerId = comboPlayerSelect.getSelectedIndex() + 1;
        JFileChooser chooser = new JFileChooser(".");
        chooser.setDialogTitle("Guardar Progreso de Jugador");
        chooser.setSelectedFile(new File("jugador" + playerId + "_progreso.txt"));
        chooser.setFileFilter(new FileNameExtensionFilter("Archivos de Texto (*.txt)", "txt"));

        int result = chooser.showSaveDialog(this);
        if (result == JFileChooser.APPROVE_OPTION) {
            File file = chooser.getSelectedFile();
            try {
                facade.savePlayerProgress(playerId, file);
                JOptionPane.showMessageDialog(this,
                        "Progreso guardado correctamente en: " + file.getName(),
                        "Guardado Exitoso", JOptionPane.INFORMATION_MESSAGE);
            } catch (DOPOSoccerException ex) {
                JOptionPane.showMessageDialog(this,
                        "Error al guardar progreso: " + ex.getMessage(),
                        "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    private void loadProgressAction() {
        int playerId = comboPlayerSelect.getSelectedIndex() + 1;
        JFileChooser chooser = new JFileChooser(".");
        chooser.setDialogTitle("Cargar Progreso de Jugador");
        chooser.setFileFilter(new FileNameExtensionFilter("Archivos de Texto (*.txt)", "txt"));

        int result = chooser.showOpenDialog(this);
        if (result == JFileChooser.APPROVE_OPTION) {
            File file = chooser.getSelectedFile();
            try {
                facade.loadPlayerProgress(playerId, file);
                JOptionPane.showMessageDialog(this,
                        "Progreso cargado y aplicado exitosamente desde: " + file.getName(),
                        "Carga Exitosa", JOptionPane.INFORMATION_MESSAGE);
                refreshDisplay();
            } catch (DOPOSoccerException ex) {
                JOptionPane.showMessageDialog(this,
                        "Error al cargar progreso: " + ex.getMessage(),
                        "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }
}
