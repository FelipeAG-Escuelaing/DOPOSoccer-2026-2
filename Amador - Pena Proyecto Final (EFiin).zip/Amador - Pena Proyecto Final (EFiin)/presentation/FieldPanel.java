package presentation;

import domain.Ball;
import domain.CharacterType;
import domain.DOPOSoccer;
import domain.Field;
import domain.GoalPost;
import domain.Match;
import domain.Player;

import javax.imageio.ImageIO;
import javax.swing.JPanel;
import java.awt.AlphaComposite;
import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GradientPaint;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.RenderingHints;
import java.awt.geom.AffineTransform;
import java.io.File;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Panel de renderizado visual 2D para DOPOSoccer.
 * Dibuja el estadio, cesped, arcos, jugadores con sus animaciones y el balon.
 */
public class FieldPanel extends GamePanel {

    // Fuente de gran tamano para avisos de gol y finalizacion.

    private final Font bannerFont;

    // Fuente para avisos de poder listo sobre el jugador.

    private final Font alertFont;

    // Imagen personalizada de la foto del estadio.

    private Image imgFotoEstadio;

    // Imagen de fondo del estadio.

    private Image imgBackground;

    // Imagen de la tribuna de espectadores.

    private Image imgStadium;

    // Textura del cesped de la cancha.

    private Image imgField;

    // Textura de la porteria.

    private Image imgGoal;

    // Textura del balon de futbol.

    private Image imgBall;

    // Textura del botin de patada.

    private Image imgShoe;

    // Mapa con las imagenes de cabezas de cada personaje.

    private final Map<CharacterType, Image> headImages;

    /**
     * Constructor del panel de campo de juego.
     * 
     * @param facade Fachada principal del juego.
     */
    public FieldPanel(DOPOSoccer facade) {
        super(facade);
        setPreferredSize(new Dimension((int) Field.DEFAULT_WIDTH, (int) Field.DEFAULT_HEIGHT));
        setBackground(new Color(25, 30, 38));

        this.bannerFont = new Font("Arial Black", Font.BOLD, 42);
        this.alertFont = new Font("SansSerif", Font.BOLD, 12);
        this.headImages = new HashMap<>();

        loadOriginalAssets();
    }

    /**
     * Carga las texturas desde la carpeta de recursos.
     */
    private void loadOriginalAssets() {
        try {
            File fCustom = new File("assets/foto estadio.png");
            if (!fCustom.exists()) {
                fCustom = new File("C:/Users/Usuario/imagenes para dopoSoccer/foto estadio.png");
            }
            if (fCustom.exists()) {
                imgFotoEstadio = ImageIO.read(fCustom);
            }

            File fBg = new File("assets/bg-1.png");
            if (fBg.exists())
                imgBackground = ImageIO.read(fBg);

            File fStadium = new File("assets/stadium-01.png");
            if (fStadium.exists())
                imgStadium = ImageIO.read(fStadium);

            File fField = new File("assets/field-01.png");
            if (fField.exists())
                imgField = ImageIO.read(fField);

            File fGoal = new File("assets/Goal.png");
            if (fGoal.exists())
                imgGoal = ImageIO.read(fGoal);

            File fBall = new File("assets/ball1.png");
            if (fBall.exists())
                imgBall = ImageIO.read(fBall);

            File fShoe = new File("assets/Player-Shoe-01-.png");
            if (fShoe.exists())
                imgShoe = ImageIO.read(fShoe);

            File fH1 = new File("assets/Player-Head-01-n.png");
            if (fH1.exists())
                headImages.put(CharacterType.SOUTH_KOREA, ImageIO.read(fH1));

            File fH2 = new File("assets/Player-Head-02-n.png");
            if (fH2.exists())
                headImages.put(CharacterType.CAMEROON, ImageIO.read(fH2));

            File fH3 = new File("assets/Player-Head-03-n.png");
            if (fH3.exists())
                headImages.put(CharacterType.NIGERIA, ImageIO.read(fH3));

            File fH4 = new File("assets/Player-Head-04-n.png");
            if (fH4.exists())
                headImages.put(CharacterType.USA, ImageIO.read(fH4));

        } catch (Exception e) {
            // Si falta alguna imagen, el panel usa respaldo procedural sin fallar
        }
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        Graphics2D g2 = (Graphics2D) g;
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        g2.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);

        Match match = facade.getCurrentMatch();
        if (match == null)
            return;

        Field field = match.getField();
        double w = field.getWidth();
        double h = field.getHeight();
        double groundY = field.getGroundY();

        // Fondo de estadio
        drawStadium(g2, (int) w, (int) h, (int) groundY);

        // Cesped
        drawPitch(g2, (int) w, (int) h, (int) groundY);

        // Arcos
        drawGoal(g2, field.getLeftGoal(), true);
        drawGoal(g2, field.getRightGoal(), false);

        // Balones
        List<Ball> balls = match.getBalls();
        for (Ball b : balls) {
            if (b.isIllusion())
                drawBall(g2, b);
        }
        Ball mainBall = match.getMainBall();
        if (mainBall != null) {
            drawBall(g2, mainBall);
        }

        // Jugadores
        drawPlayer(g2, match.getPlayer1());
        drawPlayer(g2, match.getPlayer2());

        // Mensajes flotantes de gol o fin
        drawOverlays(g2, (int) w, (int) h, match);
    }

    /**
     * Dibuja el fondo del estadio con la foto personalizada y conserva la franja publicitaria.
     */
    private void drawStadium(Graphics2D g2, int w, int h, int groundY) {
        int billboardH = 35;
        int stadiumH = groundY - billboardH;

        if (imgFotoEstadio != null) {
            // Fondo con la foto del estadio personalizada
            g2.drawImage(imgFotoEstadio, 0, 0, w, stadiumH, null);
        } else if (imgBackground != null) {
            g2.drawImage(imgBackground, 0, 0, w, groundY, null);
            if (imgStadium != null) {
                g2.drawImage(imgStadium, 0, groundY - 140, w, 140, null);
            }
        } else {
            GradientPaint sky = new GradientPaint(0, 0, new Color(10, 16, 28), 0, groundY - 100, new Color(28, 42, 65));
            g2.setPaint(sky);
            g2.fillRect(0, 0, w, stadiumH);
            g2.setColor(new Color(20, 26, 38));
            g2.fillRect(0, groundY - 110, w, 60);
        }

        // Franja publicitaria requerida intacta
        g2.setColor(new Color(18, 22, 28));
        g2.fillRect(0, groundY - 35, w, 35);
        g2.setColor(new Color(0, 180, 216));
        g2.setFont(new Font("Arial Black", Font.BOLD, 13));
        g2.drawString("DOPO SOCCER 2026-2 | ECI | HEAD SOCCER JAVA EDITION", w / 2 - 230, groundY - 12);
    }

    /**
     * Dibuja el cesped verde y las lineas reglamentarias de la cancha.
     */
    private void drawPitch(Graphics2D g2, int w, int h, int groundY) {
        if (imgField != null) {
            g2.drawImage(imgField, 0, groundY, w, h - groundY, null);
        } else {
            int stripeW = 50;
            Color g1 = new Color(46, 139, 87);
            Color g2Color = new Color(40, 128, 78);
            for (int x = 0; x < w; x += stripeW) {
                g2.setColor(((x / stripeW) % 2 == 0) ? g1 : g2Color);
                g2.fillRect(x, groundY, stripeW, h - groundY);
            }
        }

        g2.setColor(Color.WHITE);
        g2.setStroke(new BasicStroke(3));
        g2.drawLine(0, groundY, w, groundY);

        int midX = w / 2;
        g2.drawLine(midX, groundY, midX, h);
        g2.drawOval(midX - 45, groundY - 5, 90, 40);
        g2.fillOval(midX - 4, groundY - 4, 8, 8);
    }

    /**
     * Dibuja la estructura y red de una porteria.
     */
    private void drawGoal(Graphics2D g2, GoalPost goal, boolean isLeft) {
        if (goal == null)
            return;
        int gx = (int) goal.getX();
        int gy = (int) goal.getY();
        int gw = (int) goal.getWidth();
        int gh = (int) goal.getHeight();

        if (imgGoal != null) {
            if (isLeft) {
                g2.drawImage(imgGoal, gx, gy - 10, gw, gh + 15, null);
            } else {
                g2.drawImage(imgGoal, gx + gw, gy - 10, -gw, gh + 15, null);
            }
        } else {
            g2.setColor(new Color(240, 240, 240, 90));
            g2.setStroke(new BasicStroke(1));
            for (int x = gx; x <= gx + gw; x += 12) {
                g2.drawLine(x, gy, x, gy + gh);
            }
            for (int y = gy; y <= gy + gh; y += 12) {
                g2.drawLine(gx, y, gx + gw, y);
            }

            g2.setColor(Color.WHITE);
            g2.setStroke(new BasicStroke(5));
            g2.drawLine(gx, gy, gx + gw, gy);
            g2.drawLine(isLeft ? gx + gw : gx, gy, isLeft ? gx + gw : gx, gy + gh);
        }
    }

    /**
     * Dibuja un futbolista con su cuerpo, cabeza, pie y barra de estado.
     */
    private void drawPlayer(Graphics2D g2, Player player) {
        if (player == null)
            return;

        double px = player.getPosition().getX();
        double py = player.getPosition().getY();
        double dir = player.getFacingDirection();
        CharacterType charType = player.getCharacterType();

        // Aura visible si tiene poder activo
        if (player.hasActivePower()) {
            drawPowerAura(g2, px, py, charType);
        }

        // Efectos de estado (aturdido, electrocutado, etc.)
        drawPlayerStateEffects(g2, player, px, py);

        // Pie y botin
        drawPlayerFoot(g2, player, px, py, dir);

        // Torso
        Color jersey = getJerseyColor(charType);
        g2.setColor(jersey);
        g2.fillRoundRect((int) (px - 14), (int) (py - 28), 28, 26, 8, 8);
        g2.setColor(Color.WHITE);
        g2.drawRoundRect((int) (px - 14), (int) (py - 28), 28, 26, 8, 8);

        // Cabeza
        int headR = (int) Player.HEAD_RADIUS;
        int headX = (int) (px - headR);
        int headY = (int) (py - 45 - headR);
        int headD = headR * 2 + 10;

        Image headImg = headImages.get(charType);
        if (headImg != null) {
            if (dir > 0) {
                g2.drawImage(headImg, headX - 5, headY - 5, headD, headD, null);
            } else {
                g2.drawImage(headImg, headX + headD - 5, headY - 5, -headD, headD, null);
            }
        } else {
            g2.setColor(getSkinTone(charType));
            g2.fillOval(headX, headY, headR * 2, headR * 2);
            g2.setColor(Color.BLACK);
            g2.setStroke(new BasicStroke(2));
            g2.drawOval(headX, headY, headR * 2, headR * 2);
            int eyeX = (int) (px + (dir > 0 ? 8 : -14));
            g2.setColor(Color.WHITE);
            g2.fillOval(eyeX, headY + 14, 12, 14);
            g2.setColor(Color.BLACK);
            g2.fillOval(eyeX + (dir > 0 ? 4 : 2), headY + 18, 6, 6);
        }

        // Barra flotante de vida y energia
        drawFloatingPlayerHUD(g2, player, px, headY - 14);
    }

    /**
     * Dibuja el halo luminoso alrededor del jugador con poder cargado.
     */
    private void drawPowerAura(Graphics2D g2, double px, double py, CharacterType type) {
        long t = System.currentTimeMillis();
        int pulse = (int) (Math.sin(t * 0.01) * 6);

        Color auraColor;
        switch (type) {
            case SOUTH_KOREA:
                auraColor = new Color(0, 150, 255, 90 + pulse * 5);
                break;
            case CAMEROON:
                auraColor = new Color(255, 230, 0, 95 + pulse * 5);
                break;
            case NIGERIA:
                auraColor = new Color(100, 255, 150, 90 + pulse * 5);
                break;
            case USA:
                auraColor = new Color(255, 80, 200, 90 + pulse * 5);
                break;
            default:
                auraColor = new Color(255, 215, 0, 90);
                break;
        }

        g2.setColor(auraColor);
        g2.fillOval((int) (px - 38 - pulse), (int) (py - 78 - pulse), 76 + pulse * 2, 78 + pulse * 2);
    }

    /**
     * Dibuja el botin del jugador con la animacion de patada.
     */
    private void drawPlayerFoot(Graphics2D g2, Player player, double px, double py, double dir) {
        int footX = (int) px;
        int footY = (int) (py - 8);

        if (player.isKicking()) {
            footX += (int) (dir * 28);
            footY -= 8;
            g2.setColor(new Color(255, 255, 255, 130));
            g2.setStroke(new BasicStroke(4));
            g2.drawLine((int) px, (int) (py - 6), footX, footY);
        }

        if (imgShoe != null) {
            if (dir > 0) {
                g2.drawImage(imgShoe, footX - 10, footY - 6, 20, 14, null);
            } else {
                g2.drawImage(imgShoe, footX + 10, footY - 6, -20, 14, null);
            }
        } else {
            g2.setColor(Color.BLACK);
            g2.fillRoundRect(footX - 8, footY - 4, 16, 10, 4, 4);
            g2.setColor(Color.YELLOW);
            g2.fillRect(footX - 4, footY + 4, 8, 3);
        }
    }

    /**
     * Dibuja las alteraciones visuales sobre el jugador segun su estado.
     */
    private void drawPlayerStateEffects(Graphics2D g2, Player player, double px, double py) {
        String stateName = player.getState().getStateName();

        if ("ATURDIDO".equals(stateName)) {
            long t = System.currentTimeMillis();
            double angle = t * 0.005;
            g2.setColor(new Color(255, 220, 0));
            g2.setFont(new Font("SansSerif", Font.BOLD, 15));
            for (int i = 0; i < 3; i++) {
                double a = angle + i * (2 * Math.PI / 3);
                int sx = (int) (px + Math.cos(a) * 26);
                int sy = (int) (py - 78 + Math.sin(a) * 10);
                g2.drawString("*", sx - 4, sy + 5);
            }
        } else if ("ELECTROCUTADO".equals(stateName)) {
            g2.setColor(new Color(255, 255, 50));
            g2.setStroke(new BasicStroke(2));
            for (int i = 0; i < 4; i++) {
                int ox = (int) (px + (Math.random() - 0.5) * 40);
                int oy = (int) (py - 30 + (Math.random() - 0.5) * 50);
                g2.drawLine(ox, oy, ox + 6, oy - 8);
                g2.drawLine(ox + 6, oy - 8, ox + 2, oy - 14);
            }
        } else if ("CONFUNDIDO".equals(stateName)) {
            g2.setColor(new Color(255, 100, 200));
            g2.setFont(new Font("SansSerif", Font.BOLD, 18));
            g2.drawString("?", (int) px - 16, (int) py - 76);
            g2.drawString("?", (int) px + 8, (int) py - 82);
        } else if ("INCONSCIENTE (AIRE)".equals(stateName)) {
            g2.setColor(new Color(150, 220, 255));
            g2.drawOval((int) px - 20, (int) py - 85, 40, 16);
        } else if ("EMPUJADO".equals(stateName)) {
            g2.setColor(new Color(100, 200, 255, 140));
            g2.setStroke(new BasicStroke(2));
            g2.drawLine((int) px - 30, (int) py - 30, (int) px + 30, (int) py - 30);
        }
    }

    /**
     * Dibuja las barras flotantes de salud y poder sobre la cabeza del jugador.
     */
    private void drawFloatingPlayerHUD(Graphics2D g2, Player player, double px, int y) {
        int barW = 56;
        int barH = 5;
        int bx = (int) (px - barW / 2);

        // Barra de salud
        double maxLife = player.getStats().getVidaMax();
        double currentLife = player.getCurrentHealth();
        double lifePercent = Math.max(0.0, Math.min(1.0, currentLife / maxLife));

        g2.setColor(new Color(180, 40, 40));
        g2.fillRect(bx, y, barW, barH);
        g2.setColor(new Color(40, 210, 80));
        g2.fillRect(bx, y, (int) (barW * lifePercent), barH);
        g2.setColor(Color.BLACK);
        g2.setStroke(new BasicStroke(1));
        g2.drawRect(bx, y, barW, barH);

        // Barra de poder
        int pyBar = y + barH + 2;
        double powerPercent = Math.max(0.0, Math.min(1.0, player.getPowerEnergy() / 100.0));

        g2.setColor(new Color(50, 50, 50));
        g2.fillRect(bx, pyBar, barW, barH);
        g2.setColor(player.hasActivePower() ? new Color(0, 230, 255) : new Color(255, 165, 0));
        g2.fillRect(bx, pyBar, (int) (barW * powerPercent), barH);
        g2.setColor(Color.BLACK);
        g2.drawRect(bx, pyBar, barW, barH);

        // Avisos de poder disponible
        if (player.hasActivePower()) {
            g2.setFont(alertFont);
            g2.setColor(new Color(0, 240, 255));
            String readyText = "AURA ACTIVA";
            int kw = g2.getFontMetrics().stringWidth(readyText);
            g2.drawString(readyText, (int) px - kw / 2, y - 4);
        } else if (player.isPowerReady()) {
            g2.setFont(alertFont);
            g2.setColor(new Color(255, 230, 0));
            String keyHint = (player.getId() == 1) ? "PODER [K]" : "PODER [P]";
            int kw = g2.getFontMetrics().stringWidth(keyHint);
            g2.drawString(keyHint, (int) px - kw / 2, y - 4);
        }
    }

    /**
     * Dibuja el balon oficial o las copias de ilusion con su respectiva rotacion.
     */
    private void drawBall(Graphics2D g2, Ball ball) {
        if (ball == null)
            return;

        double bx = ball.getPosition().getX();
        double by = ball.getPosition().getY();
        double r = ball.getRadius();

        Graphics2D gBall = (Graphics2D) g2.create();

        if (ball.isIllusion()) {
            gBall.setComposite(AlphaComposite.getInstance(AlphaComposite.SRC_OVER, 0.45f));
        }

        String effect = ball.getActiveEffect();
        if ("AURA_AZUL".equals(effect)) {
            gBall.setColor(new Color(0, 150, 255, 150));
            gBall.fillOval((int) (bx - r * 1.8), (int) (by - r * 1.8), (int) (r * 3.6), (int) (r * 3.6));
        } else if ("RAYO_ELECTRICO".equals(effect)) {
            gBall.setColor(new Color(255, 255, 0, 160));
            gBall.fillOval((int) (bx - r * 1.6), (int) (by - r * 1.6), (int) (r * 3.2), (int) (r * 3.2));
        } else if ("TORNADO".equals(effect)) {
            gBall.setColor(new Color(200, 225, 255, 150));
            gBall.fillOval((int) (bx - r * 1.8), (int) (by - r * 1.8), (int) (r * 3.6), (int) (r * 3.6));
        }

        AffineTransform oldTx = gBall.getTransform();
        gBall.translate(bx, by);
        gBall.rotate(ball.getRotationAngle());

        if (imgBall != null) {
            gBall.drawImage(imgBall, (int) -r, (int) -r, (int) (r * 2), (int) (r * 2), null);
        } else {
            gBall.setColor(Color.WHITE);
            gBall.fillOval((int) -r, (int) -r, (int) (r * 2), (int) (r * 2));
            gBall.setColor(Color.BLACK);
            gBall.setStroke(new BasicStroke(1.5f));
            gBall.drawOval((int) -r, (int) -r, (int) (r * 2), (int) (r * 2));
            gBall.fillOval((int) -r / 3, (int) -r / 3, (int) (r * 0.66), (int) (r * 0.66));
        }

        gBall.setTransform(oldTx);
        gBall.dispose();
    }

    /**
     * Dibuja los mensajes centrales superpuestos para gol, pausa o fin del partido.
     */
    private void drawOverlays(Graphics2D g2, int w, int h, Match match) {
        if (match.getGoalCelebrationTimer() > 0.0) {
            g2.setColor(new Color(0, 0, 0, 120));
            g2.fillRect(0, h / 2 - 60, w, 110);
            g2.setColor(new Color(255, 215, 0));
            g2.setFont(bannerFont);
            String goalText = "GOL";
            int tw = g2.getFontMetrics().stringWidth(goalText);
            g2.drawString(goalText, w / 2 - tw / 2, h / 2 + 10);

            g2.setFont(new Font("SansSerif", Font.BOLD, 18));
            g2.setColor(Color.WHITE);
            String scorer = "Anotado por Jugador " + match.getLastScoringPlayerId();
            int sw = g2.getFontMetrics().stringWidth(scorer);
            g2.drawString(scorer, w / 2 - sw / 2, h / 2 + 36);
        }

        if (match.isGameOver()) {
            g2.setColor(new Color(0, 0, 0, 180));
            g2.fillRect(0, 0, w, h);

            g2.setColor(new Color(255, 215, 0));
            g2.setFont(bannerFont);
            String overText = "FIN DEL PARTIDO";
            int tw = g2.getFontMetrics().stringWidth(overText);
            g2.drawString(overText, w / 2 - tw / 2, h / 2 - 40);

            Player win = match.getWinner();
            Player lose = match.getLoser();

            g2.setFont(new Font("SansSerif", Font.BOLD, 22));
            g2.setColor(new Color(100, 255, 120));
            String winText = "GANADOR: " + (win != null ? win.getName() : "Empate") + " (+" + match.getWinnerPoints()
                    + " pts)";
            int ww = g2.getFontMetrics().stringWidth(winText);
            g2.drawString(winText, w / 2 - ww / 2, h / 2 + 8);

            g2.setFont(new Font("SansSerif", Font.BOLD, 18));
            g2.setColor(new Color(255, 120, 120));
            String loseText = "PERDEDOR: " + (lose != null ? lose.getName() : "Nadie") + " (+" + match.getLoserPoints()
                    + " pts)";
            int lw = g2.getFontMetrics().stringWidth(loseText);
            g2.drawString(loseText, w / 2 - lw / 2, h / 2 + 38);

            g2.setFont(new Font("SansSerif", Font.PLAIN, 15));
            g2.setColor(Color.WHITE);
            String retry = "Presiona 'R' para revancha o ve a Configuracion de Partida";
            int rw = g2.getFontMetrics().stringWidth(retry);
            g2.drawString(retry, w / 2 - rw / 2, h / 2 + 75);
        }

        if (match.isPaused() && !match.isGameOver()) {
            g2.setColor(new Color(0, 0, 0, 120));
            g2.fillRect(0, h / 2 - 40, w, 80);
            g2.setColor(Color.WHITE);
            g2.setFont(bannerFont);
            String pauseText = "PAUSA";
            int tw = g2.getFontMetrics().stringWidth(pauseText);
            g2.drawString(pauseText, w / 2 - tw / 2, h / 2 + 15);
        }
    }

    /**
     * Retorna el color del uniforme principal del pais.
     */
    private Color getJerseyColor(CharacterType type) {
        if (type == null)
            return Color.RED;
        switch (type) {
            case SOUTH_KOREA:
                return new Color(20, 80, 200);
            case CAMEROON:
                return new Color(20, 150, 40);
            case NIGERIA:
                return new Color(0, 100, 40);
            case USA:
                return new Color(190, 20, 30);
            default:
                return Color.BLUE;
        }
    }

    /**
     * Retorna el tono de piel base del personaje.
     */
    private Color getSkinTone(CharacterType type) {
        if (type == null)
            return new Color(255, 219, 172);
        switch (type) {
            case SOUTH_KOREA:
                return new Color(255, 224, 189);
            case CAMEROON:
                return new Color(90, 56, 37);
            case NIGERIA:
                return new Color(74, 44, 28);
            case USA:
                return new Color(255, 205, 148);
            default:
                return new Color(255, 219, 172);
        }
    }
}
