package presentation;

import domain.CharacterType;

import javax.swing.ImageIcon;
import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.Polygon;
import java.awt.RenderingHints;
import java.awt.image.BufferedImage;
import java.util.HashMap;
import java.util.Map;

/**
 * Fabrica de banderas nacionales oficiales para DOPOSoccer.
 * Genera graficos vectoriales precisos de las banderas de:
 * Corea del Sur, Camerun, Nigeria y Estados Unidos.
 */
public class FlagAssets {

    private static final Map<String, Image> cache = new HashMap<>();
    private static final Map<String, ImageIcon> iconCache = new HashMap<>();

    /**
     * Retorna una imagen de la bandera nacional para el personaje especificado.
     * 
     * @param type Tipo de personaje / pais.
     * @param width Ancho deseado en pixeles.
     * @param height Alto deseado en pixeles.
     * @return Imagen renderizada de la bandera.
     */
    public static Image getFlagImage(CharacterType type, int width, int height) {
        if (type == null) {
            type = CharacterType.SOUTH_KOREA;
        }
        String key = type.name() + "_" + width + "x" + height;
        if (cache.containsKey(key)) {
            return cache.get(key);
        }

        BufferedImage img = new BufferedImage(width, height, BufferedImage.TYPE_INT_ARGB);
        Graphics2D g2 = img.createGraphics();
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        g2.setRenderingHint(RenderingHints.KEY_RENDERING, RenderingHints.VALUE_RENDER_QUALITY);

        drawFlag(g2, type, 0, 0, width, height);
        g2.dispose();

        cache.put(key, img);
        return img;
    }

    /**
     * Retorna un ImageIcon listo para JComboBox, botones y etiquetas.
     */
    public static ImageIcon getFlagIcon(CharacterType type, int width, int height) {
        String key = (type != null ? type.name() : "NULL") + "_" + width + "x" + height;
        if (iconCache.containsKey(key)) {
            return iconCache.get(key);
        }
        ImageIcon icon = new ImageIcon(getFlagImage(type, width, height));
        iconCache.put(key, icon);
        return icon;
    }

    /**
     * Dibuja directamente la bandera de un pais en las coordenadas dadas.
     */
    public static void drawFlag(Graphics2D g2, CharacterType type, int x, int y, int w, int h) {
        if (type == null) return;

        switch (type) {
            case SOUTH_KOREA:
                drawSouthKorea(g2, x, y, w, h);
                break;
            case CAMEROON:
                drawCameroon(g2, x, y, w, h);
                break;
            case NIGERIA:
                drawNigeria(g2, x, y, w, h);
                break;
            case USA:
                drawUSA(g2, x, y, w, h);
                break;
        }

        // Borde exterior fino para definir la bandera
        g2.setColor(new Color(255, 255, 255, 80));
        g2.drawRoundRect(x, y, w - 1, h - 1, 4, 4);
    }

    /**
     * Bandera de Corea del Sur: fondo blanco con simbolo Taegeuk rojo/azul central y trigramas.
     */
    private static void drawSouthKorea(Graphics2D g2, int x, int y, int w, int h) {
        g2.setColor(Color.WHITE);
        g2.fillRoundRect(x, y, w, h, 4, 4);

        int cx = x + w / 2;
        int cy = y + h / 2;
        int diam = (int) (Math.min(w, h) * 0.55);
        int r = diam / 2;

        // Taegeuk (mitad superior roja, mitad inferior azul)
        g2.setColor(new Color(205, 46, 58)); // Rojo oficial
        g2.fillArc(cx - r, cy - r, diam, diam, 0, 180);
        g2.setColor(new Color(0, 71, 160)); // Azul oficial
        g2.fillArc(cx - r, cy - r, diam, diam, 180, 180);

        // Curvas internas del Taegeuk
        g2.setColor(new Color(205, 46, 58));
        g2.fillOval(cx - r, cy - r / 2, r, r);
        g2.setColor(new Color(0, 71, 160));
        g2.fillOval(cx, cy - r / 2, r, r);

        // Trigramas negros en las 4 esquinas (simplificados)
        g2.setColor(new Color(20, 20, 20));
        g2.fillRect(x + 3, y + 3, 5, 2);
        g2.fillRect(x + 3, y + 6, 5, 2);
        g2.fillRect(x + w - 8, y + 3, 5, 2);
        g2.fillRect(x + w - 8, y + 6, 5, 2);
        g2.fillRect(x + 3, y + h - 8, 5, 2);
        g2.fillRect(x + 3, y + h - 5, 5, 2);
        g2.fillRect(x + w - 8, y + h - 8, 5, 2);
        g2.fillRect(x + w - 8, y + h - 5, 5, 2);
    }

    /**
     * Bandera de Camerun: tricolor vertical verde, rojo, amarillo con estrella dorada central.
     */
    private static void drawCameroon(Graphics2D g2, int x, int y, int w, int h) {
        int stripeW = w / 3;
        // Franja verde
        g2.setColor(new Color(0, 122, 94));
        g2.fillRect(x, y, stripeW, h);
        // Franja roja central
        g2.setColor(new Color(206, 17, 38));
        g2.fillRect(x + stripeW, y, stripeW, h);
        // Franja amarilla
        g2.setColor(new Color(252, 209, 22));
        g2.fillRect(x + stripeW * 2, y, w - stripeW * 2, h);

        // Estrella dorada central de 5 puntas
        int cx = x + w / 2;
        int cy = y + h / 2;
        int starR = Math.max(3, h / 5);
        drawStar(g2, cx, cy, starR, new Color(255, 223, 0));
    }

    /**
     * Bandera de Nigeria: tricolor vertical verde, blanco, verde.
     */
    private static void drawNigeria(Graphics2D g2, int x, int y, int w, int h) {
        int stripeW = w / 3;
        // Franja verde izquierda
        g2.setColor(new Color(0, 135, 81));
        g2.fillRect(x, y, stripeW, h);
        // Franja blanca central
        g2.setColor(Color.WHITE);
        g2.fillRect(x + stripeW, y, stripeW, h);
        // Franja verde derecha
        g2.setColor(new Color(0, 135, 81));
        g2.fillRect(x + stripeW * 2, y, w - stripeW * 2, h);
    }

    /**
     * Bandera de Estados Unidos: 13 franjas horizontales y canton azul con estrellas.
     */
    private static void drawUSA(Graphics2D g2, int x, int y, int w, int h) {
        // Fondo blanco
        g2.setColor(Color.WHITE);
        g2.fillRect(x, y, w, h);

        // 7 franjas rojas
        g2.setColor(new Color(179, 25, 66));
        double stripeH = (double) h / 13.0;
        for (int i = 0; i < 13; i += 2) {
            int sy = (int) Math.round(y + i * stripeH);
            int sh = (int) Math.ceil(stripeH);
            g2.fillRect(x, sy, w, sh);
        }

        // Canton azul
        int cantonW = (int) (w * 0.42);
        int cantonH = (int) Math.round(7 * stripeH);
        g2.setColor(new Color(10, 49, 97));
        g2.fillRect(x, y, cantonW, cantonH);

        // Estrellas blancas en el canton
        g2.setColor(Color.WHITE);
        int cols = 4;
        int rows = 3;
        int stepX = cantonW / (cols + 1);
        int stepY = cantonH / (rows + 1);
        for (int r = 1; r <= rows; r++) {
            for (int c = 1; c <= cols; c++) {
                g2.fillRect(x + c * stepX - 1, y + r * stepY - 1, 2, 2);
            }
        }
    }

    /**
     * Dibuja una estrella regular de 5 puntas.
     */
    private static void drawStar(Graphics2D g2, int cx, int cy, int radius, Color color) {
        int innerRadius = radius / 2;
        Polygon star = new Polygon();
        for (int i = 0; i < 10; i++) {
            double angle = -Math.PI / 2 + i * Math.PI / 5;
            int r = (i % 2 == 0) ? radius : innerRadius;
            star.addPoint((int) (cx + r * Math.cos(angle)), (int) (cy + r * Math.sin(angle)));
        }
        g2.setColor(color);
        g2.fillPolygon(star);
    }
}
