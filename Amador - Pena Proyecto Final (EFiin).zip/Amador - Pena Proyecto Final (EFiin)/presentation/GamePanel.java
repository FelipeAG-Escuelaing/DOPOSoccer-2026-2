package presentation;

import domain.DOPOSoccer;
import javax.swing.JPanel;

/**
 * Clase base para paneles visuales del juego que interactuan con la fachada del dominio.
 */
public abstract class GamePanel extends JPanel {

    // Fachada central del juego

    protected final DOPOSoccer facade;

    /**
     * Constructor que enlaza el panel con la fachada.
     * 
     * @param facade Fachada principal del juego.
     */
    public GamePanel(DOPOSoccer facade) {
        this.facade = facade;
    }

    /**
     * Retorna la fachada del juego asociada a este panel.
     * 
     * @return Fachada DOPOSoccer.
     */
    public DOPOSoccer getFacade() {
        return facade;
    }
}

