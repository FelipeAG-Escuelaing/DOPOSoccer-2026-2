package test.domain;

import domain.CharacterType;
import domain.DOPOSoccer;
import domain.DOPOSoccerException;
import domain.Field;
import domain.GoalMatch;
import domain.Match;
import domain.Player;
import domain.PlayerProgress;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

import java.io.File;

/**
 * Pruebas unitarias para validar los mecanismos de persistencia:
 * Guardar y abrir partidas completas en curso y guardar/cargar el progreso de puntos y mejoras.
 */
public class PersistenceTest {

    @Test
    public void testSaveAndLoadMatchState() throws Exception {
        DOPOSoccer facade = new DOPOSoccer();
        facade.configureAndStartMatch("PvP", "TIME", CharacterType.SOUTH_KOREA, CharacterType.USA, 90, 1000.0, 550.0);

        Match match = facade.getCurrentMatch();
        match.getPlayer1().getPosition().set(350.0, 400.0);
        match.getPlayer1().takeDamage(25.0);
        match.getPlayer1().addPower(50.0);
        match.getMainBall().getPosition().set(480.0, 300.0);

        File tempFile = File.createTempFile("doposoccer_test_match", ".dopo");
        tempFile.deleteOnExit();

        facade.saveMatch(tempFile);
        assertTrue(tempFile.exists() && tempFile.length() > 0);

        DOPOSoccer loadedFacade = new DOPOSoccer();
        loadedFacade.loadMatch(tempFile);

        Match loadedMatch = loadedFacade.getCurrentMatch();
        assertNotNull(loadedMatch);
        assertEquals(350.0, loadedMatch.getPlayer1().getPosition().getX(), 1e-4);
        assertEquals(400.0, loadedMatch.getPlayer1().getPosition().getY(), 1e-4);
        assertEquals(match.getPlayer1().getCurrentHealth(), loadedMatch.getPlayer1().getCurrentHealth(), 1e-4);
        assertEquals(50.0, loadedMatch.getPlayer1().getPowerEnergy(), 1e-4);
        assertEquals(480.0, loadedMatch.getMainBall().getPosition().getX(), 1e-4);

        loadedFacade.update(0.02);
        assertTrue(loadedFacade.isMatchActive());
    }

    @Test
    public void testSaveAndLoadPlayerProgress() throws Exception {
        Field f = new Field();
        Player p = new Player(1, "Campeon ECI", CharacterType.CAMEROON, 200.0, f.getGroundY(), 1.0);
        p.setAccumulatedPoints(3500);
        p.getStats().setSpeed(4);
        p.getStats().setJump(3);
        p.getStats().setKick(5);
        p.getStats().setSurvival(4);

        File tempFile = File.createTempFile("player_progress_test", ".txt");
        tempFile.deleteOnExit();

        PlayerProgress progress = new PlayerProgress(p);
        progress.saveToTextFile(tempFile);
        assertTrue(tempFile.exists() && tempFile.length() > 0);

        PlayerProgress loadedProgress = PlayerProgress.loadFromTextFile(tempFile);
        assertEquals("Campeon ECI", loadedProgress.getPlayerName());
        assertEquals(CharacterType.CAMEROON, loadedProgress.getCharacterType());
        assertEquals(3500, loadedProgress.getAccumulatedPoints());
        assertEquals(4, loadedProgress.getSpeed());
        assertEquals(3, loadedProgress.getJump());
        assertEquals(5, loadedProgress.getKick());
        assertEquals(4, loadedProgress.getSurvival());

        Player newPlayer = new Player(2, "Novato", CharacterType.SOUTH_KOREA, 500.0, f.getGroundY(), -1.0);
        loadedProgress.applyToPlayer(newPlayer);

        assertEquals(3500, newPlayer.getAccumulatedPoints());
        assertEquals(4, newPlayer.getStats().getSpeed());
        assertEquals(5, newPlayer.getStats().getKick());
    }

    @Test
    public void testFileErrorHandling() {
        DOPOSoccer facade = new DOPOSoccer();
        File nonExistent = new File("archivo_que_no_existe_12345.dopo");

        boolean threw = false;
        try {
            facade.loadMatch(nonExistent);
        } catch (DOPOSoccerException e) {
            threw = true;
            assertTrue(e.getMessage().contains(DOPOSoccerException.FILE_ERROR));
        }
        assertTrue(threw);
    }
}
