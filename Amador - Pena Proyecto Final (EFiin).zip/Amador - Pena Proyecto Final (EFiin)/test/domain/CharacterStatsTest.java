package test.domain;

import domain.CharacterStats;
import domain.CharacterType;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 * Pruebas unitarias para validar las formulas matematicas oficiales de estadisticas y danio:
 *  - multiplicadorKick = 1 + 0.10 * (Kick - 1)
 *  - VidaMax = 100 * (1 + 0.10 * (Survival - 1))
 *  - DanioPatada = 10 * multiplicadorKick
 *  - DanioPoder = DanioTiro * multiplicadorKick
 */
public class CharacterStatsTest {

    @Test
    public void testOfficialFormulasKickMultiplier() {
        // Kick = 1 -> mult = 1 + 0.10 * 0 = 1.0
        CharacterStats s1 = new CharacterStats(3, 3, 1, 3);
        assertEquals(1.0, s1.getMultiplicadorKick(), 1e-4);

        // Kick = 4 (Corea del Sur) -> mult = 1 + 0.10 * 3 = 1.30
        CharacterStats s4 = new CharacterStats(3, 3, 4, 3);
        assertEquals(1.30, s4.getMultiplicadorKick(), 1e-4);

        // Kick = 5 -> mult = 1 + 0.10 * 4 = 1.40
        CharacterStats s5 = new CharacterStats(3, 3, 5, 3);
        assertEquals(1.40, s5.getMultiplicadorKick(), 1e-4);
    }

    @Test
    public void testOfficialFormulasVidaMax() {
        // Survival = 1 -> VidaMax = 100 * (1 + 0.10 * 0) = 100
        CharacterStats s1 = new CharacterStats(3, 3, 3, 1);
        assertEquals(100.0, s1.getVidaMax(), 1e-4);

        // Survival = 3 -> VidaMax = 100 * (1 + 0.10 * 2) = 120
        CharacterStats s3 = new CharacterStats(3, 3, 3, 3);
        assertEquals(120.0, s3.getVidaMax(), 1e-4);

        // Survival = 4 (Camerun) -> VidaMax = 100 * (1 + 0.10 * 3) = 130
        CharacterStats s4 = new CharacterStats(3, 3, 3, 4);
        assertEquals(130.0, s4.getVidaMax(), 1e-4);
    }

    @Test
    public void testOfficialFormulasDanioPatada() {
        // DanioPatada = 10 * multiplicadorKick
        CharacterStats s1 = new CharacterStats(3, 3, 1, 3);
        assertEquals(10.0, s1.getDanioPatada(), 1e-4);

        CharacterStats s4 = new CharacterStats(3, 3, 4, 3);
        assertEquals(13.0, s4.getDanioPatada(), 1e-4);
    }

    @Test
    public void testOfficialFormulasDanioPoder() {
        // DanioPoder = DanioTiro * multiplicadorKick
        // Camerun: Danio base = 60, Kick = 3 -> mult = 1.20 -> DanioPoder = 60 * 1.20 = 72.0
        CharacterStats cameroonStats = CharacterType.CAMEROON.createDefaultStats();
        assertEquals(1.20, cameroonStats.getMultiplicadorKick(), 1e-4);
        assertEquals(72.0, cameroonStats.getDanioPoder(60.0), 1e-4);

        // Corea del Sur: Danio base = 40, Kick = 4 -> mult = 1.30 -> DanioPoder = 40 * 1.30 = 52.0
        CharacterStats koreaStats = CharacterType.SOUTH_KOREA.createDefaultStats();
        assertEquals(1.30, koreaStats.getMultiplicadorKick(), 1e-4);
        assertEquals(52.0, koreaStats.getDanioPoder(40.0), 1e-4);

        // Estados Unidos: Danio base = 30, Kick = 3 -> mult = 1.20 -> DanioPoder = 30 * 1.20 = 36.0
        CharacterStats usaStats = CharacterType.USA.createDefaultStats();
        assertEquals(36.0, usaStats.getDanioPoder(30.0), 1e-4);
    }

    @Test
    public void testStatsBoundsClamping() {
        CharacterStats low = new CharacterStats(-5, 0, -2, -1);
        assertEquals(1, low.getSpeed());
        assertEquals(1, low.getJump());
        assertEquals(1, low.getKick());
        assertEquals(1, low.getSurvival());

        CharacterStats high = new CharacterStats(99, 15, 12, 50);
        assertEquals(10, high.getSpeed());
        assertEquals(10, high.getJump());
        assertEquals(10, high.getKick());
        assertEquals(10, high.getSurvival());
    }
}
