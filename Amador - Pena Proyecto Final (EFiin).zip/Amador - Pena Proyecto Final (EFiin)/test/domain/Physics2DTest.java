package test.domain;

import domain.Ball;
import domain.CircleHitbox;
import domain.Vector2D;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 * Pruebas unitarias para el motor matematico de fisica 2D en Java.
 */
public class Physics2DTest {

    @Test
    public void testVector2DOperations() {
        Vector2D v1 = new Vector2D(3.0, 4.0);
        assertEquals(5.0, v1.magnitude(), 1e-4);

        v1.add(1.0, 2.0);
        assertEquals(4.0, v1.getX(), 1e-4);
        assertEquals(6.0, v1.getY(), 1e-4);

        v1.multiply(0.5);
        assertEquals(2.0, v1.getX(), 1e-4);
        assertEquals(3.0, v1.getY(), 1e-4);

        Vector2D norm = new Vector2D(0.0, 10.0).normalize();
        assertEquals(0.0, norm.getX(), 1e-4);
        assertEquals(1.0, norm.getY(), 1e-4);
    }

    @Test
    public void testCircleHitboxIntersections() {
        CircleHitbox c1 = new CircleHitbox(new Vector2D(100.0, 100.0), 20.0);
        CircleHitbox c2 = new CircleHitbox(new Vector2D(130.0, 100.0), 20.0);
        CircleHitbox c3 = new CircleHitbox(new Vector2D(200.0, 100.0), 20.0);

        // c1 y c2 solapan (distancia 30 <= radio1 + radio2 = 40)
        assertTrue(c1.intersects(c2));

        // c1 y c3 no solapan (distancia 100 > 40)
        assertFalse(c1.intersects(c3));

        // Interseccion con rectangulo AABB
        assertTrue(c1.intersectsRect(90.0, 90.0, 50.0, 50.0));
        assertFalse(c1.intersectsRect(300.0, 300.0, 50.0, 50.0));
    }

    @Test
    public void testBallFloorBounceAndRestitution() {
        Ball ball = new Ball(500.0, 480.0);
        ball.applyImpulse(0.0, 200.0);

        // Avanzar tiempo para que toque el suelo (groundY = 500)
        ball.updatePhysics(0.1, 1000.0, 500.0, 320.0, 80.0);

        // Al rebotar, la velocidad vertical debe ser negativa (hacia arriba) por restitucion
        assertTrue(ball.getVelocity().getY() <= 0.0);
        assertTrue(ball.getPosition().getY() <= 500.0 - ball.getRadius());
    }

    @Test
    public void testBallCrossbarBounce() {
        // Balon cayendo justo sobre el travesano del arco izquierdo (crossbarY = 320, depth = 80)
        Ball ball = new Ball(75.0, 315.0);
        ball.applyImpulse(0.0, 300.0);

        ball.updatePhysics(0.05, 1000.0, 500.0, 320.0, 80.0);

        // Debe rebotar hacia arriba
        assertTrue(ball.getVelocity().getY() <= 0.0);
    }
}
