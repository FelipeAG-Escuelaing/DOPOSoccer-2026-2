package test.domain;

import domain.CharacterType;
import domain.DOPOSoccer;
import domain.DOPOSoccerException;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 * Pruebas unitarias para la Fachada del Dominio (DOPOSoccer):
 *  - Configuracion y arranque de partidos.
 *  - Manejo de excepciones y registro de logs de error.
 *  - Delegacion de acciones de jugadores P1 y P2.
 *  - Activacion de aura de poder.
 *  - Pausa, reinicio y mejoras de estadisticas.
 */
public class DOPOSoccerTest {

    @Test
    public void testFacadeInitialization() {
        DOPOSoccer facade = new DOPOSoccer();
        assertTrue(facade.isMatchActive());
        assertFalse(facade.isMatchPaused());
        assertFalse(facade.isGameOver());
        assertNotNull(facade.getCurrentMatch());
    }

    @Test
    public void testConfigurationValidation() {
        DOPOSoccer facade = new DOPOSoccer();

        boolean thrown = false;
        try {
            facade.configureAndStartMatch("PvP", "TIME", null, CharacterType.CAMEROON, 60, 1000, 550);
        } catch (DOPOSoccerException e) {
            thrown = true;
            assertEquals(DOPOSoccerException.NULL_CHARACTER, e.getMessage());
        }
        assertTrue(thrown);

        thrown = false;
        try {
            facade.configureAndStartMatch("PvP", "TIME", CharacterType.SOUTH_KOREA, CharacterType.CAMEROON, 60, -100, 550);
        } catch (DOPOSoccerException e) {
            thrown = true;
            assertEquals(DOPOSoccerException.INVALID_CONFIGURATION, e.getMessage());
        }
        assertTrue(thrown);
    }

    @Test
    public void testPauseAndRestart() throws DOPOSoccerException {
        DOPOSoccer facade = new DOPOSoccer();
        assertFalse(facade.isMatchPaused());

        facade.togglePause();
        assertTrue(facade.isMatchPaused());

        facade.togglePause();
        assertFalse(facade.isMatchPaused());

        facade.restartCurrentMatch();
        assertTrue(facade.isMatchActive());
        assertFalse(facade.isMatchPaused());
    }

    @Test
    public void testPlayerActionsDelegation() throws DOPOSoccerException {
        DOPOSoccer facade = new DOPOSoccer();
        facade.configureAndStartMatch("PvP", "TIME", CharacterType.SOUTH_KOREA, CharacterType.USA, 60, 1000, 550);

        // Movimientos P1
        facade.moveP1Right();
        assertTrue(facade.getCurrentMatch().getPlayer1().getVelocity().getX() > 0);
        facade.stopP1Horizontal();
        assertEquals(0.0, facade.getCurrentMatch().getPlayer1().getVelocity().getX(), 1e-4);
        facade.jumpP1();
        assertFalse(facade.getCurrentMatch().getPlayer1().isGrounded());

        // Movimientos P2
        facade.moveP2Left();
        assertTrue(facade.getCurrentMatch().getPlayer2().getVelocity().getX() < 0);
        facade.stopP2Horizontal();
        assertEquals(0.0, facade.getCurrentMatch().getPlayer2().getVelocity().getX(), 1e-4);

        // Activacion de poder P1
        facade.getCurrentMatch().getPlayer1().addPower(100.0);
        facade.powerP1();
        assertTrue(facade.getCurrentMatch().getPlayer1().hasActivePower());
    }

    @Test
    public void testStatUpgradeThroughFacade() {
        DOPOSoccer facade = new DOPOSoccer();
        facade.getCurrentMatch().getPlayer1().addPoints(5000);
        boolean upgraded = facade.upgradeStat(1, "speed");
        assertTrue(upgraded);
    }

    @Test
    public void testErrorLogTracking() {
        DOPOSoccerException.clearErrorLog();
        new DOPOSoccerException("Error de prueba 1");
        new DOPOSoccerException("Error de prueba 2");

        DOPOSoccer facade = new DOPOSoccer();
        assertTrue(facade.getDomainErrorLog().size() >= 2);
    }
}
