package test.domain;

import domain.Ball;
import domain.CharacterType;
import domain.ClumsyProfile;
import domain.DOPOSoccer;
import domain.DOPOSoccerException;
import domain.DefensiveProfile;
import domain.ExpertProfile;
import domain.Field;
import domain.GoalMatch;
import domain.MachinePlayer;
import domain.MachineProfile;
import domain.OffensiveProfile;
import domain.Player;
import domain.TimeMatch;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 * Pruebas unitarias para validar la inteligencia artificial y los 4 perfiles
 * de la maquina en DOPOSoccer: Torpe, Ofensiva, Defensiva y Experta.
 */
public class MachinePlayerTest {

    @Test
    public void testMachinePlayerInitialization() {
        MachineProfile prof = new OffensiveProfile();
        MachinePlayer mp = new MachinePlayer(2, "CPU", CharacterType.USA, 800.0, 500.0, -1.0, prof);

        assertEquals("CPU", mp.getName());
        assertEquals(2, mp.getId());
        assertEquals(CharacterType.USA, mp.getCharacterType());
        assertEquals("Ofensiva", mp.getProfile().getProfileName());

        // Cambio de perfil en caliente
        mp.setProfile(new DefensiveProfile());
        assertEquals("Defensiva", mp.getProfile().getProfileName());

        mp.setProfile(new ClumsyProfile());
        assertEquals("Torpe", mp.getProfile().getProfileName());

        mp.setProfile(new ExpertProfile());
        assertEquals("Experta", mp.getProfile().getProfileName());
    }

    @Test
    public void testClumsyProfileBehavior() {
        Field f = new Field();
        Player p1 = new Player(1, "Humano", CharacterType.SOUTH_KOREA, 200.0, f.getGroundY(), 1.0);
        ClumsyProfile clumsy = new ClumsyProfile();
        MachinePlayer p2 = new MachinePlayer(2, "CPU Torpe", CharacterType.CAMEROON, 800.0, f.getGroundY(), -1.0, clumsy);
        GoalMatch match = new GoalMatch(f, p1, p2, 5);

        for (int i = 0; i < 30; i++) {
            match.update(0.02);
        }
        assertTrue(p2.getPosition().getX() > 0);
    }

    @Test
    public void testOffensiveProfileBehavior() {
        Field f = new Field();
        Player p1 = new Player(1, "Humano", CharacterType.SOUTH_KOREA, 200.0, f.getGroundY(), 1.0);
        OffensiveProfile offensive = new OffensiveProfile();
        MachinePlayer p2 = new MachinePlayer(2, "CPU Ofensiva", CharacterType.CAMEROON, 800.0, f.getGroundY(), -1.0, offensive);
        TimeMatch match = new TimeMatch(f, p1, p2, 60);

        Ball ball = match.getMainBall();
        ball.getPosition().set(650.0, f.getGroundY());
        ball.getVelocity().set(0.0, 0.0);

        double startX = p2.getPosition().getX();
        for (int i = 0; i < 15; i++) {
            match.update(0.02);
        }

        assertTrue(p2.getPosition().getX() < startX);
    }

    @Test
    public void testDefensiveProfileBehavior() {
        Field f = new Field();
        Player p1 = new Player(1, "Humano", CharacterType.SOUTH_KOREA, 200.0, f.getGroundY(), 1.0);
        DefensiveProfile defensive = new DefensiveProfile();
        MachinePlayer p2 = new MachinePlayer(2, "CPU Defensiva", CharacterType.NIGERIA, 850.0, f.getGroundY(), -1.0, defensive);
        GoalMatch match = new GoalMatch(f, p1, p2, 3);

        Ball ball = match.getMainBall();
        ball.getPosition().set(250.0, f.getGroundY());

        for (int i = 0; i < 20; i++) {
            match.update(0.02);
        }
        assertTrue(p2.getPosition().getX() > f.getWidth() * 0.50);
    }

    @Test
    public void testExpertProfileBehavior() {
        Field f = new Field();
        Player p1 = new Player(1, "Humano", CharacterType.SOUTH_KOREA, 200.0, f.getGroundY(), 1.0);
        ExpertProfile expert = new ExpertProfile();
        MachinePlayer p2 = new MachinePlayer(2, "CPU Experta", CharacterType.USA, 800.0, f.getGroundY(), -1.0, expert);
        TimeMatch match = new TimeMatch(f, p1, p2, 60);

        Ball ball = match.getMainBall();
        ball.getPosition().set(700.0, f.getGroundY() - 80.0);
        ball.getVelocity().set(-50.0, 100.0);

        for (int i = 0; i < 20; i++) {
            match.update(0.02);
        }
        assertTrue(p2.getPosition().getX() > 0 && p2.getPosition().getX() < f.getWidth());
    }

    @Test
    public void testFacadePvMConfiguration() throws DOPOSoccerException {
        DOPOSoccer facade = new DOPOSoccer();
        facade.configureAndStartMatch("PvM", "Experta", "TIME",
                CharacterType.SOUTH_KOREA, CharacterType.NIGERIA,
                60, Field.DEFAULT_WIDTH, Field.DEFAULT_HEIGHT);

        assertTrue(facade.isPlayer2Machine());
        assertTrue(facade.getCurrentMatch().getPlayer2() instanceof MachinePlayer);
        MachinePlayer mp = (MachinePlayer) facade.getCurrentMatch().getPlayer2();
        assertEquals("Experta", mp.getProfile().getProfileName());
    }
}
