package test.domain;

import domain.Ball;
import domain.CharacterType;
import domain.ConfusedState;
import domain.DOPOSoccerException;
import domain.ElectrocutedState;
import domain.Field;
import domain.GoalMatch;
import domain.Player;
import domain.PushedState;
import domain.StunnedState;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 * Pruebas unitarias para validar las 8 Reglas Oficiales de Tiros de Poder:
 * - Llenado en 10s y +25% al recibir gol
 * - Vaciado inmediato al activar y recarga continua
 * - Aura visible sin limite de tiempo
 * - Al tocar el balon se dispara el poder y desaparece el aura
 * - Danio y efecto al golpear al rival
 * - Gol directo sin tocar al rival no hace danio ni efecto
 * - No activar otro poder mientras tenga el poder activo
 * - Reemplazo no acumulativo de efectos
 */
public class PowerShotTest {

    @Test
    public void testSouthKoreaPowerShotRules() throws DOPOSoccerException {
        Field f = new Field();
        Player p1 = new Player(1, "Corea", CharacterType.SOUTH_KOREA, 200.0, 500.0, 1.0);
        Player p2 = new Player(2, "Rival", CharacterType.CAMEROON, 800.0, 500.0, -1.0);
        GoalMatch match = new GoalMatch(f, p1, p2, 5);

        // Sin energia: excepcion
        boolean thrown = false;
        try {
            p1.activatePowerAura();
        } catch (DOPOSoccerException e) {
            thrown = true;
            assertEquals(DOPOSoccerException.POWER_NOT_READY, e.getMessage());
        }
        assertTrue(thrown);

        // Cargar energia
        p1.addPower(100.0);
        p1.activatePowerAura();

        // Barra vacia y aura visible activa
        assertEquals(0.0, p1.getPowerEnergy(), 1e-4);
        assertTrue(p1.hasActivePower());

        // No puede activar otro poder mientras tenga el aura activa
        thrown = false;
        try {
            p1.activatePowerAura();
        } catch (DOPOSoccerException e) {
            thrown = true;
        }
        assertTrue(thrown);

        // Al tocar el balon, se ejecuta el tiro de poder y el aura desaparece
        Ball ball = match.getMainBall();
        ball.getPosition().set(p1.getPosition().getX() + 20, p1.getPosition().getY() - 40);
        match.update(0.02);

        // El aura del jugador desaparecio y el balon ahora tiene el poder
        assertFalse(p1.hasActivePower());
        assertTrue(ball.isPowerShot());
        assertEquals("AURA_AZUL", ball.getActiveEffect());

        // Si golpea al rival, se aplican danio y efecto
        double p2LifeBefore = p2.getCurrentHealth();
        ball.getPosition().set(p2.getPosition().getX() - 10, p2.getPosition().getY() - 40);
        match.update(0.02);

        // Danio: 40 * 1.30 = 52.0
        assertEquals(p2LifeBefore - 52.0, p2.getCurrentHealth(), 1e-4);
        assertTrue(p2.getState() instanceof PushedState);
        assertEquals("EMPUJADO", p2.getState().getStateName());
    }

    @Test
    public void testCameroonPowerShotRules() throws DOPOSoccerException {
        Field f = new Field();
        Player p1 = new Player(1, "Camerun", CharacterType.CAMEROON, 200.0, 500.0, 1.0);
        Player p2 = new Player(2, "Rival", CharacterType.SOUTH_KOREA, 800.0, 500.0, -1.0);
        GoalMatch match = new GoalMatch(f, p1, p2, 5);

        p1.addPower(100.0);
        p1.activatePowerAura();

        Ball ball = match.getMainBall();
        ball.getPosition().set(p1.getPosition().getX() + 20, p1.getPosition().getY() - 40);
        match.update(0.02);

        assertEquals("RAYO_ELECTRICO", ball.getActiveEffect());

        // Impactar a rival
        double p2LifeBefore = p2.getCurrentHealth();
        ball.getPosition().set(p2.getPosition().getX() - 10, p2.getPosition().getY() - 40);
        match.update(0.02);

        // Danio: 60 * 1.20 = 72.0
        assertEquals(p2LifeBefore - 72.0, p2.getCurrentHealth(), 1e-4);
        assertTrue(p2.getState() instanceof ElectrocutedState);
        assertFalse(p2.getState().canJump());
        assertEquals(0.50, p2.getState().getSpeedMultiplier(), 1e-4);
    }

    @Test
    public void testNigeriaPowerShotRules() throws DOPOSoccerException {
        Field f = new Field();
        Player p1 = new Player(1, "Nigeria", CharacterType.NIGERIA, 200.0, 500.0, 1.0);
        Player p2 = new Player(2, "Rival", CharacterType.SOUTH_KOREA, 800.0, 500.0, -1.0);
        GoalMatch match = new GoalMatch(f, p1, p2, 5);

        p1.addPower(100.0);
        p1.activatePowerAura();

        Ball ball = match.getMainBall();
        ball.getPosition().set(p1.getPosition().getX() + 20, p1.getPosition().getY() - 40);
        match.update(0.02);

        assertEquals("TORNADO", ball.getActiveEffect());

        // Impactar a rival
        ball.getPosition().set(p2.getPosition().getX() - 10, p2.getPosition().getY() - 40);
        match.update(0.02);

        assertTrue(p2.getState().getStateName().contains("INCONSCIENTE"));
        assertFalse(p2.getState().canMove());
        assertFalse(p2.getState().canJump());
        assertTrue(p2.getVelocity().getY() < 0);
    }

    @Test
    public void testUSAPowerShotRules() throws DOPOSoccerException {
        Field f = new Field();
        Player p1 = new Player(1, "USA", CharacterType.USA, 200.0, 500.0, 1.0);
        Player p2 = new Player(2, "Rival", CharacterType.CAMEROON, 800.0, 500.0, -1.0);
        GoalMatch match = new GoalMatch(f, p1, p2, 5);

        p1.addPower(100.0);
        p1.activatePowerAura();

        Ball ball = match.getMainBall();
        ball.getPosition().set(p1.getPosition().getX() + 20, p1.getPosition().getY() - 40);
        match.update(0.02);

        // El balon se divide en 8 balones identicos (1 real + 7 falsos)
        assertEquals(8, match.getBalls().size());

        // Impactar al rival
        ball.getPosition().set(p2.getPosition().getX() - 10, p2.getPosition().getY() - 40);
        match.update(0.02);

        assertTrue(p2.getState() instanceof ConfusedState);
        assertTrue(p2.getState().isInvertedControls());
    }

    @Test
    public void testRule6GoalWithoutTouchingRivalHasNoDamageNorEffect() throws DOPOSoccerException {
        Field f = new Field();
        Player p1 = new Player(1, "Corea", CharacterType.SOUTH_KOREA, 200.0, 500.0, 1.0);
        Player p2 = new Player(2, "Rival", CharacterType.CAMEROON, 800.0, 500.0, -1.0);
        GoalMatch match = new GoalMatch(f, p1, p2, 5);

        p1.addPower(100.0);
        p1.activatePowerAura();

        Ball ball = match.getMainBall();
        ball.getPosition().set(p1.getPosition().getX() + 20, p1.getPosition().getY() - 40);
        match.update(0.02);

        double p2LifeBefore = p2.getCurrentHealth();

        // El balon entra directo al arco derecho sin tocar a P2
        ball.getPosition().set(f.getWidth() - 10.0, 400.0);
        match.update(0.05);

        // Gol contado
        assertEquals(1, match.getScore1());
        // No hay dano ni efecto en el rival
        assertEquals(p2LifeBefore, p2.getCurrentHealth(), 1e-4);
        assertEquals("NORMAL", p2.getState().getStateName());
    }

    @Test
    public void testRule8EffectsDoNotStack() throws DOPOSoccerException {
        Player p2 = new Player(2, "Rival", CharacterType.CAMEROON, 800.0, 500.0, -1.0);

        // Primero bajo electrocutado
        p2.setState(new ElectrocutedState(3.0));
        assertEquals("ELECTROCUTADO", p2.getState().getStateName());

        // Luego recibe tiro de Corea: nuevo efecto reemplaza al anterior
        p2.setState(new PushedState(1.5, 1.0));
        assertEquals("EMPUJADO", p2.getState().getStateName());
        assertTrue(p2.getState() instanceof PushedState);
    }

    @Test
    public void testCannotActivatePowerWhileStunned() {
        Player p1 = new Player(1, "Corea", CharacterType.SOUTH_KOREA, 200.0, 500.0, 1.0);
        p1.addPower(100.0);
        p1.setState(new StunnedState(3.0));

        boolean thrown = false;
        try {
            p1.activatePowerAura();
        } catch (DOPOSoccerException e) {
            thrown = true;
            assertEquals(DOPOSoccerException.PLAYER_STUNNED, e.getMessage());
        }
        assertTrue(thrown);
    }
}
