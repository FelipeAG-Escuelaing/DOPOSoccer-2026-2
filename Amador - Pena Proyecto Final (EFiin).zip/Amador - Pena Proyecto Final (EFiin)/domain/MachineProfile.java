package domain;

import java.io.Serializable;

/**
 * Interfaz que define la estrategia de comportamiento para la maquina (IA).
 * Permite implementar diferentes perfiles de dificultad y estilo de juego.
 */
public interface MachineProfile extends Serializable {

    /**
     * Retorna el nombre legible del perfil de la maquina.
     * 
     * @return Nombre del perfil (Torpe, Ofensiva, Defensiva, Experta).
     */
    String getProfileName();

    /**
     * Decide y ejecuta las acciones del jugador de la maquina en cada tick.
     * 
     * @param machine Jugador controlado por la maquina.
     * @param match Partido en curso para consultar posiciones y balon.
     * @param dt Delta time en segundos.
     */
    void decideAction(MachinePlayer machine, Match match, double dt);
}
