package domain;

/**
 * Estado de aturdimiento cuando la vida del jugador llega a cero.
 * El jugador queda inmovilizado durante 3 segundos.
 * Al terminar recupera su vida maxima y vuelve al estado normal.
 */
public class StunnedState extends TimedState {

    /**
     * Constructor por defecto con la duracion oficial de 3.0 segundos.
     */
    public StunnedState() {
        this(3.0);
    }

    /**
     * Constructor con duracion configurable para pruebas.
     * 
     * @param duration Segundos que durara aturdido el jugador.
     */
    public StunnedState(double duration) {
        super(duration);
    }

    @Override
    protected void onExpire(Player player) {
        player.restoreHealth();
        super.onExpire(player);
    }

    @Override
    public boolean canMove() {
        return false;
    }

    @Override
    public boolean canJump() {
        return false;
    }

    @Override
    public boolean canKick() {
        return false;
    }

    @Override
    public boolean canUsePower() {
        return false;
    }

    @Override
    public double getSpeedMultiplier() {
        return 0.0;
    }

    @Override
    public String getStateName() {
        return "ATURDIDO";
    }
}
