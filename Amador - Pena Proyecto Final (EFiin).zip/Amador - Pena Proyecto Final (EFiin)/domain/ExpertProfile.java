package domain;

/**
 * Perfil Experto de la maquina.
 * Toma decisiones estrategicas segun el marcador, tiempo, estado del rival
 * y calcula la trayectoria del balon para anticipar sus rebotes.
 */
public class ExpertProfile implements MachineProfile {

    private static final long serialVersionUID = 1L;

    public ExpertProfile() {
        // Constructor por defecto
    }

    @Override
    public String getProfileName() {
        return "Experta";
    }

    @Override
    public void decideAction(MachinePlayer machine, Match match, double dt) {
        if (machine == null || match == null) {
            return;
        }

        Ball ball = match.getMainBall();
        if (ball == null) {
            return;
        }

        double fieldWidth = match.getField().getWidth();
        double groundY = match.getField().getGroundY();
        double machineX = machine.getPosition().getX();
        double machineY = machine.getPosition().getY();
        double ballX = ball.getPosition().getX();
        double ballY = ball.getPosition().getY();
        double ballVx = ball.getVelocity().getX();
        double ballVy = ball.getVelocity().getY();

        // 1. Anticipacion de trayectoria: calculamos donde aterrizara el balon
        double predictedX = ballX;
        if (ballY < groundY - 30.0 && Math.abs(ballVy) > 10.0) {
            // Estimamos el tiempo de vuelo hasta el suelo con gravedad
            double timeToGround = Math.max(0.1, (groundY - ballY) / Math.max(100.0, Math.abs(ballVy)));
            predictedX = ballX + ballVx * timeToGround;
            // Limitamos dentro de la cancha
            if (predictedX < 60.0) predictedX = 60.0;
            if (predictedX > fieldWidth - 60.0) predictedX = fieldWidth - 60.0;
        }

        // 2. Evaluacion del estado del partido
        int scoreDifference = match.getScore2() - match.getScore1();
        boolean isLosing = scoreDifference < 0;
        boolean isWinning = scoreDifference > 0;

        // Si va perdiendo o esta en muerte subita, adelanta lineas ofensivas
        double targetX;
        if (isLosing || match.isSuddenDeath()) {
            targetX = predictedX + 25.0; // Se posiciona justo detras del balon para empujar
        } else if (isWinning) {
            // Si va ganando, mantiene balance defensivo cuidando su mitad
            targetX = Math.max(fieldWidth * 0.50, predictedX + 30.0);
        } else {
            targetX = predictedX + 20.0;
        }

        // 3. Movimiento inteligente hacia la posicion calculada
        if (machineX < targetX - 15.0) {
            machine.moveRight();
        } else if (machineX > targetX + 15.0) {
            machine.moveLeft();
        } else {
            machine.stopHorizontal();
        }

        // 4. Salto inteligente:
        // Solo salta si el balon viene a altura de cabezazo y esta cerca en X
        double dx = Math.abs(machineX - ballX);
        if (ballY < machineY - 30.0 && ballY > machineY - 110.0 && dx < 75.0 && machine.isGrounded()) {
            machine.jump();
        }

        // 5. Patada precisa:
        // Patea cuando el balon esta en su arco frontal (a la izquierda de la maquina)
        if (ballX < machineX && dx < 85.0 && Math.abs(machineY - ballY) < 70.0) {
            machine.kick();
        }

        // 6. Uso estrategico del superpoder:
        // Activa el poder si esta listo y el balon esta en posicion de remate o el rival esta aturdido
        if (machine.isPowerReady()) {
            Player rival = match.getPlayer1();
            boolean rivalVulnerable = (rival != null && rival.isStunned());
            boolean goodShotAngle = (ballX < machineX && dx < 120.0);

            if (rivalVulnerable || goodShotAngle || isLosing) {
                try {
                    machine.activatePowerAura();
                } catch (DOPOSoccerException e) {
                    // Ignorar si no se puede activar
                }
            }
        }
    }
}
