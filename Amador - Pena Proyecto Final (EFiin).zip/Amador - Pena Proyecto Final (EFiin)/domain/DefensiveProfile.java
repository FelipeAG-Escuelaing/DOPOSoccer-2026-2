package domain;

/**
 * Perfil Defensivo de la maquina.
 * Su maxima prioridad es proteger su arco, evitar goles rivales y despejar el balon.
 */
public class DefensiveProfile implements MachineProfile {

    private static final long serialVersionUID = 1L;

    public DefensiveProfile() {
        // Constructor por defecto
    }

    @Override
    public String getProfileName() {
        return "Defensiva";
    }

    @Override
    public void decideAction(MachinePlayer machine, Match match, double dt) {
        if (machine == null || match == null) {
            return;
        }

        Ball ball = match.getMainBall();
        if (ball == null) {
            return;
        }

        double fieldWidth = match.getField().getWidth();
        double machineX = machine.getPosition().getX();
        double machineY = machine.getPosition().getY();
        double ballX = ball.getPosition().getX();
        double ballY = ball.getPosition().getY();

        // Posicion ancla defensiva ideal frente a su propio arco (lado derecho)
        double defenseAnchorX = fieldWidth - 160.0;

        // Si el balon esta lejos en el campo rival, mantiene la posicion de guardia
        if (ballX < fieldWidth * 0.50) {
            if (machineX < defenseAnchorX - 20.0) {
                machine.moveRight();
            } else if (machineX > defenseAnchorX + 20.0) {
                machine.moveLeft();
            } else {
                machine.stopHorizontal();
            }
        } else {
            // El balon entro a su mitad defensiva: sale a interceptar y despejar
            if (ballX > machineX + 15.0) {
                // Si el balon paso detras de la maquina, corre a cubrir el arco
                machine.moveRight();
            } else {
                // Bloquea el paso del balon
                if (machineX - ballX > 45.0) {
                    machine.moveLeft();
                } else {
                    machine.stopHorizontal();
                }
            }

            // Despeje con patada si el balon esta al alcance
            double dx = Math.abs(machineX - ballX);
            double dy = Math.abs(machineY - ballY);
            if (dx < 90.0 && dy < 75.0) {
                machine.kick();
            }

            // Salto defensivo para bloquear tiros por arriba que vayan al arco
            if (ballY < machineY - 40.0 && dx < 100.0 && machine.isGrounded()) {
                machine.jump();
            }

            // Si el balon esta muy cerca del arco y tiene poder, lo usa para despejar con fuerza
            if (ballX > fieldWidth - 250.0 && machine.isPowerReady()) {
                try {
                    machine.activatePowerAura();
                } catch (DOPOSoccerException e) {
                    // Ignorar si no esta listo
                }
            }
        }
    }
}
