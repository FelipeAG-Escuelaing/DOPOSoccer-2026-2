package domain;

/**
 * Estado inconsciente infligido por el tiro de poder de Nigeria.
 * El rival es lanzado al aire y no puede moverse, saltar ni patear por 3 segundos.
 */
public class AirKnockoutState extends TimedState {

    /**
     * Constructor por defecto con la duracion oficial de 3.0 segundos.
     */
    public AirKnockoutState() {
        this(3.0);
    }

    /**
     * Constructor con duracion configurable para pruebas.
     * 
     * @param duration Segundos de duracion.
     */
    public AirKnockoutState(double duration) {
        super(duration);
    }

    @Override
    public boolean canMove() {
        return false;
    }

    @Override
    public boolean canJump() {
        return false;
    }

    @Override
    public boolean canKick() {
        return false;
    }

    @Override
    public boolean canUsePower() {
        return false;
    }

    @Override
    public double getSpeedMultiplier() {
        return 0.0;
    }

    @Override
    public String getStateName() {
        return "INCONSCIENTE";
    }
}
