package domain;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.Serializable;

/**
 * Representa el progreso persistente de un jugador en DOPOSoccer.
 * Guarda los puntos acumulados y los niveles mejorados de sus estadisticas.
 * Permite guardar y cargar tanto en formato serializado como en texto plano.
 */
public class PlayerProgress implements Serializable {

    private static final long serialVersionUID = 1L;

    private String playerName;
    private CharacterType characterType;
    private int accumulatedPoints;
    private int speed;
    private int jump;
    private int kick;
    private int survival;

    /**
     * Constructor que toma los datos de un jugador real en la cancha.
     * 
     * @param player Jugador del cual se extrae el progreso.
     */
    public PlayerProgress(Player player) {
        if (player != null) {
            this.playerName = player.getName();
            this.characterType = player.getCharacterType();
            this.accumulatedPoints = player.getAccumulatedPoints();
            CharacterStats stats = player.getStats();
            if (stats != null) {
                this.speed = stats.getSpeed();
                this.jump = stats.getJump();
                this.kick = stats.getKick();
                this.survival = stats.getSurvival();
            } else {
                this.speed = 1;
                this.jump = 1;
                this.kick = 1;
                this.survival = 1;
            }
        }
    }

    /**
     * Constructor con parametros directos.
     * 
     * @param playerName Nombre del jugador.
     * @param characterType Pais seleccionado.
     * @param points Puntos acumulados.
     * @param speed Nivel de velocidad.
     * @param jump Nivel de salto.
     * @param kick Nivel de patada.
     * @param survival Nivel de supervivencia.
     */
    public PlayerProgress(String playerName, CharacterType characterType, int points,
            int speed, int jump, int kick, int survival) {
        this.playerName = playerName;
        this.characterType = characterType != null ? characterType : CharacterType.SOUTH_KOREA;
        this.accumulatedPoints = points;
        this.speed = speed;
        this.jump = jump;
        this.kick = kick;
        this.survival = survival;
    }

    /**
     * Aplica los valores de este progreso sobre un jugador en el partido.
     * 
     * @param player Jugador a actualizar.
     */
    public void applyToPlayer(Player player) {
        if (player == null) {
            return;
        }
        player.setAccumulatedPoints(this.accumulatedPoints);
        CharacterStats stats = player.getStats();
        if (stats != null) {
            stats.setSpeed(this.speed);
            stats.setJump(this.jump);
            stats.setKick(this.kick);
            stats.setSurvival(this.survival);
            player.restoreHealth(); // Recalcula vida maxima segun nuevo survival
        }
    }

    /**
     * Guarda el progreso en un archivo de texto plano legible.
     * 
     * @param file Archivo destino.
     * @throws DOPOSoccerException Si ocurre un error de escritura.
     */
    public void saveToTextFile(File file) throws DOPOSoccerException {
        try (PrintWriter pw = new PrintWriter(new FileWriter(file))) {
            pw.println("PLAYER_NAME=" + playerName);
            pw.println("CHARACTER_TYPE=" + (characterType != null ? characterType.name() : "SOUTH_KOREA"));
            pw.println("ACCUMULATED_POINTS=" + accumulatedPoints);
            pw.println("SPEED=" + speed);
            pw.println("JUMP=" + jump);
            pw.println("KICK=" + kick);
            pw.println("SURVIVAL=" + survival);
        } catch (IOException e) {
            throw new DOPOSoccerException(DOPOSoccerException.FILE_ERROR + ": " + e.getMessage());
        }
    }

    /**
     * Carga un progreso guardado desde un archivo de texto plano.
     * 
     * @param file Archivo fuente.
     * @return Objeto PlayerProgress cargado.
     * @throws DOPOSoccerException Si el archivo no existe o el formato es incorrecto.
     */
    public static PlayerProgress loadFromTextFile(File file) throws DOPOSoccerException {
        if (file == null || !file.exists()) {
            throw new DOPOSoccerException(DOPOSoccerException.FILE_ERROR + ": El archivo no existe.");
        }

        String name = "Jugador";
        CharacterType cType = CharacterType.SOUTH_KOREA;
        int points = 0;
        int spd = 1, jmp = 1, kck = 1, surv = 1;

        try (BufferedReader br = new BufferedReader(new FileReader(file))) {
            String line;
            while ((line = br.readLine()) != null) {
                line = line.trim();
                if (line.isEmpty() || line.startsWith("#")) {
                    continue;
                }
                int eq = line.indexOf('=');
                if (eq > 0) {
                    String key = line.substring(0, eq).trim();
                    String val = line.substring(eq + 1).trim();
                    if ("PLAYER_NAME".equalsIgnoreCase(key)) {
                        name = val;
                    } else if ("CHARACTER_TYPE".equalsIgnoreCase(key)) {
                        try {
                            cType = CharacterType.valueOf(val.toUpperCase());
                        } catch (Exception ex) {
                            cType = CharacterType.SOUTH_KOREA;
                        }
                    } else if ("ACCUMULATED_POINTS".equalsIgnoreCase(key)) {
                        points = Integer.parseInt(val);
                    } else if ("SPEED".equalsIgnoreCase(key)) {
                        spd = Integer.parseInt(val);
                    } else if ("JUMP".equalsIgnoreCase(key)) {
                        jmp = Integer.parseInt(val);
                    } else if ("KICK".equalsIgnoreCase(key)) {
                        kck = Integer.parseInt(val);
                    } else if ("SURVIVAL".equalsIgnoreCase(key)) {
                        surv = Integer.parseInt(val);
                    }
                }
            }
        } catch (Exception e) {
            throw new DOPOSoccerException(DOPOSoccerException.FILE_ERROR + ": Formato invalido en " + file.getName());
        }

        return new PlayerProgress(name, cType, points, spd, jmp, kck, surv);
    }

    // Getters y Setters

    public String getPlayerName() {
        return playerName;
    }

    public CharacterType getCharacterType() {
        return characterType;
    }

    public int getAccumulatedPoints() {
        return accumulatedPoints;
    }

    public int getSpeed() {
        return speed;
    }

    public int getJump() {
        return jump;
    }

    public int getKick() {
        return kick;
    }

    public int getSurvival() {
        return survival;
    }
}
