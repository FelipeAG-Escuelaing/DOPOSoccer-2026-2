package domain;

import domain.power.PowerShot;

/**
 * Controla la fisica, gravedad, rebotes y estados del balon de futbol.
 * Tambien se usa para las 7 ilusiones falsas creadas por el poder de USA.
 */
public class Ball extends MovableEntity implements java.io.Serializable {

    private static final long serialVersionUID = 1L;

    // Radio estandar del balon de futbol

    public static final double DEFAULT_RADIUS = 16.0;

    // Aceleracion constante de gravedad hacia abajo

    public static final double GRAVITY = 650.0;

    // Coeficiente de elasticidad en los rebotes contra el suelo

    public static final double RESTITUTION = 0.75;

    // Radio fisico del balon

    private double radius;

    // Hitbox circular para detectar choques con jugadores y postes

    private CircleHitbox hitbox;

    // Bandera que indica si este balon es una ilusion falsa del poder de USA

    private boolean isIllusion;

    // Tiempo restante antes de que la ilusion falsa desaparezca

    private double illusionTimer;

    // Bandera que indica si el balon viene con un tiro de poder activo

    private boolean isPowerShot;

    // Referencia al jugador que disparo el tiro de poder

    private Player powerShooter;

    // Estrategia del tiro de poder que lleva el balon

    private PowerShot powerStrategy;

    // Nombre del efecto visual que tiene activo (ej: AURA_AZUL, RAYO_ELECTRICO)

    private String activeEffect;

    // Temporizador de duracion del efecto en el balon

    private double effectTimer;

    // Angulo de giro para animar la rotacion al rodar

    private double rotationAngle;

    // Ultimo jugador que toco o pateo el balon

    private Player lastKicker;

    /**
     * Constructor para el balon oficial reglamentario del partido.
     * 
     * @param x Posicion inicial en X.
     * @param y Posicion inicial en Y.
     */
    public Ball(double x, double y) {
        this(x, y, false);
    }

    /**
     * Constructor completo que permite crear tanto el balon real como balones de
     * ilusion.
     * 
     * @param x          Posicion inicial en X.
     * @param y          Posicion inicial en Y.
     * @param isIllusion true si es un balon falso de ilusion.
     */
    public Ball(double x, double y, boolean isIllusion) {
        super(x, y);
        this.radius = DEFAULT_RADIUS;
        this.hitbox = new CircleHitbox(this.position, this.radius);
        this.isIllusion = isIllusion;

        // Las ilusiones del poder de USA duran 2.5 segundos segun la tabla del Anexo 1
        this.illusionTimer = isIllusion ? 2.5 : 0.0;

        this.isPowerShot = false;
        this.powerShooter = null;
        this.powerStrategy = null;
        this.activeEffect = "NONE";
        this.effectTimer = 0.0;
        this.rotationAngle = 0.0;
    }

    /**
     * Retorna el vector de posicion del balon.
     * 
     * @return Vector2D de posicion.
     */
    public Vector2D getPosition() {
        return position;
    }

    /**
     * Retorna el vector de velocidad del balon.
     * 
     * @return Vector2D de velocidad.
     */
    public Vector2D getVelocity() {
        return velocity;
    }

    /**
     * Retorna el radio del balon.
     * 
     * @return Radio en pixeles.
     */
    public double getRadius() {
        return radius;
    }

    /**
     * Retorna la hitbox circular de colisiones del balon.
     * 
     * @return CircleHitbox asociada.
     */
    public CircleHitbox getHitbox() {
        return hitbox;
    }

    /**
     * Indica si el balon es una ilusion falsa.
     * 
     * @return true si es falso, false si es el balon real.
     */
    public boolean isIllusion() {
        return isIllusion;
    }

    /**
     * Permite marcar o desmarcar el balon como ilusion.
     * 
     * @param illusion true para marcarlo como ilusion.
     */
    public void setIllusion(boolean illusion) {
        isIllusion = illusion;
    }

    /**
     * Retorna los segundos restantes antes de que la ilusion desaparezca.
     * 
     * @return Tiempo en segundos.
     */
    public double getIllusionTimer() {
        return illusionTimer;
    }

    /**
     * Indica si el balon viaja con un tiro de poder activo cargado.
     * 
     * @return true si lleva tiro de poder.
     */
    public boolean isPowerShot() {
        return isPowerShot;
    }

    /**
     * Retorna el jugador que ejecuto el tiro de poder sobre el balon.
     * 
     * @return Jugador lanzador.
     */
    public Player getPowerShooter() {
        return powerShooter;
    }

    /**
     * Retorna la estrategia del tiro de poder activa en el balon.
     * 
     * @return Objeto PowerShot correspondiente.
     */
    public PowerShot getPowerStrategy() {
        return powerStrategy;
    }

    /**
     * Activa el estado de tiro de poder en el balon cuando el jugador con aura lo
     * toca.
     * 
     * @param strategy   Estrategia del poder segun el pais.
     * @param shooter    Jugador que dispara el poder.
     * @param effectName Identificador del efecto visual.
     * @param duration   Cuantos segundos dura el tiro de poder.
     */
    public void setPowerShot(PowerShot strategy, Player shooter, String effectName, double duration) {
        this.isPowerShot = true;
        this.powerStrategy = strategy;
        this.powerShooter = shooter;
        this.activeEffect = effectName != null ? effectName : "NONE";
        this.effectTimer = duration;
    }

    /**
     * Apaga el estado de poder del balon despues de golpear al rival o entrar al
     * arco.
     */
    public void consumePowerShot() {
        this.isPowerShot = false;
        this.powerStrategy = null;
        this.powerShooter = null;
        this.activeEffect = "NONE";
        this.effectTimer = 0.0;
    }

    /**
     * Retorna el nombre del efecto visual que tiene activo el balon.
     * 
     * @return Nombre del efecto o NONE.
     */
    public String getActiveEffect() {
        return activeEffect;
    }

    /**
     * Asigna un efecto visual y su duracion al balon.
     * 
     * @param effect   Nombre del efecto visual.
     * @param duration Segundos que durara visible.
     */
    public void setActiveEffect(String effect, double duration) {
        this.activeEffect = effect != null ? effect : "NONE";
        this.effectTimer = duration;
    }

    /**
     * Retorna el angulo de rotacion para el giro visual del balon.
     * 
     * @return Angulo en radianes.
     */
    public double getRotationAngle() {
        return rotationAngle;
    }

    /**
     * Retorna el ultimo jugador que contacto el balon.
     * 
     * @return Jugador que toco el balon de ultimo.
     */
    public Player getLastKicker() {
        return lastKicker;
    }

    /**
     * Guarda la referencia del jugador que acaba de patear o cabecear el balon.
     * 
     * @param kicker Jugador que hizo contacto.
     */
    public void setLastKicker(Player kicker) {
        this.lastKicker = kicker;
    }

    /**
     * Reinicia la posicion y velocidad del balon, quitando efectos activos.
     * 
     * @param x Nueva coordenada X.
     * @param y Nueva coordenada Y.
     */
    public void reset(double x, double y) {
        this.position.set(x, y);
        this.velocity.set(0.0, 0.0);
        this.isPowerShot = false;
        this.powerShooter = null;
        this.powerStrategy = null;
        this.activeEffect = "NONE";
        this.effectTimer = 0.0;
        this.rotationAngle = 0.0;
        this.lastKicker = null;
    }

    /**
     * Aplica una fuerza o impulso directo cambiando la velocidad del balon.
     * 
     * @param vx Velocidad en el eje X.
     * @param vy Velocidad en el eje Y.
     */
    public void applyImpulse(double vx, double vy) {
        this.velocity.set(vx, vy);
    }

    /**
     * Actualiza la fisica del balon en cada tick del juego (gravedad, rebotes y
     * limites).
     * 
     * @param dt         Delta time en segundos.
     * @param fieldWidth Ancho total de la cancha.
     * @param groundY    Nivel en Y donde esta el suelo.
     * @param crossbarY  Altura del travesano.
     * @param goalDepth  Profundidad de los arcos.
     */
    public void updatePhysics(double dt, double fieldWidth, double groundY, double crossbarY, double goalDepth) {
        // Reducimos el tiempo del efecto visual si esta activo
        if (effectTimer > 0) {
            effectTimer -= dt;
            if (effectTimer <= 0) {
                consumePowerShot();
            }
        }

        // Reducimos el tiempo de vida de los balones falsos de USA
        if (isIllusion) {
            illusionTimer -= dt;
        }

        // Comportamientos especiales de trayectoria segun el tiro de poder
        if ("AURA_AZUL".equals(activeEffect)) {
            // Corea del Sur: tiro recto y horizontal, amortiguamos la caida en Y
            velocity.setY(velocity.getY() * 0.95);
        } else if ("TORNADO".equals(activeEffect)) {
            // Nigeria: remolino a ras de suelo con rebotes rapidos hacia abajo
            velocity.add(0.0, GRAVITY * 1.3 * dt);
        } else {
            // Gravedad normal hacia abajo
            velocity.add(0.0, GRAVITY * dt);
        }

        // Movemos la posicion sumando velocidad por el tiempo transcurrido
        position.add(velocity.getX() * dt, velocity.getY() * dt);

        // Giramos el balon visualmente segun la velocidad horizontal
        rotationAngle += (velocity.getX() * dt) / radius;

        // Rebote contra el suelo
        if (position.getY() + radius >= groundY) {
            position.setY(groundY - radius);
            // El tornado de Nigeria rebota con mas energia
            double rest = "TORNADO".equals(activeEffect) ? 0.92 : RESTITUTION;
            velocity.setY(-Math.abs(velocity.getY()) * rest);
            velocity.setX(velocity.getX() * 0.97); // Friccion con el pasto
            // Si el rebote es casi imperceptible lo dejamos quieto en Y
            if (Math.abs(velocity.getY()) < 25.0) {
                velocity.setY(0.0);
            }
        }

        // Rebote contra el techo de la pantalla
        if (position.getY() - radius <= 0) {
            position.setY(radius);
            velocity.setY(Math.abs(velocity.getY()) * RESTITUTION);
        }

        // Rebote contra el poste o pared sobre el arco izquierdo
        if (position.getX() - radius < goalDepth) {
            if (position.getY() < crossbarY) {
                // Arriba del travesano rebota hacia la derecha
                position.setX(goalDepth + radius);
                velocity.setX(Math.abs(velocity.getX()) * RESTITUTION);
            } else if (Math.abs(position.getY() - crossbarY) <= radius && position.getX() >= goalDepth - 10) {
                // Golpe directo en el travesano izquierdo
                velocity.setY(-Math.abs(velocity.getY()) * RESTITUTION);
                position.setY(crossbarY - radius);
            }
        }

        // Rebote contra el poste o pared sobre el arco derecho
        if (position.getX() + radius > fieldWidth - goalDepth) {
            if (position.getY() < crossbarY) {
                // Arriba del travesano rebota hacia la izquierda
                position.setX(fieldWidth - goalDepth - radius);
                velocity.setX(-Math.abs(velocity.getX()) * RESTITUTION);
            } else if (Math.abs(position.getY() - crossbarY) <= radius
                    && position.getX() <= fieldWidth - goalDepth + 10) {
                // Golpe directo en el travesano derecho
                velocity.setY(-Math.abs(velocity.getY()) * RESTITUTION);
                position.setY(crossbarY - radius);
            }
        }

        // Evitamos que el balon escape por los extremos absolutos de la pantalla
        if (position.getX() - radius < 0) {
            position.setX(radius);
            velocity.setX(Math.abs(velocity.getX()) * RESTITUTION);
        } else if (position.getX() + radius > fieldWidth) {
            position.setX(fieldWidth - radius);
            velocity.setX(-Math.abs(velocity.getX()) * RESTITUTION);
        }
    }
}
