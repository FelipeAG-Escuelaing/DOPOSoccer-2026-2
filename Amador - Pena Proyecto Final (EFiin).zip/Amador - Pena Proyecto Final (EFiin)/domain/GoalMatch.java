package domain;

/**
 * Modalidad de partido por limite de goles predefinido (ej: primero a 3, 5 o 7 goles).
 * No hay limite de tiempo reglamentario; el juego finaliza en el momento en que
 * un jugador alcanza la cantidad de goles establecida.
 */
public class GoalMatch extends Match implements java.io.Serializable {

    private static final long serialVersionUID = 1L;

    // Meta de goles por defecto

    public static final int DEFAULT_GOAL_LIMIT = 5;

    // Cantidad de goles que se necesitan para ganar el partido

    private final int goalLimit;

    // Tiempo transcurrido acumulado de juego en segundos

    private double elapsedTime;

    /**
     * Constructor por defecto con meta de 5 goles.
     * 
     * @param field Cancha del partido.
     * @param player1 Jugador 1.
     * @param player2 Jugador 2.
     */
    public GoalMatch(Field field, Player player1, Player player2) {
        this(field, player1, player2, DEFAULT_GOAL_LIMIT);
    }

    /**
     * Constructor para configurar la cantidad de goles para ganar.
     * 
     * @param field Cancha del partido.
     * @param player1 Jugador 1.
     * @param player2 Jugador 2.
     * @param goalLimit Meta de goles (minimo 1).
     */
    public GoalMatch(Field field, Player player1, Player player2, int goalLimit) {
        super(field, player1, player2);
        this.goalLimit = Math.max(1, goalLimit);
        this.elapsedTime = 0.0;
    }

    /**
     * Retorna el limite de goles configurado para el partido.
     * 
     * @return Meta de goles.
     */
    public int getGoalLimit() {
        return goalLimit;
    }

    /**
     * Retorna los segundos transcurridos desde que inicio el partido.
     * 
     * @return Tiempo en segundos.
     */
    public double getElapsedTime() {
        return elapsedTime;
    }

    /**
     * Acumula el tiempo transcurrido en el cronometro.
     * 
     * @param dt Delta time en segundos.
     */
    @Override
    protected void updateMatchSpecificLogic(double dt) {
        elapsedTime += dt;
    }

    /**
     * Comprueba si alguno de los dos jugadores ya alcanzo la meta de goles
     * para declarar al ganador de forma inmediata.
     */
    @Override
    protected void checkGameOverConditions() {
        // Si Jugador 1 llego al limite de goles, gana el partido
        if (score1 >= goalLimit) {
            finishMatch(player1, player2);
        }
        // Si Jugador 2 llego al limite de goles, gana el partido
        else if (score2 >= goalLimit) {
            finishMatch(player2, player1);
        }
    }

    /**
     * Retorna el nombre de la modalidad para el marcador.
     * 
     * @return Texto con la cantidad de goles.
     */
    @Override
    public String getMatchTypeName() {
        return "Por Goles (" + goalLimit + " goles)";
    }
}
