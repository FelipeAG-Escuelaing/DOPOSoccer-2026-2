package domain;

/**
 * Estado electrocutado infligido por el tiro de poder de Camerun.
 * El rival no puede saltar y su velocidad se reduce al 50% por 3 segundos.
 */
public class ElectrocutedState extends TimedState {

    /**
     * Constructor por defecto con la duracion oficial de 3.0 segundos.
     */
    public ElectrocutedState() {
        this(3.0);
    }

    /**
     * Constructor con duracion configurable para pruebas unitarias.
     * 
     * @param duration Segundos de duracion.
     */
    public ElectrocutedState(double duration) {
        super(duration);
    }

    @Override
    public boolean canJump() {
        return false;
    }

    @Override
    public double getSpeedMultiplier() {
        return 0.50;
    }

    @Override
    public String getStateName() {
        return "ELECTROCUTADO";
    }
}
