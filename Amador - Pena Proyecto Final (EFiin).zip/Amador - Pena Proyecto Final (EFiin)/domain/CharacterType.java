package domain;

import domain.power.CameroonPowerShot;
import domain.power.NigeriaPowerShot;
import domain.power.PowerShot;
import domain.power.SouthKoreaPowerShot;
import domain.power.USAPowerShot;

/**
 * Enumeracion con los cuatro personajes oficiales:
 * Corea del Sur, Camerun, Nigeria y Estados Unidos.
 * Cada uno define sus estadisticas por defecto y fabrica su tiro de poder.
 */
public enum CharacterType {

    /**
     * Corea del Sur: Aura Azul, Tiro recto, Empuje por 1.5s, Danio base 40
     */
    SOUTH_KOREA("Corea del Sur", "Aura Azul (Empuje 1.5s, Danio 40)", 3, 3, 4, 3) {
        @Override
        public PowerShot createPowerShot() {
            return new SouthKoreaPowerShot();
        }
    },

    /**
     * Camerun: Rayo electrico, Electrocutado por 3s, Danio base 60
     */
    CAMEROON("Camerun", "Rayo Electrico (Electrocutado 3s, Danio 60)", 3, 3, 3, 4) {
        @Override
        public PowerShot createPowerShot() {
            return new CameroonPowerShot();
        }
    },

    /**
     * Nigeria: Tornado rebotador, Inconsciente en aire por 3s, Danio base 40
     */
    NIGERIA("Nigeria", "Tornado Rebotador (Inconsciente 3s, Danio 40)", 4, 4, 3, 2) {
        @Override
        public PowerShot createPowerShot() {
            return new NigeriaPowerShot();
        }
    },

    /**
     * Estados Unidos: Ilusion de 8 balones, Confusion por 2.5s, Danio base 30
     */
    USA("Estados Unidos", "Ilusion (8 balones, Confusion 2.5s, Danio 30)", 3, 4, 3, 3) {
        @Override
        public PowerShot createPowerShot() {
            return new USAPowerShot();
        }
    };

    // Nombre para mostrar en los menus y marcadores

    private final String displayName;

    // Resumen de que hace el tiro de poder del personaje

    private final String powerDescription;

    // Nivel por defecto de velocidad

    private final int defaultSpeed;

    // Nivel por defecto de salto

    private final int defaultJump;

    // Nivel por defecto de patada

    private final int defaultKick;

    // Nivel por defecto de supervivencia

    private final int defaultSurvival;

    /**
     * Constructor del enum con la informacion de cada seleccion nacional.
     * 
     * @param displayName Nombre legible del pais.
     * @param powerDescription Descripcion corta del poder.
     * @param speed Nivel inicial de velocidad.
     * @param jump Nivel inicial de salto.
     * @param kick Nivel inicial de patada.
     * @param survival Nivel inicial de supervivencia.
     */
    CharacterType(String displayName, String powerDescription, int speed, int jump, int kick, int survival) {
        this.displayName = displayName;
        this.powerDescription = powerDescription;
        this.defaultSpeed = speed;
        this.defaultJump = jump;
        this.defaultKick = kick;
        this.defaultSurvival = survival;
    }

    /**
     * Retorna el nombre visible del pais.
     * 
     * @return Texto con el nombre.
     */
    public String getDisplayName() {
        return displayName;
    }

    @Override
    public String toString() {
        return displayName;
    }

    /**
     * Retorna la descripcion de la habilidad especial.
     * 
     * @return Texto con el resumen del poder.
     */
    public String getPowerDescription() {
        return powerDescription;
    }

    /**
     * Crea un objeto con los niveles base de atributos del personaje.
     * 
     * @return Instancia nueva de CharacterStats con valores por defecto.
     */
    public CharacterStats createDefaultStats() {
        return new CharacterStats(defaultSpeed, defaultJump, defaultKick, defaultSurvival);
    }

    /**
     * Metodo fabrica para instanciar la estrategia del tiro de poder del pais.
     * 
     * @return Nueva instancia del PowerShot correspondiente.
     */
    public abstract PowerShot createPowerShot();
}
