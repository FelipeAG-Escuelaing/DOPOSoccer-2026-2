package domain;

/**
 * Estado empujado infligido por el tiro de poder de Corea del Sur.
 * El rival es empujado hacia su propio arco durante 1.5 segundos.
 */
public class PushedState extends TimedState {

    // Direccion del empuje: 1.0 hacia la derecha, -1.0 hacia la izquierda

    private final double pushDirection;

    /**
     * Constructor por defecto de 1.5 segundos en la direccion indicada.
     * 
     * @param pushDirection Hacia donde empuja (1.0 derecha, -1.0 izquierda).
     */
    public PushedState(double pushDirection) {
        this(1.5, pushDirection);
    }

    /**
     * Constructor con duracion configurable para pruebas unitarias.
     * 
     * @param duration Segundos que dura el empuje.
     * @param pushDirection Direccion horizontal del empuje.
     */
    public PushedState(double duration, double pushDirection) {
        super(duration);
        this.pushDirection = pushDirection;
    }

    /**
     * Retorna la direccion horizontal del empuje.
     * 
     * @return 1.0 derecha, -1.0 izquierda.
     */
    public double getPushDirection() {
        return pushDirection;
    }

    @Override
    public void update(double dt, Player player) {
        // Le forzamos una velocidad horizontal constante hacia su porteria
        player.getVelocity().setX(pushDirection * 350.0);
        super.update(dt, player);
    }

    @Override
    public boolean canMove() {
        return false;
    }

    @Override
    public boolean canJump() {
        return false;
    }

    @Override
    public boolean canKick() {
        return false;
    }

    @Override
    public boolean canUsePower() {
        return false;
    }

    @Override
    public double getSpeedMultiplier() {
        return 0.0;
    }

    @Override
    public String getStateName() {
        return "EMPUJADO";
    }
}
