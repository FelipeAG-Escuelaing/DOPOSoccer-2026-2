package domain;

import java.util.Random;

/**
 * Perfil Torpe de la maquina.
 * Escoge sus movimientos de manera erratica y al azar.
 */
public class ClumsyProfile implements MachineProfile {

    private static final long serialVersionUID = 1L;

    // Generador de numeros aleatorios para las decisiones
    private final Random random;

    // Temporizador para cambiar de accion
    private double decisionTimer;

    // Accion horizontal elegida actualmente (-1 izq, 0 quieto, 1 der)
    private int currentDirection;

    /**
     * Constructor por defecto del perfil torpe.
     */
    public ClumsyProfile() {
        this.random = new Random();
        this.decisionTimer = 0.0;
        this.currentDirection = 0;
    }

    @Override
    public String getProfileName() {
        return "Torpe";
    }

    @Override
    public void decideAction(MachinePlayer machine, Match match, double dt) {
        if (machine == null || match == null) {
            return;
        }

        decisionTimer -= dt;
        if (decisionTimer <= 0.0) {
            // Cambiamos de decision cada 0.25 a 0.55 segundos
            decisionTimer = 0.25 + random.nextDouble() * 0.30;

            int roll = random.nextInt(10);
            if (roll < 4) {
                currentDirection = -1; // Mover a la izquierda
            } else if (roll < 8) {
                currentDirection = 1; // Mover a la derecha
            } else {
                currentDirection = 0; // Quedarse quieto
            }

            // Probabilidad del 35% de saltar
            if (random.nextDouble() < 0.35 && machine.isGrounded()) {
                machine.jump();
            }

            // Probabilidad del 40% de patear
            if (random.nextDouble() < 0.40) {
                machine.kick();
            }

            // Probabilidad del 25% de activar poder si esta al 100%
            if (random.nextDouble() < 0.25 && machine.isPowerReady()) {
                try {
                    machine.activatePowerAura();
                } catch (DOPOSoccerException e) {
                    // Si no se puede activar, se ignora
                }
            }
        }

        // Aplicamos el movimiento continuo decidido
        if (currentDirection < 0) {
            machine.moveLeft();
        } else if (currentDirection > 0) {
            machine.moveRight();
        } else {
            machine.stopHorizontal();
        }
    }
}
