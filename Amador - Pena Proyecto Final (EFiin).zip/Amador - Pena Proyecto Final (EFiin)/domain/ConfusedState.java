package domain;

/**
 * Estado confundido infligido por el tiro de poder de Estados Unidos.
 * Invierte los controles de movimiento del rival por 2.5 segundos.
 */
public class ConfusedState extends TimedState {

    /**
     * Constructor por defecto con la duracion oficial de 2.5 segundos.
     */
    public ConfusedState() {
        this(2.5);
    }

    /**
     * Constructor con duracion configurable para pruebas unitarias.
     * 
     * @param duration Segundos que durara confundido el jugador.
     */
    public ConfusedState(double duration) {
        super(duration);
    }

    @Override
    public boolean canUsePower() {
        return true;
    }

    @Override
    public boolean isInvertedControls() {
        return true;
    }

    @Override
    public String getStateName() {
        return "CONFUNDIDO";
    }
}
