package domain;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;

/**
 * Clase abstracta que define la estructura del partido con el patron Template Method.
 * Maneja las colecciones de jugadores y balones, las colisiones y las reglas de goles y puntos.
 */
public abstract class Match implements java.io.Serializable {

    private static final long serialVersionUID = 1L;

    // Puntos que recibe el jugador ganador del partido segun la regla oficial

    public static final int POINTS_WINNER = 100;

    // Puntos que recibe el jugador perdedor del partido segun la regla oficial

    public static final int POINTS_LOSER = 25;

    // Referencia a la cancha con sus dimensiones y arcos

    protected final Field field;

    // Jugador 1 (lado izquierdo)

    protected final Player player1;

    // Jugador 2 (lado derecho)

    protected final Player player2;

    // Coleccion con los dos jugadores del partido

    protected final List<Player> players;

    // Coleccion con los balones en juego (el oficial mas las ilusiones de USA)

    protected final List<Ball> balls;

    // Marcador de goles del Jugador 1

    protected int score1;

    // Marcador de goles del Jugador 2

    protected int score2;

    // Bandera que indica si el partido ya termino

    protected boolean isGameOver;

    // Bandera que indica si el partido esta en pausa

    protected boolean isPaused;

    // Bandera que indica si estamos en muerte subita por empate al final del tiempo

    protected boolean isSuddenDeath;

    // Referencia al jugador que gano el partido

    protected Player winner;

    // Referencia al jugador que perdio el partido

    protected Player loser;

    // Puntos ganados por el vencedor

    protected int winnerPoints;

    // Puntos ganados por el perdedor

    protected int loserPoints;

    // Temporizador para la celebracion animada tras anotar un gol

    protected double goalCelebrationTimer;

    // Id del jugador que anoto el ultimo gol (1 o 2)

    protected int lastScoringPlayerId;

    /**
     * Constructor base que recibe la cancha y los dos jugadores ya configurados.
     * 
     * @param field Objeto con las medidas y arcos de la cancha.
     * @param player1 Jugador 1.
     * @param player2 Jugador 2.
     */
    public Match(Field field, Player player1, Player player2) {
        this.field = field != null ? field : new Field();
        this.player1 = player1;
        this.player2 = player2;

        // Guardamos los jugadores en la lista
        this.players = new ArrayList<>(2);
        this.players.add(player1);
        this.players.add(player2);

        // El primer balon de la lista (indice 0) siempre es el balon reglamentario
        this.balls = new ArrayList<>();
        this.balls.add(new Ball(this.field.getWidth() / 2.0, this.field.getGroundY() - 180.0));

        this.score1 = 0;
        this.score2 = 0;
        this.isGameOver = false;
        this.isPaused = false;
        this.isSuddenDeath = false;
        this.goalCelebrationTimer = 0.0;
        this.lastScoringPlayerId = 0;
    }

    /**
     * Retorna la cancha del partido.
     * 
     * @return Objeto Field.
     */
    public Field getField() {
        return field;
    }

    /**
     * Retorna el Jugador 1.
     * 
     * @return Instancia de Player 1.
     */
    public Player getPlayer1() {
        return player1;
    }

    /**
     * Retorna el Jugador 2.
     * 
     * @return Instancia de Player 2.
     */
    public Player getPlayer2() {
        return player2;
    }

    /**
     * Retorna la lista inmutable con los dos jugadores.
     * 
     * @return Lista de jugadores de solo lectura.
     */
    public List<Player> getPlayers() {
        return Collections.unmodifiableList(players);
    }

    /**
     * Retorna la lista inmutable con todos los balones activos.
     * 
     * @return Lista de balones de solo lectura.
     */
    public List<Ball> getBalls() {
        return Collections.unmodifiableList(balls);
    }

    /**
     * Retorna el balon oficial reglamentario.
     * 
     * @return Objeto Ball principal.
     */
    public Ball getMainBall() {
        return balls.isEmpty() ? null : balls.get(0);
    }

    /**
     * Agrega un nuevo balon a la lista (como las ilusiones de USA).
     * 
     * @param ball Balon a agregar.
     */
    public void addBall(Ball ball) {
        if (ball != null) {
            this.balls.add(ball);
        }
    }

    /**
     * Elimina todos los balones falsos de ilusion dejando unicamente el balon real.
     */
    public void clearIllusionBalls() {
        if (balls.size() > 1) {
            Ball main = balls.get(0);
            balls.clear();
            balls.add(main);
        }
    }

    /**
     * Retorna los goles anotados por el Jugador 1.
     * 
     * @return Goles de P1.
     */
    public int getScore1() {
        return score1;
    }

    /**
     * Retorna los goles anotados por el Jugador 2.
     * 
     * @return Goles de P2.
     */
    public int getScore2() {
        return score2;
    }

    /**
     * Indica si el partido ya finalizo.
     * 
     * @return true si el juego termino.
     */
    public boolean isGameOver() {
        return isGameOver;
    }

    /**
     * Indica si el partido esta pausado.
     * 
     * @return true si esta en pausa.
     */
    public boolean isPaused() {
        return isPaused;
    }

    /**
     * Permite pausar o reanudar el partido.
     * 
     * @param paused true para pausar, false para continuar.
     */
    public void setPaused(boolean paused) {
        this.isPaused = paused;
    }

    /**
     * Indica si el partido entro a muerte subita por empate al final del tiempo.
     * 
     * @return true si estamos en muerte subita.
     */
    public boolean isSuddenDeath() {
        return isSuddenDeath;
    }

    /**
     * Retorna el jugador que gano el partido.
     * 
     * @return Objeto Player ganador o null si sigue en juego.
     */
    public Player getWinner() {
        return winner;
    }

    /**
     * Retorna el jugador que perdio el partido.
     * 
     * @return Objeto Player perdedor o null.
     */
    public Player getLoser() {
        return loser;
    }

    /**
     * Retorna los puntos ganados por el vencedor (+100).
     * 
     * @return Puntos del ganador.
     */
    public int getWinnerPoints() {
        return winnerPoints;
    }

    /**
     * Retorna los puntos ganados por el perdedor (+25).
     * 
     * @return Puntos del perdedor.
     */
    public int getLoserPoints() {
        return loserPoints;
    }

    /**
     * Retorna el temporizador de la celebracion de gol.
     * 
     * @return Segundos restantes de celebracion.
     */
    public double getGoalCelebrationTimer() {
        return goalCelebrationTimer;
    }

    /**
     * Retorna el numero del jugador que anoto el ultimo gol (1 o 2).
     * 
     * @return Id del anotador.
     */
    public int getLastScoringPlayerId() {
        return lastScoringPlayerId;
    }

    /**
     * Metodo Plantilla que define la secuencia en cada tick del juego:
     * 1. Pausa o celebracion de gol.
     * 2. Logica especifica del tipo de partido (tiempo o goles).
     * 3. Fisicas, colisiones y tiros de poder.
     * 4. Revision de goles en ambos arcos.
     * 5. Comprobacion de si el partido termino.
     * 
     * @param dt Tiempo delta en segundos.
     */
    public final void update(double dt) {
        if (isGameOver || isPaused) {
            return;
        }

        // Si hay celebracion de gol congelamos el juego 2 segundos y luego reiniciamos posiciones
        if (goalCelebrationTimer > 0.0) {
            goalCelebrationTimer -= dt;
            if (goalCelebrationTimer <= 0.0) {
                goalCelebrationTimer = 0.0;
                resetAfterGoal();
            }
            return;
        }

        // Paso variable: descuenta tiempo o cuenta goles
        updateMatchSpecificLogic(dt);

        // Paso comun: actualiza posiciones y choques de jugadores y balones
        updateEntitiesPhysics(dt);

        // Paso comun: verifica si el balon cruzo alguna linea de gol
        checkGoalConditions();

        // Paso variable: comprueba si alguien ya gano el partido
        checkGameOverConditions();
    }

    /**
     * Paso variable del Template Method implementado por TimeMatch y GoalMatch.
     * 
     * @param dt Delta time en segundos.
     */
    protected abstract void updateMatchSpecificLogic(double dt);

    /**
     * Paso variable para comprobar si se cumplio la condicion de fin de juego.
     */
    protected abstract void checkGameOverConditions();

    /**
     * Nombre para mostrar del tipo de partido.
     * 
     * @return Texto con el nombre de la modalidad.
     */
    public abstract String getMatchTypeName();

    /**
     * Actualiza la fisica de jugadores, balones y resuelve choques y patadas.
     * 
     * @param dt Delta time en segundos.
     */
    protected void updateEntitiesPhysics(double dt) {
        double fWidth = field.getWidth();
        double groundY = field.getGroundY();
        double crossbarY = field.getLeftGoal().getCrossbarY();
        double goalDepth = field.getLeftGoal().getWidth();

        // Si algun jugador es controlado por la maquina, actualiza su inteligencia artificial
        if (player1 instanceof MachinePlayer) {
            ((MachinePlayer) player1).updateAI(this, dt);
        }
        if (player2 instanceof MachinePlayer) {
            ((MachinePlayer) player2).updateAI(this, dt);
        }

        // Actualizamos las fisicas de ambos jugadores
        player1.update(dt, fWidth, groundY);
        player2.update(dt, fWidth, groundY);

        // Actualizamos los balones y borramos las ilusiones cuyo tiempo expiro
        Iterator<Ball> it = balls.iterator();
        while (it.hasNext()) {
            Ball b = it.next();
            b.updatePhysics(dt, fWidth, groundY, crossbarY, goalDepth);
            if (b.isIllusion() && b.getIllusionTimer() <= 0.0) {
                it.remove();
            }
        }

        // Hacemos una copia de la lista para evitar errores de concurrencia al crear ilusiones
        List<Ball> currentBalls = new ArrayList<>(balls);
        for (Ball b : currentBalls) {
            checkPlayerBallCollision(player1, player2, b);
            checkPlayerBallCollision(player2, player1, b);
        }

        // Verificamos si alguna patada alcanzo al balon o al rival
        checkKickInteractions(player1, player2);
        checkKickInteractions(player2, player1);
    }

    /**
     * Evalua si un jugador cabecea o choca el cuerpo con el balon,
     * aplicando las Reglas de Tiro de Poder.
     * 
     * @param player Jugador que colisiona.
     * @param opponent Jugador rival.
     * @param ball Balon con el que choca.
     */
    protected void checkPlayerBallCollision(Player player, Player opponent, Ball ball) {
        if (player == null || ball == null) {
            return;
        }

        CircleHitbox head = player.getHeadHitbox();
        CircleHitbox body = player.getBodyHitbox();
        CircleHitbox bHit = ball.getHitbox();

        boolean hitHead = head.intersects(bHit);
        boolean hitBody = body.intersects(bHit);

        if (hitHead || hitBody) {
            // Si el balon venia con tiro de poder y golpea al rival, aplica danio y efecto
            if (ball.isPowerShot() && ball.getPowerShooter() != null && ball.getPowerShooter() != player) {
                ball.getPowerStrategy().applyEffectToRival(ball.getPowerShooter(), player, ball);
                ball.consumePowerShot(); // El poder se gasta en el impacto
            }

            // Cuando el jugador con aura toca el balon, dispara el poder y apaga el aura
            if (player.hasActivePower()) {
                player.triggerPowerShotOnBall(this, opponent, ball);
            } else {
                // calculamos el vector normal para el rebote
                Vector2D center = hitHead ? head.getCenter() : body.getCenter();
                double dx = ball.getPosition().getX() - center.getX();
                double dy = ball.getPosition().getY() - center.getY();
                double dist = Math.sqrt(dx * dx + dy * dy);

                // Evitamos division por cero si coinciden exactamente los centros
                if (dist < 1e-4) {
                    dx = player.getFacingDirection();
                    dy = -1.0;
                    dist = 1.0;
                }

                double nx = dx / dist;
                double ny = dy / dist;

                // Separamos el balon para que no se quede pegado dentro de la cabeza
                double targetDist = ball.getRadius() + (hitHead ? head.getRadius() : body.getRadius());
                ball.getPosition().set(center.getX() + nx * targetDist, center.getY() + ny * targetDist);

                // Le damos impulso al balon segun el vector normal del golpe
                double bounceSpeed = 480.0;
                ball.getVelocity().set(nx * bounceSpeed + player.getVelocity().getX() * 0.4,
                                       ny * bounceSpeed - 100.0);
                ball.setLastKicker(player);
            }
        }
    }

    /**
     * Evalua si una patada golpeo el balon o al jugador rival,
     * Si la patada toca el balon lo impulsa, si alcanza al rival le hace danio cuerpo a cuerpo.
     * 
     * @param attacker Jugador que esta pateando.
     * @param defender Jugador rival defensor.
     */
    protected void checkKickInteractions(Player attacker, Player defender) {
        if (!attacker.isKicking()) {
            return;
        }

        double dir = attacker.getFacingDirection();
        double kickReach = 56.0;
        double kickX = attacker.getPosition().getX() + dir * kickReach;
        double kickY = attacker.getPosition().getY() - 15.0;

        // 1. Verificamos si la patada alcanza el balon
        Ball mainBall = getMainBall();
        if (mainBall != null) {
            double distSq = Math.pow(mainBall.getPosition().getX() - kickX, 2)
                          + Math.pow(mainBall.getPosition().getY() - kickY, 2);

            // Si la punta del pie toca el balon
            if (distSq <= Math.pow(mainBall.getRadius() + 35.0, 2)) {
                // Si tenia el aura encendida, la patada dispara el tiro de poder (Regla 4)
                if (attacker.hasActivePower()) {
                    attacker.triggerPowerShotOnBall(this, defender, mainBall);
                } else {
                    // Impulso fuerte con el multiplicador de patada
                    double mult = attacker.getStats().getMultiplicadorKick();
                    mainBall.applyImpulse(dir * 580.0 * mult, -320.0 * mult);
                    mainBall.setLastKicker(attacker);
                }
            }
        }

        // 2. Verificamos si la patada alcanza al rival cuerpo a cuerpo
        double distDefSq = Math.pow(defender.getPosition().getX() - kickX, 2)
                         + Math.pow(defender.getPosition().getY() - kickY, 2);

        if (distDefSq <= Math.pow(Player.BODY_RADIUS + 30.0, 2)) {
            // Danio oficial de patada normal: 10 * multiplicadorKick
            double damage = attacker.getStats().getDanioPatada();
            defender.takeDamage(damage);
            // Empujamos un poco al rival hacia atras por el impacto
            defender.getVelocity().setX(dir * 140.0);
        }
    }

    /**
     * Revisa si el balon oficial entro en el arco izquierdo o derecho.
     */
    protected void checkGoalConditions() {
        Ball mainBall = getMainBall();
        if (mainBall == null || mainBall.isIllusion()) {
            return;
        }

        // Gol en arco izquierdo: anoto el Jugador 2
        if (field.getLeftGoal().isGoal(mainBall)) {
            handleGoal(2);
        }
        // Gol en arco derecho: anoto el Jugador 1
        else if (field.getRightGoal().isGoal(mainBall)) {
            handleGoal(1);
        }
    }

    /**
     * Procesa la anotacion de un gol, sube el marcador e inicia la celebracion.
     * Al recibir un gol, la barra del jugador que recibio el gol aumenta un cuarto (+25%).
     * Si el tiro entro sin tocar al rival, cuenta el gol y se apaga el poder sin danio.
     * 
     * @param scorerId Id del jugador que marco el gol (1 o 2).
     */
    public void handleGoal(int scorerId) {
        if (goalCelebrationTimer > 0.0) {
            return;
        }

        // Si el balon llevaba poder y entro directo, se consume el poder
        Ball main = getMainBall();
        if (main != null && main.isPowerShot()) {
            main.consumePowerShot();
        }

        this.lastScoringPlayerId = scorerId;
        this.goalCelebrationTimer = 2.0; // 2 segundos de pausa de celebracion

        if (scorerId == 1) {
            score1++;
            // Jugador 2 recibio gol: su barra aumenta +25%
            player2.onConcedeGoal();
        } else {
            score2++;
            // Jugador 1 recibio gol: su barra aumenta +25%
            player1.onConcedeGoal();
        }

        // Si estabamos en muerte subita este gol de oro termina el partido de una vez
        if (isSuddenDeath) {
            finishMatch(scorerId == 1 ? player1 : player2, scorerId == 1 ? player2 : player1);
        } else {
            checkGameOverConditions();
        }
    }

    /**
     * Requisito: Despues de cada gol, los personajes y el balon
     * caen desde el centro de la cancha por gravedad.
     */
    public void resetAfterGoal() {
        clearIllusionBalls();
        Ball mainBall = getMainBall();
        if (mainBall != null) {
            // El balon se ubica arriba en el centro para que caiga
            mainBall.reset(field.getWidth() / 2.0, field.getGroundY() - 200.0);
        }

        // Los jugadores se ubican en el aire en sus mitades de cancha y caen por gravedad
        player1.getPosition().set(field.getWidth() * 0.25, field.getGroundY() - 140.0);
        player1.getVelocity().set(0.0, 0.0);
        player1.setGrounded(false);
        player1.setFacingDirection(1.0);

        player2.getPosition().set(field.getWidth() * 0.75, field.getGroundY() - 140.0);
        player2.getVelocity().set(0.0, 0.0);
        player2.setGrounded(false);
        player2.setFacingDirection(-1.0);
    }

    /**
     * Finaliza el juego y reparte los puntos: +100 puntos al ganador y +25 al perdedor.
     * 
     * @param winPlayer Jugador vencedor.
     * @param losePlayer Jugador derrotado.
     */
    protected void finishMatch(Player winPlayer, Player losePlayer) {
        this.isGameOver = true;
        this.winner = winPlayer;
        this.loser = losePlayer;
        this.winnerPoints = POINTS_WINNER;
        this.loserPoints = POINTS_LOSER;

        // Entregamos los puntos acumulables a cada jugador
        if (winPlayer != null) {
            winPlayer.addPoints(POINTS_WINNER);
        }
        if (losePlayer != null) {
            losePlayer.addPoints(POINTS_LOSER);
        }
    }

    /**
     * Permite forzar la finalizacion del partido en cualquier momento desde la interfaz.
     */
    public void finishMatchManually() {
        if (!isGameOver) {
            if (score1 > score2) {
                finishMatch(player1, player2);
            } else if (score2 > score1) {
                finishMatch(player2, player1);
            } else {
                // En caso de empate al terminar manualmente, se define por salud restante
                double hp1 = player1.getCurrentHealth();
                double hp2 = player2.getCurrentHealth();
                if (hp1 >= hp2) {
                    finishMatch(player1, player2);
                } else {
                    finishMatch(player2, player1);
                }
            }
        }
    }
}
