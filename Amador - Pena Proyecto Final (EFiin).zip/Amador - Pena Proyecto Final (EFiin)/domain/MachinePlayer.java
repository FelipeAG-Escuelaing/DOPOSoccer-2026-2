package domain;

/**
 * Subclase de Player que representa a un jugador controlado por la inteligencia artificial.
 * Aplica el patron Strategy delegando sus decisiones al MachineProfile asignado.
 */
public class MachinePlayer extends Player {

    private static final long serialVersionUID = 1L;

    // Estrategia de comportamiento de la maquina (Torpe, Ofensiva, Defensiva, Experta)
    private MachineProfile profile;

    /**
     * Constructor principal para inicializar un jugador de la maquina.
     * 
     * @param id Identificador numerico del jugador (normalmente 2).
     * @param name Nombre o etiqueta a mostrar en pantalla.
     * @param characterType Pais del personaje.
     * @param startX Posicion inicial en X.
     * @param startY Posicion inicial en Y.
     * @param facingDirection Orientacion inicial (1.0 derecha, -1.0 izquierda).
     * @param profile Perfil de comportamiento con la estrategia de IA.
     */
    public MachinePlayer(int id, String name, CharacterType characterType, double startX, double startY,
            double facingDirection, MachineProfile profile) {
        super(id, name, characterType, startX, startY, facingDirection);
        this.profile = profile != null ? profile : new OffensiveProfile();
    }

    /**
     * Retorna el perfil actual de la maquina.
     * 
     * @return Objeto MachineProfile.
     */
    public MachineProfile getProfile() {
        return profile;
    }

    /**
     * Permite cambiar la estrategia de la maquina en cualquier momento.
     * 
     * @param profile Nuevo perfil de comportamiento.
     */
    public void setProfile(MachineProfile profile) {
        if (profile != null) {
            this.profile = profile;
        }
    }

    /**
     * Se llama en cada paso del ciclo del juego para que la IA tome decisiones.
     * 
     * @param match Partido en curso.
     * @param dt Tiempo transcurrido en segundos.
     */
    public void updateAI(Match match, double dt) {
        if (match == null || match.isGameOver() || match.isPaused()) {
            return;
        }
        if (profile != null) {
            profile.decideAction(this, match, dt);
        }
    }
}
