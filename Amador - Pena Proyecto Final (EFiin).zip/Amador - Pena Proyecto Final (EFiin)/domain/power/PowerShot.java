package domain.power;

import domain.Ball;
import domain.Match;
import domain.Player;

/**
 * Clase abstracta base que representa la estrategia de un tiro de poder.
 * Define como reacciona el balon al dispararse y que efecto o danio le causa al rival.
 * 
 * Cumple con las reglas oficiales del documento:
 * - Al tocar el balon, se dispara el tiro de poder y el aura desaparece.
 * - Si impacta al rival fisicamente, le aplica danio y estado negativo.
 * - Si entra al arco rival sin tocar al jugador, cuenta el gol sin danio ni efecto.
 * - Los efectos no se acumulan, el nuevo reemplaza al anterior.
 */
public abstract class PowerShot implements java.io.Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * Constructor por defecto de la clase base PowerShot.
     */
    public PowerShot() {
        // Inicializa la estrategia del tiro de poder
    }

    /**
     * Aplica la cinematica, velocidad y trayectoria particular de cada pais al balon.
     * 
     * @param match Partido en curso donde se ejecuta la jugada.
     * @param caster Jugador que lanza el tiro de poder.
     * @param opponent Jugador rival.
     * @param ball Balon principal sobre el cual se aplica el tiro.
     */
    public abstract void applyPowerShotToBall(Match match, Player caster, Player opponent, Ball ball);

    /**
     * Metodo plantilla que calcula el danio, descuenta la salud y delega el efecto negativo al rival.
     * 
     * @param caster Jugador atacante que origino el disparo.
     * @param opponent Jugador rival que recibe el impacto.
     * @param ball Balon cargado con el poder que impacto al rival.
     */
    public void applyEffectToRival(Player caster, Player opponent, Ball ball) {
        if (opponent == null || caster == null) {
            return;
        }
        double damage = calculateDamage(caster);
        opponent.takeDamage(damage);
        applyNegativeState(caster, opponent, ball);
    }

    /**
     * Paso variable del metodo plantilla: aplica el estado alterado o fuerza particular al rival.
     * 
     * @param caster Jugador atacante.
     * @param opponent Jugador rival que recibe el impacto.
     * @param ball Balon que causo el impacto.
     */
    protected abstract void applyNegativeState(Player caster, Player opponent, Ball ball);

    /**
     * Retorna el nombre descriptivo del tiro de poder y su pais.
     * 
     * @return Cadena con el nombre del tiro de poder.
     */
    public abstract String getPowerName();

    /**
     * Retorna el identificador unico del efecto visual y de estado.
     * 
     * @return Clave en mayusculas del efecto.
     */
    public abstract String getEffectName();

    /**
     * Retorna el danio base del tiro de poder.
     * 
     * @return Valor numerico del danio base.
     */
    public abstract double getBaseDamage();

    /**
     * Retorna la duracion en segundos del efecto negativo sobre el rival.
     * 
     * @return Tiempo en segundos que dura la alteracion de estado.
     */
    public abstract double getDuration();

    /**
     * Calcula el danio final aplicando la formula oficial de la tabla del documento:
     * DanioPoder = DanioTiro * multiplicadorKick.
     * 
     * @param caster Jugador que dispara el tiro con sus respectivas estadisticas.
     * @return Danio final calculado listo para descontar de la vida del rival.
     */
    public double calculateDamage(Player caster) {
        if (caster == null || caster.getStats() == null) {
            return getBaseDamage();
        }
        return getBaseDamage() * caster.getStats().getMultiplicadorKick();
    }
}
