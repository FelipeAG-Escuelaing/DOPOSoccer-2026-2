package domain.power;

import domain.Ball;
import domain.Match;
import domain.Player;
import domain.PushedState;

/**
 * Tiro de poder de Corea del Sur.
 * - Nombre: Aura Azul.
 * - Trayectoria: Recto y horizontal a alta velocidad.
 * - Efecto en el rival: Empuje hacia su propio arco por 1.5 segundos.
 * - Danio base: 40 puntos.
 */
public class SouthKoreaPowerShot extends PowerShot {

    public static final double BASE_DAMAGE = 40.0;
    public static final double DURATION = 1.5;

    public SouthKoreaPowerShot() {
        super();
    }

    @Override
    public void applyPowerShotToBall(Match match, Player caster, Player opponent, Ball ball) {
        double dir = caster.getFacingDirection();
        ball.applyImpulse(dir * 880.0, -10.0);
        ball.setPowerShot(this, caster, getEffectName(), DURATION);
        ball.setLastKicker(caster);
    }

    @Override
    protected void applyNegativeState(Player caster, Player opponent, Ball ball) {
        double pushDir = caster.getFacingDirection();
        opponent.setState(new PushedState(DURATION, pushDir));
    }

    @Override
    public String getPowerName() {
        return "Aura Azul (Corea del Sur)";
    }

    @Override
    public String getEffectName() {
        return "AURA_AZUL";
    }

    @Override
    public double getBaseDamage() {
        return BASE_DAMAGE;
    }

    @Override
    public double getDuration() {
        return DURATION;
    }
}
