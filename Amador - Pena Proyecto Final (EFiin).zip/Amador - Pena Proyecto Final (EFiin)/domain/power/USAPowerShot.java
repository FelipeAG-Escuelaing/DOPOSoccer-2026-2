package domain.power;

import domain.Ball;
import domain.ConfusedState;
import domain.Match;
import domain.Player;

/**
 * Tiro de poder de Estados Unidos.
 * - Nombre: Ilusion.
 * - Trayectoria: El balon se divide en 8 balones identicos (1 real y 7 copias que desaparecen).
 * - Efecto en el rival: Confusion (controles de movimiento invertidos por 2.5 segundos).
 * - Danio base: 30 puntos.
 */
public class USAPowerShot extends PowerShot {

    public static final double BASE_DAMAGE = 30.0;
    public static final double DURATION = 2.5;

    public USAPowerShot() {
        super();
    }

    @Override
    public void applyPowerShotToBall(Match match, Player caster, Player opponent, Ball ball) {
        double dir = caster.getFacingDirection();
        ball.applyImpulse(dir * 720.0, -180.0);
        ball.setPowerShot(this, caster, getEffectName(), DURATION);
        ball.setLastKicker(caster);

        if (match != null) {
            match.clearIllusionBalls();
            double startX = ball.getPosition().getX();
            double startY = ball.getPosition().getY();
            double[] angles = { -0.45, -0.30, -0.15, 0.15, 0.30, 0.45, 0.60 };
            for (double angle : angles) {
                Ball fake = new Ball(startX, startY, true);
                double speed = 700.0;
                double vx = dir * Math.cos(angle) * speed;
                double vy = Math.sin(angle) * speed - 120.0;
                fake.applyImpulse(vx, vy);
                fake.setActiveEffect("ILUSION", DURATION);
                match.addBall(fake);
            }
        }
    }

    @Override
    protected void applyNegativeState(Player caster, Player opponent, Ball ball) {
        opponent.setState(new ConfusedState(DURATION));
    }

    @Override
    public String getPowerName() {
        return "Ilusion (Estados Unidos)";
    }

    @Override
    public String getEffectName() {
        return "ILUSION";
    }

    @Override
    public double getBaseDamage() {
        return BASE_DAMAGE;
    }

    @Override
    public double getDuration() {
        return DURATION;
    }
}
