package domain.power;

import domain.Ball;
import domain.ElectrocutedState;
import domain.Match;
import domain.Player;

/**
 * Tiro de poder de Camerun.
 * - Nombre: Rayo electrico.
 * - Trayectoria: Disparo recto cubierto de chispas electricas.
 * - Efecto en el rival: Electrocutado (no puede saltar y su velocidad se reduce al 50% por 3 segundos).
 * - Danio base: 60 puntos.
 */
public class CameroonPowerShot extends PowerShot {

    public static final double BASE_DAMAGE = 60.0;
    public static final double DURATION = 3.0;

    public CameroonPowerShot() {
        super();
    }

    @Override
    public void applyPowerShotToBall(Match match, Player caster, Player opponent, Ball ball) {
        double dir = caster.getFacingDirection();
        ball.applyImpulse(dir * 800.0, -80.0);
        ball.setPowerShot(this, caster, getEffectName(), DURATION);
        ball.setLastKicker(caster);
    }

    @Override
    protected void applyNegativeState(Player caster, Player opponent, Ball ball) {
        opponent.setState(new ElectrocutedState(DURATION));
    }

    @Override
    public String getPowerName() {
        return "Rayo (Camerun)";
    }

    @Override
    public String getEffectName() {
        return "RAYO_ELECTRICO";
    }

    @Override
    public double getBaseDamage() {
        return BASE_DAMAGE;
    }

    @Override
    public double getDuration() {
        return DURATION;
    }
}
