package domain;

import domain.power.PowerShot;

/**
 * Representa a un jugador en la cancha. Maneja su fisica 2D, su barra de vida,
 * el aturdimiento cuando la vida llega a cero, la carga de poder y sus mejoras
 * de estadisticas.
 */
public class Player extends MovableEntity implements java.io.Serializable {

    private static final long serialVersionUID = 1L;

    // Gravedad que jala al jugador hacia el suelo

    public static final double GRAVITY = 650.0;

    // Radio de la cabeza para cabecear el balon

    public static final double HEAD_RADIUS = 26.0;

    // Radio del cuerpo para recibir impactos y patadas

    public static final double BODY_RADIUS = 22.0;

    // Identificador del jugador: 1 para Jugador 1 o 2 para Jugador 2

    private final int id;

    // Nombre para mostrar en pantalla

    private final String name;

    // Tipo de seleccion nacional elegida (Corea, Camerun, Nigeria, USA)

    private final CharacterType characterType;

    // Estadisticas de atributos y formulas de danio

    private final CharacterStats stats;

    // Estrategia concreta del tiro de poder segun su pais

    private final PowerShot powerShot;

    // Hacia donde mira el jugador: 1.0 derecha, -1.0 izquierda

    private double facingDirection;

    // Indica si el jugador esta tocando el suelo para poder saltar

    private boolean isGrounded;

    // Puntos de vida actuales del jugador

    private double currentHealth;

    // Progreso de la barra de poder de 0.0 a 100.0 (se llena en 10 segundos)

    private double powerEnergy;

    // Indica si el aura de poder esta activa alrededor del jugador

    private boolean hasActivePower;

    // Estado actual del jugador mediante el patron State

    private PlayerState state;

    // Puntos acumulados ganados en partidos (+100 victoria, +25 derrota)

    private int accumulatedPoints;

    // Bandera que indica si el jugador esta estirando el pie para patear

    private boolean isKicking;

    // Temporizador de la animacion de la patada (0.22 segundos)

    private double kickDurationTimer;

    // Tiempo de espera antes de poder volver a patear

    private double kickCooldownTimer;

    // Hitbox circular de la cabeza

    private final CircleHitbox headHitbox;

    // Hitbox circular del cuerpo

    private final CircleHitbox bodyHitbox;

    /**
     * Constructor principal para crear e inicializar un jugador en la cancha.
     * 
     * @param id              Numero de jugador (1 o 2).
     * @param name            Nombre o etiqueta del jugador.
     * @param characterType   Pais seleccionado.
     * @param startX          Posicion inicial en X.
     * @param startY          Posicion inicial en Y.
     * @param facingDirection Orientacion (1.0 derecha, -1.0 izquierda).
     */
    public Player(int id, String name, CharacterType characterType, double startX, double startY,
            double facingDirection) {
        super(startX, startY);
        this.id = id;
        this.name = name;
        this.characterType = characterType != null ? characterType : CharacterType.SOUTH_KOREA;
        this.stats = this.characterType.createDefaultStats();
        this.powerShot = this.characterType.createPowerShot();

        this.facingDirection = facingDirection;
        this.isGrounded = true;

        // Inicia con la vida maxima segun su nivel de survival
        this.currentHealth = this.stats.getVidaMax();
        this.powerEnergy = 0.0;
        this.hasActivePower = false;
        this.state = new NormalState();
        this.accumulatedPoints = 0;

        this.isKicking = false;
        this.kickDurationTimer = 0.0;
        this.kickCooldownTimer = 0.0;

        // La cabeza queda arriba del centro y el cuerpo un poco mas abajo
        this.headHitbox = new CircleHitbox(new Vector2D(startX, startY - 45.0), HEAD_RADIUS);
        this.bodyHitbox = new CircleHitbox(new Vector2D(startX, startY - 18.0), BODY_RADIUS);
    }

    /**
     * Retorna el identificador del jugador.
     * 
     * @return Id numerico.
     */
    public int getId() {
        return id;
    }

    /**
     * Retorna el nombre del jugador.
     * 
     * @return Texto con el nombre.
     */
    public String getName() {
        return name;
    }

    /**
     * Retorna el tipo de personaje elegido.
     * 
     * @return Enum CharacterType.
     */
    public CharacterType getCharacterType() {
        return characterType;
    }

    /**
     * Retorna el objeto con las estadisticas y formulas de atributos.
     * 
     * @return CharacterStats del jugador.
     */
    public CharacterStats getStats() {
        return stats;
    }

    /**
     * Retorna el tiro de poder del personaje.
     * 
     * @return Objeto PowerShot.
     */
    public PowerShot getPowerShot() {
        return powerShot;
    }

    /**
     * Retorna el vector de posicion del jugador.
     * 
     * @return Vector2D de posicion.
     */
    public Vector2D getPosition() {
        return position;
    }

    /**
     * Retorna el vector de velocidad del jugador.
     * 
     * @return Vector2D de velocidad.
     */
    public Vector2D getVelocity() {
        return velocity;
    }

    /**
     * Retorna la direccion hacia donde mira el jugador.
     * 
     * @return 1.0 para derecha, -1.0 para izquierda.
     */
    public double getFacingDirection() {
        return facingDirection;
    }

    /**
     * Asigna la orientacion hacia donde mira el jugador.
     * 
     * @param facingDirection 1.0 para derecha o -1.0 para izquierda.
     */
    public void setFacingDirection(double facingDirection) {
        this.facingDirection = facingDirection;
    }

    /**
     * Indica si el jugador esta apoyado en el suelo.
     * 
     * @return true si esta en el pasto.
     */
    public boolean isGrounded() {
        return isGrounded;
    }

    /**
     * Permite fijar manualmente si el jugador se encuentra en el suelo.
     * 
     * @param grounded true si esta apoyado en el pasto, false si esta en el aire.
     */
    public void setGrounded(boolean grounded) {
        this.isGrounded = grounded;
    }

    /**
     * Retorna los puntos de vida actuales.
     * 
     * @return Vida actual.
     */
    public double getCurrentHealth() {
        return currentHealth;
    }

    /**
     * Retorna el porcentaje de energia de poder de 0 a 100.
     * 
     * @return Nivel de la barra de poder.
     */
    public double getPowerEnergy() {
        return powerEnergy;
    }

    /**
     * Indica si el jugador tiene encendida su aura de poder.
     * 
     * @return true si el aura esta activa.
     */
    public boolean hasActivePower() {
        return hasActivePower;
    }

    /**
     * Permite encender o apagar el aura de poder directamente.
     * 
     * @param active true para encender, false para apagar.
     */
    public void setHasActivePower(boolean active) {
        this.hasActivePower = active;
    }

    /**
     * Retorna el estado actual del jugador (Normal, Aturdido, Electrocutado, etc.).
     * 
     * @return Objeto que implementa PlayerState.
     */
    public PlayerState getState() {
        return state;
    }

    /**
     * Cambia el estado del jugador aplicando el patron State.
     * 
     * @param state Nuevo estado a aplicar.
     */
    public void setState(PlayerState state) {
        if (state != null) {
            this.state = state;
        }
    }

    /**
     * Retorna los puntos acumulados para comprar mejoras.
     * 
     * @return Cantidad de puntos acumulados.
     */
    public int getAccumulatedPoints() {
        return accumulatedPoints;
    }

    /**
     * Suma puntos al jugador al finalizar un partido.
     * 
     * @param points Puntos a sumar.
     */
    public void addPoints(int points) {
        this.accumulatedPoints += Math.max(0, points);
    }

    /**
     * Asigna directamente los puntos acumulados del jugador.
     * 
     * @param points Cantidad de puntos acumulados.
     */
    public void setAccumulatedPoints(int points) {
        this.accumulatedPoints = Math.max(0, points);
    }

    /**
     * Restaura la vida del jugador al valor maximo segun su nivel de supervivencia.
     */
    public void restoreHealth() {
        if (this.stats != null) {
            this.currentHealth = this.stats.getVidaMax();
        }
    }

    /**
     * Indica si el jugador esta en medio de la animacion de patada.
     * 
     * @return true si esta pateando.
     */
    public boolean isKicking() {
        return isKicking;
    }

    /**
     * Retorna la hitbox circular de la cabeza.
     * 
     * @return Hitbox de la cabeza.
     */
    public CircleHitbox getHeadHitbox() {
        return headHitbox;
    }

    /**
     * Retorna la hitbox circular del cuerpo.
     * 
     * @return Hitbox del cuerpo.
     */
    public CircleHitbox getBodyHitbox() {
        return bodyHitbox;
    }

    /**
     * Revisa si la barra de poder llego al 100% para poder activarla.
     * 
     * @return true si la barra esta al maximo.
     */
    public boolean isPowerReady() {
        return powerEnergy >= 100.0;
    }

    /**
     * Suma energia a la barra de poder asegurando que no pase de 100.
     * 
     * @param amount Cantidad de energia a sumar.
     */
    public void addPower(double amount) {
        this.powerEnergy = Math.min(100.0, this.powerEnergy + amount);
    }

    /**
     * Cuando el jugador recibe un gol, su barra aumenta un cuarto (+25%).
     */
    public void onConcedeGoal() {
        addPower(25.0);
    }

    /**
     * Activa el aura de poder cuando la barra esta al 100%.
     * La barra se vacia inmediatamente y empieza a recargarse de nuevo.
     * El aura queda visible sin limite de tiempo hasta que el jugador toque el
     * balon.
     * 
     * @throws DOPOSoccerException Si la barra no estaba llena, si ya tenia un poder
     *                             activo o si esta aturdido.
     */
    public void activatePowerAura() throws DOPOSoccerException {
        // mientras tenga el poder en el aura no puede activar otro
        if (hasActivePower) {
            throw new DOPOSoccerException("Ya tienes un tiro de poder activo en tu aura.");
        }
        // requiere barra llena
        if (!isPowerReady()) {
            throw new DOPOSoccerException(DOPOSoccerException.POWER_NOT_READY);
        }
        // No puede activar poder si esta aturdido
        if (!state.canUsePower()) {
            throw new DOPOSoccerException(DOPOSoccerException.PLAYER_STUNNED);
        }

        // Vaciamos la barra para que empiece a recargar de inmediato
        this.powerEnergy = 0.0;
        // Encendemos el aura visible
        this.hasActivePower = true;
    }

    /**
     * Cuando el jugador con aura activa toca el balon,
     * se dispara el tiro de poder sobre el balon y el aura desaparece.
     * 
     * @param match    Partido en curso.
     * @param opponent Jugador rival.
     * @param ball     Balon que toco el jugador.
     */
    public void triggerPowerShotOnBall(Match match, Player opponent, Ball ball) {
        if (!hasActivePower || ball == null) {
            return;
        }
        // El aura desaparece al hacer contacto con el balon
        this.hasActivePower = false;
        // Ejecutamos la estrategia del poder segun el pais
        powerShot.applyPowerShotToBall(match, this, opponent, ball);
    }

    /**
     * Aplica danio a la vida del jugador. Si la vida llega a cero, entra a estado
     * aturdido por 3 segundos.
     * 
     * @param damage Cantidad de danio a descontar.
     */
    public void takeDamage(double damage) {
        this.currentHealth = Math.max(0.0, this.currentHealth - damage);

        // Si la vida llega a cero entra en estado aturdido por 3 segundos
        if (this.currentHealth <= 0.0) {
            this.currentHealth = 0.0;
            setState(new StunnedState(3.0));
        }
    }

    /**
     * Informa si el jugador se encuentra aturdido sin poder actuar.
     * 
     * @return true si esta aturdido, false en caso contrario.
     */
    public boolean isStunned() {
        return this.state instanceof StunnedState;
    }

    /**
     * Compra una mejora para una estadistica gastando los puntos acumulados.
     * El costo se duplica segun el nivel (500, 1000, 2000, 4000...).
     * 
     * @param statName Nombre del atributo: speed, jump, kick o survival.
     * @return true si alcanzo el dinero y se mejoro, false si no.
     */
    public boolean upgradeStat(String statName) {
        int currentLevel = 1;
        if ("speed".equalsIgnoreCase(statName))
            currentLevel = stats.getSpeed();
        else if ("jump".equalsIgnoreCase(statName))
            currentLevel = stats.getJump();
        else if ("kick".equalsIgnoreCase(statName))
            currentLevel = stats.getKick();
        else if ("survival".equalsIgnoreCase(statName))
            currentLevel = stats.getSurvival();

        // Calculamos el costo con la formula de duplicacion
        int cost = CharacterStats.getUpgradeCost(currentLevel);
        if (accumulatedPoints >= cost) {
            boolean upgraded = false;
            if ("speed".equalsIgnoreCase(statName))
                upgraded = stats.upgradeSpeed();
            else if ("jump".equalsIgnoreCase(statName))
                upgraded = stats.upgradeJump();
            else if ("kick".equalsIgnoreCase(statName))
                upgraded = stats.upgradeKick();
            else if ("survival".equalsIgnoreCase(statName)) {
                upgraded = stats.upgradeSurvival();
                // Si sube survival le actualizamos la vida maxima
                if (upgraded)
                    restoreHealth();
            }

            if (upgraded) {
                accumulatedPoints -= cost;
                return true;
            }
        }
        return false;
    }

    /**
     * Ordena caminar a la izquierda respetando si esta confundido o ralentizado.
     */
    public void moveLeft() {
        if (!state.canMove())
            return;
        double baseSpeed = stats.getMovementSpeed() * state.getSpeedMultiplier();

        // Si tiene confusion por el poder de USA los controles van al reves
        if (state.isInvertedControls()) {
            velocity.setX(baseSpeed);
        } else {
            velocity.setX(-baseSpeed);
        }
    }

    /**
     * Ordena caminar a la derecha respetando si esta confundido o ralentizado.
     */
    public void moveRight() {
        if (!state.canMove())
            return;
        double baseSpeed = stats.getMovementSpeed() * state.getSpeedMultiplier();

        // Si tiene confusion por el poder de USA los controles van al reves
        if (state.isInvertedControls()) {
            velocity.setX(-baseSpeed);
        } else {
            velocity.setX(baseSpeed);
        }
    }

    /**
     * Frena el movimiento horizontal si el estado actual lo permite.
     */
    public void stopHorizontal() {
        if (state.canMove()) {
            velocity.setX(0.0);
        }
    }

    /**
     * Ejecuta el salto hacia arriba si esta apoyado en el suelo y el estado lo
     * permite.
     */
    public void jump() {
        if (state.canJump() && isGrounded) {
            velocity.setY(stats.getJumpImpulse());
            isGrounded = false;
        }
    }

    /**
     * Activa la patada ofensiva si no esta en tiempo de recarga.
     * 
     * @return true si inicio la patada con exito.
     */
    public boolean kick() {
        if (state.canKick() && kickCooldownTimer <= 0.0) {
            isKicking = true;
            kickDurationTimer = 0.22; // La patada dura extendida 0.22s
            kickCooldownTimer = 0.38; // Cooldown de 0.38s para volver a patear
            return true;
        }
        return false;
    }

    /**
     * Actualiza la posicion, gravedad, temporizadores y carga de poder en cada tick
     * del juego.
     * 
     * @param dt         Delta time en segundos.
     * @param fieldWidth Ancho de la cancha.
     * @param groundY    Nivel del suelo en Y.
     */
    public void update(double dt, double fieldWidth, double groundY) {
        // Actualizamos el temporizador del estado actual
        state.update(dt, this);

        // Control del tiempo que dura el pie estirado
        if (isKicking) {
            kickDurationTimer -= dt;
            if (kickDurationTimer <= 0.0) {
                isKicking = false;
            }
        }
        if (kickCooldownTimer > 0.0) {
            kickCooldownTimer -= dt;
        }

        // La barra se llena continuamente en 10 segundos (10 puntos por segundo)
        if (powerEnergy < 100.0) {
            addPower(10.0 * dt);
        }

        // Si la posicion en Y esta por encima del suelo, el jugador esta en el aire
        if (position.getY() < groundY - 0.1) {
            isGrounded = false;
        }

        // Si esta en el aire le aplicamos gravedad hacia abajo
        if (!isGrounded) {
            velocity.add(0.0, GRAVITY * dt);
        }

        // Movemos la posicion sumando velocidad por tiempo
        position.add(velocity.getX() * dt, velocity.getY() * dt);

        // Choque con el suelo de la cancha
        if (position.getY() >= groundY) {
            position.setY(groundY);
            velocity.setY(0.0);
            isGrounded = true;
        }

        // Limites laterales para que no se salga de la pantalla
        double halfWidth = 28.0;
        if (position.getX() - halfWidth < 0) {
            position.setX(halfWidth);
            velocity.setX(0.0);
        } else if (position.getX() + halfWidth > fieldWidth) {
            position.setX(fieldWidth - halfWidth);
            velocity.setX(0.0);
        }

        // Actualizamos las hitboxes segun la nueva posicion del jugador
        headHitbox.getCenter().set(position.getX(), position.getY() - 45.0);
        bodyHitbox.getCenter().set(position.getX(), position.getY() - 18.0);
    }
}
