package domain;

/**
 * Representa la cancha de futbol con sus medidas, el nivel del suelo y las dos porterias.
 */
public class Field implements java.io.Serializable {

    private static final long serialVersionUID = 1L;

    // Ancho estandar por defecto de la cancha

    public static final double DEFAULT_WIDTH = 1000.0;

    // Alto estandar por defecto de la cancha

    public static final double DEFAULT_HEIGHT = 550.0;

    // Ancho o profundidad por defecto de los arcos

    public static final double DEFAULT_GOAL_WIDTH = 80.0;

    // Alto por defecto de los arcos

    public static final double DEFAULT_GOAL_HEIGHT = 180.0;

    // Ancho total de la cancha en pixeles

    private final double width;

    // Alto total de la cancha en pixeles

    private final double height;

    // Nivel en el eje Y donde los jugadores y el balon pisan el suelo

    private final double groundY;

    // Porteria del lado izquierdo

    private final GoalPost leftGoal;

    // Porteria del lado derecho

    private final GoalPost rightGoal;

    /**
     * Constructor por defecto con las medidas estandar de 1000x550.
     */
    public Field() {
        this(DEFAULT_WIDTH, DEFAULT_HEIGHT);
    }

    /**
     * Constructor para crear una cancha con resolucion personalizada (800x500, 1000x550, 1200x650).
     * 
     * @param width Ancho de la cancha.
     * @param height Alto de la cancha.
     */
    public Field(double width, double height) {
        this.width = width;
        this.height = height;

        // Dejamos el pasto 50 pixeles por encima del borde inferior de la pantalla
        this.groundY = height - 50.0;

        double goalWidth = DEFAULT_GOAL_WIDTH;
        double goalHeight = DEFAULT_GOAL_HEIGHT;
        // El travesano se ubica restando la altura del arco al nivel del suelo
        double crossbarY = this.groundY - goalHeight;

        // Construimos ambos arcos en los extremos izquierdo y derecho
        this.leftGoal = new GoalPost(GoalPost.Side.LEFT, 0, crossbarY, goalWidth, goalHeight);
        this.rightGoal = new GoalPost(GoalPost.Side.RIGHT, width - goalWidth, crossbarY, goalWidth, goalHeight);
    }

    /**
     * Retorna el ancho total del campo.
     * 
     * @return Ancho en pixeles.
     */
    public double getWidth() {
        return width;
    }

    /**
     * Retorna el alto total del campo.
     * 
     * @return Alto en pixeles.
     */
    public double getHeight() {
        return height;
    }

    /**
     * Retorna la coordenada Y del suelo.
     * 
     * @return Nivel del suelo en Y.
     */
    public double getGroundY() {
        return groundY;
    }

    /**
     * Retorna el arco del lado izquierdo.
     * 
     * @return Objeto GoalPost izquierdo.
     */
    public GoalPost getLeftGoal() {
        return leftGoal;
    }

    /**
     * Retorna el arco del lado derecho.
     * 
     * @return Objeto GoalPost derecho.
     */
    public GoalPost getRightGoal() {
        return rightGoal;
    }
}
