package domain;

/**
 * Guarda las estadisticas y calcula las formulas de juego segun las tablas del PDF:
 *  - multiplicadorKick = 1 + 0.10 * (Kick - 1)
 *  - VidaMax = 100 * (1 + 0.10 * (Survival - 1))
 *  - DanioPatada = 10 * multiplicadorKick
 *  - DanioPoder = DanioTiro * multiplicadorKick
 *  - Costo mejora: empieza en 500 y se duplica en cada nivel (500, 1000, 2000...).
 */
public class CharacterStats implements java.io.Serializable {

    private static final long serialVersionUID = 1L;

    // Nivel minimo para cualquier estadistica

    public static final int MIN_STAT = 1;

    // Nivel maximo alcanzable para las estadisticas

    public static final int MAX_STAT = 10;

    // Precio inicial en puntos para comprar la primera mejora

    public static final int BASE_UPGRADE_PRICE = 500;

    // Nivel de velocidad de movimiento (1 a 10)

    private int speed;

    // Nivel de altura de salto (1 a 10)

    private int jump;

    // Nivel de fuerza de patada para el multiplicador de danio (1 a 10)

    private int kick;

    // Nivel de supervivencia que define la vida maxima (1 a 10)

    private int survival;

    /**
     * Constructor con los 4 atributos iniciales. Trunca los valores entre 1 y 10.
     * 
     * @param speed Nivel inicial de velocidad.
     * @param jump Nivel inicial de salto.
     * @param kick Nivel inicial de patada.
     * @param survival Nivel inicial de supervivencia.
     */
    public CharacterStats(int speed, int jump, int kick, int survival) {
        // Aseguramos que ningun valor quede por debajo de 1 ni por encima de 10
        this.speed = Math.max(MIN_STAT, Math.min(MAX_STAT, speed));
        this.jump = Math.max(MIN_STAT, Math.min(MAX_STAT, jump));
        this.kick = Math.max(MIN_STAT, Math.min(MAX_STAT, kick));
        this.survival = Math.max(MIN_STAT, Math.min(MAX_STAT, survival));
    }

    /**
     * Retorna el nivel actual de velocidad.
     * 
     * @return Puntos de velocidad.
     */
    public int getSpeed() {
        return speed;
    }

    /**
     * Retorna el nivel actual de salto.
     * 
     * @return Puntos de salto.
     */
    public int getJump() {
        return jump;
    }

    /**
     * Retorna el nivel actual de patada.
     * 
     * @return Puntos de patada.
     */
    public int getKick() {
        return kick;
    }

    /**
     * Retorna el nivel actual de supervivencia.
     * 
     * @return Puntos de supervivencia.
     */
    public int getSurvival() {
        return survival;
    }

    public void setSpeed(int speed) {
        this.speed = Math.max(MIN_STAT, Math.min(MAX_STAT, speed));
    }

    public void setJump(int jump) {
        this.jump = Math.max(MIN_STAT, Math.min(MAX_STAT, jump));
    }

    public void setKick(int kick) {
        this.kick = Math.max(MIN_STAT, Math.min(MAX_STAT, kick));
    }

    public void setSurvival(int survival) {
        this.survival = Math.max(MIN_STAT, Math.min(MAX_STAT, survival));
    }

    /**
     * Calcula cuanto cuesta subir un nivel segun la formula de duplicacion:
     * Nivel 1 a 2 cuesta 500, de 2 a 3 cuesta 1000, de 3 a 4 cuesta 2000, etc.
     * 
     * @param currentLevel Nivel que tiene actualmente la estadistica.
     * @return Costo en puntos para adquirir el siguiente nivel.
     */
    public static int getUpgradeCost(int currentLevel) {
        if (currentLevel < 1 || currentLevel >= MAX_STAT) {
            return Integer.MAX_VALUE;
        }
        // Formula: 500 * (2 elevado a la currentLevel - 1)
        return BASE_UPGRADE_PRICE * (1 << (currentLevel - 1));
    }

    /**
     * Sube un punto a la velocidad si aun no llego al maximo de 10.
     * 
     * @return true si se pudo mejorar, false si ya estaba al tope.
     */
    public boolean upgradeSpeed() {
        if (speed < MAX_STAT) {
            speed++;
            return true;
        }
        return false;
    }

    /**
     * Sube un punto al salto si aun no llego al maximo de 10.
     * 
     * @return true si se pudo mejorar, false si ya estaba al tope.
     */
    public boolean upgradeJump() {
        if (jump < MAX_STAT) {
            jump++;
            return true;
        }
        return false;
    }

    /**
     * Sube un punto a la patada si aun no llego al maximo de 10.
     * 
     * @return true si se pudo mejorar, false si ya estaba al tope.
     */
    public boolean upgradeKick() {
        if (kick < MAX_STAT) {
            kick++;
            return true;
        }
        return false;
    }

    /**
     * Sube un punto a la supervivencia si aun no llego al maximo de 10.
     * 
     * @return true si se pudo mejorar, false si ya estaba al tope.
     */
    public boolean upgradeSurvival() {
        if (survival < MAX_STAT) {
            survival++;
            return true;
        }
        return false;
    }

    /**
     * Formula oficial de la Tabla 3: multiplicadorKick = 1 + 0.10 * (Kick - 1).
     * Cada punto extra por encima de 1 suma un 10% de danio adicional.
     * 
     * @return Multiplicador numerico de la patada y poder.
     */
    public double getMultiplicadorKick() {
        // Ejemplo: kick 1 -> 1.0; kick 4 -> 1.30; kick 5 -> 1.40
        return 1.0 + 0.10 * (this.kick - 1);
    }

    /**
     * Formula oficial de la Tabla 2: VidaMax = 100 * (1 + 0.10 * (Survival - 1)).
     * Parte de 100 puntos de vida base y suma 10% por cada punto extra de survival.
     * 
     * @return Cantidad de vida maxima del jugador.
     */
    public double getVidaMax() {
        // Ejemplo: survival 1 -> 100; survival 3 -> 120; survival 4 -> 130
        return 100.0 * (1.0 + 0.10 * (this.survival - 1));
    }

    /**
     * Formula oficial de la Tabla: DanioPatada = 10 * multiplicadorKick.
     * 
     * @return Danio que inflige una patada al golpear al rival.
     */
    public double getDanioPatada() {
        // Base de 10 puntos escalada por el multiplicador de patada
        return 10.0 * getMultiplicadorKick();
    }

    /**
     * Formula oficial de la Tabla: DanioPoder = DanioTiro * multiplicadorKick.
     * 
     * @param danioTiro Danio base del tiro de poder segun el pais del personaje.
     * @return Danio total infligido al rival con el tiro de poder.
     */
    public double getDanioPoder(double danioTiro) {
        // Multiplicamos el danio base del pais por el multiplicador de kick del jugador
        return danioTiro * getMultiplicadorKick();
    }

    /**
     * Calcula la rapidez de movimiento horizontal en pixeles por segundo.
     * 
     * @return Velocidad horizontal segun el nivel de speed.
     */
    public double getMovementSpeed() {
        // Velocidad base de 260 mas 20 pixeles por cada nivel de speed
        return 260.0 + 20.0 * (this.speed - 1);
    }

    /**
     * Calcula la fuerza de impulso vertical para el salto.
     * 
     * @return Impulso de salto hacia arriba en Y (valor negativo).
     */
    public double getJumpImpulse() {
        // Impulso base hacia arriba de -480 mas -15 por cada nivel de jump
        return -480.0 - 15.0 * (this.jump - 1);
    }
}
