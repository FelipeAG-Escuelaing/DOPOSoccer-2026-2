package domain;

/**
 * Perfil Ofensivo de la maquina.
 * Su maxima prioridad es buscar el balon, avanzar hacia el arco rival y rematar.
 */
public class OffensiveProfile implements MachineProfile {

    private static final long serialVersionUID = 1L;

    public OffensiveProfile() {
        // Constructor por defecto
    }

    @Override
    public String getProfileName() {
        return "Ofensiva";
    }

    @Override
    public void decideAction(MachinePlayer machine, Match match, double dt) {
        if (machine == null || match == null) {
            return;
        }

        Ball ball = match.getMainBall();
        if (ball == null) {
            return;
        }

        double machineX = machine.getPosition().getX();
        double machineY = machine.getPosition().getY();
        double ballX = ball.getPosition().getX();
        double ballY = ball.getPosition().getY();

        // Si el balon esta detras de la maquina (a su derecha), retrocede para colocarse detras de el
        if (ballX > machineX + 20.0) {
            machine.moveRight();
        } else {
            // El balon esta en frente: avanzamos hacia la izquierda para empujarlo al arco rival
            double distToBall = Math.abs(machineX - ballX);
            if (distToBall > 35.0) {
                machine.moveLeft();
            } else {
                machine.stopHorizontal();
            }
        }

        // Si el balon esta cerca para patear (a menos de 85 pixeles)
        double dx = Math.abs(machineX - ballX);
        double dy = Math.abs(machineY - ballY);
        if (dx < 85.0 && dy < 70.0) {
            machine.kick();
        }

        // Si el balon viene por el aire y esta a su alcance, salta para cabecear
        if (ballY < machineY - 35.0 && dx < 90.0 && machine.isGrounded()) {
            machine.jump();
        }

        // Si la barra de poder esta al 100%, la activa para asegurar el gol
        if (machine.isPowerReady()) {
            try {
                machine.activatePowerAura();
            } catch (DOPOSoccerException e) {
                // Se ignora si no esta listo
            }
        }
    }
}
